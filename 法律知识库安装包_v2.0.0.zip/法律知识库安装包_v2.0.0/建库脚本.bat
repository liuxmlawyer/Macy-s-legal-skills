@echo off
REM ============================================================
REM  Legal Knowledge Base v2.0.0 - Skeleton Builder
REM  Creates an empty 10-domain library structure.
REM  Pure ASCII to avoid cmd parsing issues on Chinese Windows.
REM ============================================================
setlocal

set "PKG_DIR=%~dp0"

if "%~1"=="" (
    echo Usage: build_skeleton.bat ^<target-dir^>
    echo Example: build_skeleton.bat D:\MyLawKB
    pause
    exit /b 1
)

echo Building empty library structure at: %~1
echo.
python "%PKG_DIR%scripts\build_skeleton.py" "%~1" --with-index
if errorlevel 1 (
    echo [FAILED] Could not build the structure.
    pause
    exit /b 1
)

echo.
echo Done. No legal content was written.
pause
endlocal
