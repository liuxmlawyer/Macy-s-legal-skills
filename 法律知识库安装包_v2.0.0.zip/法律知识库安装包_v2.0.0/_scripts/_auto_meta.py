# -*- coding: utf-8 -*-
"""_auto_meta.py —— 元数据自动赋值入口（RULE-20261025-001 / rules.md V4.1）

**这是「自动填写三字段」的可调用入口**，不是文档说明。调用链：

    真实来源查询结果（JSON）
        ↓
    _meta_rules.auto_assign()          ← 规则引擎（唯一真源）
        ↓
    本脚本（dry-run 预览 / --write 写回）

用法：
    # 1) 预览单页（默认 dry-run，不写任何文件）
    python _scripts/_auto_meta.py --page wiki/01-labor/terms/xxx.md \
        --source-result sr.json

    # 2) 批量预览（对整个 wiki 目录做「旧值 → 拟改值」对照）
    python _scripts/_auto_meta.py --scan wiki --source-result sr.json \
        --csv out.csv

    # 3) 写回（仅限 --page 单页，且必须显式 --write）
    python _scripts/_auto_meta.py --page <path> --source-result sr.json --write

    # 4) 显式传入实际发布结果（决定 review_status）
    python _scripts/_auto_meta.py --page <path> --source-result sr.json \
        --publish-result pr.json
    #   pr.json = {"ingest_ok": true, "index_ok": true,
    #              "tech_gate_ok": true, "human_reviewed": false}
    #   ⚠️ 不提供时按「该页已在 wiki 正式库」推定前三项成功（human_reviewed 仍为 false），
    #      避免已入库页被提议降级为「草稿」。

⚠️ **安全约束（任务单红线）**：
  · 默认 dry-run，**不写文件**；
  · `--write` 只改 frontmatter 的四个键：
    `status` / `authority_level` / `review_status` / `verified_at` / `verify_source`；
  · **绝不**改 `last_verified`（人工核验日期，AI 不填）；
  · **绝不**改 `raw/`、不改 id、不批量迁移存量页；
  · 命中 `manual_overrides` 的字段**不覆盖**，只报告；
  · 无真实查询结果（`query_ok=false`）→ 只允许落 `待核实` / `unknown`，
    **不得**凭空声明有效。

`--source-result` JSON 结构（最小示例）：

    {
      "kind": "法规",                       // 法规 | 案例 | 实务分析
      "query_ok": true,                    // 查询是否成功执行
      "effect_fact": "现行有效",            // 来源明确给出的效力事实
      "verify_source": "flk-npc",          // 实际采用的来源
      "verified_at": "2026-10-25",         // 真实核验时间（可选，非法则丢弃）
      "note": "查询成功，命中现行版本"
    }
"""

from __future__ import annotations

import argparse
import csv
import errno
import glob
import hashlib
import json
import os
import re
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _paths import ROOT  # noqa: E402
import _meta_rules as MR  # noqa: E402

FM_RE = re.compile(r"^---\s*\r?\n(.*?)\r?\n---", re.S)


# ────────────────────────────────────────────────────────────
# frontmatter 读写（**只改白名单键**，其余字节原样保留）
# ────────────────────────────────────────────────────────────

WRITABLE_KEYS = ("status", "authority_level", "review_status",
                 "verified_at", "verify_source")

#: **块级**可写键（F06）：核验证据记录。
#:
#: ⚠️ `verify_record` 是**嵌套结构**（含 list 型 `clauses`），不能走
#:    `apply_to_text` 的行级标量替换，也不能用 `render_fm` 整体重渲染
#:    （F02 的核心教训：整体重渲染会把 list 变成字符串、把带引号的日期
#:    变成 YAML date）。
#:    故单列 `WRITABLE_BLOCK_KEYS`，由 `_replace_block()` 做**块级定向
#:    替换**——只替换 `verify_record:` 及其缩进子行，其余行逐字节保留。
#:
#: ⚠️ F06 的核心要求：新取得的来源证据必须与 status / verify_source /
#:    verified_at **一致保存**，否则会出现「状态说是现行有效、证据却还是
#:    上一轮的旧链接/旧日期」的自相矛盾。
WRITABLE_BLOCK_KEYS = ("verify_record",)


def parse_fm(text: str):
    """真实 YAML 解析（PyYAML）；解析失败抛异常，**不降级放行**。"""
    m = FM_RE.match(text)
    if not m:
        return None, text, None
    block = m.group(1)
    try:
        import yaml
    except Exception as exc:
        raise RuntimeError("缺少 PyYAML 依赖，无法进行真实 YAML 解析：%s" % exc)
    try:
        data = yaml.safe_load(block)
    except Exception as exc:
        raise RuntimeError("frontmatter YAML 语法错误：%s: %s"
                           % (type(exc).__name__, exc))
    if data is None:
        data = {}
    if not isinstance(data, dict):
        raise RuntimeError("frontmatter 顶层不是映射结构")
    return data, text, m


def _scalar_text(v):
    if v is None:
        return ""
    if isinstance(v, (dict, list)):
        return ""
    if isinstance(v, bool):
        return "true" if v else "false"
    return str(v).strip()


def render_fm(data: dict) -> str:
    """把 dict 渲染回 YAML frontmatter 文本（保持简单标量风格）。"""
    lines = ["---"]
    for k, v in data.items():
        if isinstance(v, (dict, list)):
            lines.append("%s:" % k)
            if isinstance(v, list):
                for it in v:
                    if isinstance(it, dict):
                        first = True
                        for ik, iv in it.items():
                            prefix = "  - " if first else "    "
                            lines.append("%s%s: %s" % (prefix, ik,
                                                        _yaml_scalar(iv)))
                            first = False
                    else:
                        lines.append("  - %s" % _yaml_scalar(it))
            else:
                for ik, iv in v.items():
                    lines.append("  %s: %s" % (ik, _yaml_scalar(iv)))
        else:
            lines.append("%s: %s" % (k, _yaml_scalar(v)))
    lines.append("---")
    return "\n".join(lines)


def _yaml_scalar(v) -> str:
    if v is None:
        return '""'
    if isinstance(v, bool):
        return "true" if v else "false"
    s = str(v)
    if s == "":
        return '""'
    if re.match(r"^[0-9]{4}-[0-9]{2}-[0-9]{2}$", s):
        # ⚠️ F02 的延伸：**日期一律加引号**。
        #    裸写 `2026-10-25` 会被 YAML 解析成 **date 对象**，
        #    使写回后 `last_verified` / `verified_at` / `verified_on`
        #    的类型从 str 变成 datetime.date —— 这正是 F02 批评的
        #    「类型漂移」。库内既有写法也是带引号
        #    （`last_verified: "2026-10-24"`），保持一致。
        return '"%s"' % s
    if re.search(r"[:#\[\]{}&*!|>'\"%@`]|^\s|\s$", s):
        return '"%s"' % s.replace('"', '\\"')
    return s


# ────────────────────────────────────────────────────────────
# 定向行编辑（F02）：只改授权键所在的那一行，其余字节原样保留
# ────────────────────────────────────────────────────────────

def _fm_line_span(text: str):
    """返回 (fm_start, fm_end, block_lines) —— frontmatter 内部行区间。

    `fm_start` 为 frontmatter 首行（`---`）的起始偏移；
    `fm_end`   为结束 `---` 行**之后**的偏移；
    `block_lines` 为 frontmatter 内容行列表（不含两个 `---`）。
    """
    m = FM_RE.match(text)
    if not m:
        return None, None, None
    head = text[:m.start(1)]
    body_start = m.start(1)
    body_end = m.end(1)
    lines = text[body_start:body_end].split("\n")
    return m.start(), m.end(), lines


def _find_key_line(lines, key):
    """在 frontmatter 行列表中定位**顶层**键 `key` 的行号。

    只匹配行首无缩进的 `key:`（顶层键）；嵌套层（缩进）不会被误认。
    返回 (index, indent, raw_line) 或 None。
    """
    pat = re.compile(r"^(\s*)%s\s*:" % re.escape(key))
    for i, line in enumerate(lines):
        m = pat.match(line)
        if m:
            return i, m.group(1), line
    return None


def _replace_scalar_line(line: str, value) -> str:
    """把一行 `key: <old>` 改为 `key: <new>`，**只替换值部分**。

    保留原行的键名写法与行尾注释。
    """
    m = re.match(r"^(\s*)([^:]+?)(\s*):(\s*)(.*)$", line)
    if not m:
        return line
    indent, key, gap_before, gap_after, old = m.groups()
    # 保留原行内注释（` # ...`）
    comment = ""
    body = old
    cm = re.search(r"\s+#.*$", old)
    if cm:
        body = old[:cm.start()]
        comment = " " + cm.group(0).strip()
    return "%s%s:%s%s%s" % (indent, key, gap_before, gap_after,
                            _yaml_scalar(value)) + comment


def _render_block(key: str, value: dict) -> list:
    """把一个嵌套 dict 渲染为 frontmatter 内的**块**行列表。

    格式：
        key:
          sub1: v1
          list_key:
            - a
            - b

    ⚠️ 与 `render_fm()` 的区别：这里**只渲染这一个键**，
    供 `_replace_block()` 做块级定向替换；且 list 用**块序列**表示
    （`- item` 逐行），保证 YAML 解析回来仍是 list（F02 的教训）。
    """
    lines = ["%s:" % key]
    for k, v in value.items():
        if isinstance(v, list):
            lines.append("  %s:" % k)
            for it in v:
                if isinstance(it, dict):
                    first = True
                    for ik, iv in it.items():
                        prefix = "  - " if first else "    "
                        lines.append("%s%s: %s" % (prefix, ik,
                                                   _yaml_scalar(iv)))
                        first = False
                else:
                    lines.append("  - %s" % _yaml_scalar(it))
        elif isinstance(v, dict):
            lines.append("  %s:" % k)
            for ik, iv in v.items():
                if isinstance(iv, list):
                    lines.append("    %s:" % ik)
                    for it in iv:
                        lines.append("      - %s" % _yaml_scalar(it))
                else:
                    lines.append("    %s: %s" % (ik, _yaml_scalar(iv)))
        else:
            lines.append("  %s: %s" % (k, _yaml_scalar(v)))
    return lines


def _find_block_span(lines, key):
    """定位 frontmatter 中某个**顶层块键**的行区间。

    返回 (start_idx, end_idx_exclusive) 或 None：
      · `start_idx` —— `key:` 所在行；
      · `end_idx`   —— 块内容结束后的第一行（即下一个顶层键所在行）。
    """
    pat = re.compile(r"^(\s*)%s\s*:" % re.escape(key))
    for i, line in enumerate(lines):
        m = pat.match(line)
        if not m:
            continue
        if m.group(1):        # 缩进的同名键 → 不是顶层键
            continue
        j = i + 1
        while j < len(lines):
            ln = lines[j]
            if not ln.strip():
                j += 1
                continue
            if ln.startswith((" ", "\t")):    # 缩进 → 仍属本块
                j += 1
                continue
            break                                # 顶格 → 块结束
        return i, j
    return None


def _replace_block(lines, key: str, value: dict):
    """把 frontmatter 中的 `key:` 块**定向替换**为新值。

    · 键不存在 → 在 frontmatter 内容末尾追加新块；
    · 键存在   → 只替换该块（含其缩进子行），其余行**逐字节保留**。

    返回 (new_lines, changed: bool)。
    """
    span = _find_block_span(lines, key)
    new_block = _render_block(key, value)
    if span is None:
        return lines + new_block, True
    i, j = span
    return lines[:i] + new_block + lines[j:], True


def apply_to_text(text: str, fm: dict, updates: dict) -> str:
    """把 `updates`（**白名单键**）写回 frontmatter。

    ⚠️ **F02（Codex v1 反例）——只改被授权键的那一行**：
    旧实现用 `render_fm()` 把**整个 frontmatter** 重新序列化，导致：
      · `verify_record.clauses` 这类嵌套 list 被渲染成字符串；
      · `last_verified: "2026-10-24"`（str）被渲染成 YAML date；
      · 注释、文本块、嵌套结构全部被破坏。
    现实现改为**行级定向编辑**：
      · 只定位并替换白名单键**所在的那一行**；
      · 其余行（嵌套 verify_record、manual_overrides、citations、
        last_verified 的原始表示、注释、文本块）**逐字节原样保留**；
      · 正文（frontmatter 之后）**逐字节原样保留**；
      · 键不存在时，在 frontmatter **末尾追加**该键（不改动已有任何行）。

    ⚠️ **F06（Codex v1 缺口）——块级键单独处理**：
    `verify_record` 等**嵌套结构**走 `_replace_block()`（块级定向替换），
    不用行级标量替换，也**绝不**用 `render_fm()` 整体重渲染。
    """
    m = FM_RE.match(text)
    if not m:
        raise RuntimeError("该页面没有 frontmatter，拒绝写入")

    fm_start, fm_end, lines = _fm_line_span(text)
    if lines is None:
        raise RuntimeError("frontmatter 定位失败，拒绝写入")

    changed = False
    # ── ① 标量级白名单键：行级定向编辑 ──
    for k, v in updates.items():
        if k not in WRITABLE_KEYS:
            continue
        old = fm.get(k)
        old_s = "" if old is None else str(old).strip()
        if old_s == str(v).strip():
            continue
        loc = _find_key_line(lines, k)
        if loc is None:
            # 键不存在 → 在 frontmatter 内容末尾追加（不触碰已有行）
            lines.append("%s: %s" % (k, _yaml_scalar(v)))
        else:
            idx, _indent, raw = loc
            lines[idx] = _replace_scalar_line(raw, v)
        changed = True

    # ── ② 块级白名单键（verify_record）：块级定向替换 ──
    for k, v in updates.items():
        if k not in WRITABLE_BLOCK_KEYS:
            continue
        if not isinstance(v, dict):
            continue
        lines, _ch = _replace_block(lines, k, v)
        changed = True

    if not changed:
        return text

    new_block = "\n".join(lines)
    # frontmatter 起止：`---` + 内容 + `---`
    head_prefix = text[:m.start(1)]
    tail = text[m.end(1):]
    # tail 以 "\n---" 开头（FM_RE 捕获组不含结束 ---）
    # 重新拼装：head_prefix + new_block + tail
    return head_prefix + new_block + tail


# ────────────────────────────────────────────────────────────
# 单页计算
# ────────────────────────────────────────────────────────────

def compute_page(path: str, sr: dict, publish_result: dict | None = None,
                root: str = None):
    """计算单页的拟改值；返回 (result_dict, error_str)。

    `publish_result` —— **实际发布结果**（可选）：
      {"ingest_ok": true, "index_ok": true, "tech_gate_ok": true,
       "human_reviewed": false}

    ⚠️ **F01（Codex v1 反例）——未提供发布结果时不得推定成功**：
    旧实现（v1 修正版）在 `publish_result` 为空时，按「该页已在 wiki 正式库」
    **推定 ingest/index/tech 三项成功**。这等于用**路径存在**代替
    **索引 / 门禁成功**，会让 `draft/` 下的草稿页被提议升级为「已发布」。

    现行为（F01 修复后的保守语义）：
      · **未提供** `publish_result` → `publish_known=False`
        → 一律按**保守值「草稿」**处理，**任何页都不升级**；
      · **已提供** → 依实际布尔值判定（任一失败 → 草稿；三项全成功 → 已发布）；
      · **已有「已发布」的存量页**：不提供发布结果时**保留原状态**（不降级、
        不升级），并在 `gaps` 中记录「未提供实际发布结果，保留原状态」。

    ⚠️ 保留原状态**不等于**认定其已发布——只是**不代替用户做降级判断**。
    """
    abs_p = path if os.path.isabs(path) else os.path.join(root or ROOT, path)
    try:
        rel = os.path.relpath(abs_p, root or ROOT).replace("\\", "/")
    except ValueError:
        rel = str(abs_p)
    try:
        text = open(abs_p, encoding="utf-8", errors="ignore").read()
    except OSError as exc:
        return None, "%s — 读取失败：%s" % (rel, exc)
    try:
        fm, _, _ = parse_fm(text)
    except RuntimeError as exc:
        return None, "%s — %s" % (rel, exc)
    if fm is None:
        return None, "%s — 无 frontmatter" % rel

    publish_known = publish_result is not None
    # ── G01：发布结果整体与逐字段**严格类型验证**（禁止 bool() 预转换）──
    pr_known, pr_flags, pr_errors = MR.validate_publish_result(publish_result)
    pr = pr_flags
    current_review = _scalar_text(fm.get("review_status"))

    res = MR.auto_assign(
        fm, sr,
        ingest_ok=pr["ingest_ok"],
        index_ok=pr["index_ok"],
        tech_gate_ok=pr["tech_gate_ok"],
        human_reviewed=pr["human_reviewed"],
        publish_known=publish_known,
    )
    old = {k: _scalar_text(fm.get(k)) for k in WRITABLE_KEYS}
    new = {k: res.get(k, "") for k in ("status", "authority_level",
                                      "review_status")}
    new["verified_at"] = res.get("verified_at", "")
    new["verify_source"] = res.get("verify_source", "")

    # ── G02：目标绑定核对（消费端）——来源结果必须确实属于**本页** ──
    #   核对维度：稳定页面 ID / 当前页内容指纹 / 对象 / 版本 / 条款 /
    #   匹配结论（matched）。任一不符 → 本页核验不成立。
    sr_target = sr.get("target") if isinstance(sr, dict) else None
    binding_present = isinstance(sr_target, dict) and bool(sr_target)
    binding_ok = False
    binding_errors = []
    binding_details = {"checks": []}
    if binding_present:
        binding_ok, binding_errors, binding_details = MR.check_target_binding(
            sr_target, fm, text, rel, source_result=sr)

    # ── F06 / G03：新取得的来源证据（verify_record）必须**完整且一致** ──
    #   完整证据 + 一致对象版本日期是**核验写回的前置条件**；
    #   缺字段 / 空壳 / 坏类型 / 未来日期 / 日期不一致 → 失败关闭。
    vr_new = None
    evidence_ok = False
    evidence_errors = []
    sr_ok = res.get("source_result_ok")
    if sr_ok:
        evidence_ok, evidence_errors = MR.check_verify_record(sr, fm)
        if evidence_ok:
            raw_vr = sr.get("verify_record")
            vr_new = dict(raw_vr)
            # ⚠️ G03：**不得**改写 verified_on 伪装无冲突——
            #    日期不一致已在 check_verify_record() 中失败关闭。
    else:
        evidence_errors = ["来源结果未通过严格结构/类型校验（query_ok 非真布尔等）"]

    # ── 本页核验是否成立（区分「查询传输成功」与「本页核验成功」）──
    page_verified = bool(sr_ok and evidence_ok and
                         (binding_ok if binding_present else False))

    ov = MR.read_manual_overrides(fm)
    conflicts = [n for n in res["notes"] if n.get("conflict")]
    gaps = []
    if not _scalar_text(fm.get("jurisdiction")) and \
            MR.normalize_case_effect(fm.get("case_effect")) == "典型案例":
        gaps.append("典型案例缺地域（映射表第10行 → unknown）")

    # ── F01：发布结果未知的处理 ──
    if not publish_known:
        if current_review == MR.RS_PUBLISHED:
            # 存量已发布页：保留原状态（不降级、不升级）
            new["review_status"] = MR.RS_PUBLISHED
            gaps.append("未提供实际发布结果（发布状态不可追溯）→ 保留原状态"
                        "「已发布」，未据此重新认定；如需变更请提供 --publish-result")
        else:
            gaps.append("未提供实际发布结果（发布状态不可追溯）→ 保守记为「草稿」，"
                        "不得推定成功")
    for e in pr_errors:
        gaps.append("发布结果严格类型校验：%s" % e)
    if not pr_known:
        gaps.append("发布结果整体不是可用对象（publish_known=False）→ "
                    "不得升级为「已发布」，按保守值处理")
    for e in res.get("source_result_errors", []):
        gaps.append("来源结果结构/类型校验：%s" % e)
    if not res.get("source_result_ok"):
        gaps.append("未取得真实查询结果，只能落 待核实/unknown")
    if res["verification"]:
        gaps.extend(res["verification"])

    # ── G02：绑定失败 → 不得把**别页/别版本/旧内容**的结果算作本页核验 ──
    if not binding_ok:
        if binding_present:
            for e in binding_errors:
                gaps.append("目标绑定核对：%s" % e)
        else:
            gaps.append("未提供目标绑定信息（target 缺失或为空）→ "
                        "**本页核验不成立**：不得保存核验成功状态"
                        "（status/verified_at/verify_source/verify_record 均不落）")
        # ⚠️ G02：**缺绑定**与**绑定不通过**同等处理——
        #    「缺绑定字段…不得保存核验成功状态」是通知的明文要求，
        #    故此处**真正重置**拟改值（仅记 gap 而不重置 = 形同虚设）。
        new["status"] = MR.STATUS_UNVERIFIED
        new["verified_at"] = ""
        new["verify_source"] = MR.VERIFY_UNVERIFIED
        vr_new = None
        evidence_ok = False

    # ── G03：证据不完整 → 失败关闭（不得只记 gaps 后仍落成功状态）──
    if sr_ok and not evidence_ok:
        for e in evidence_errors:
            gaps.append("核验证据前置校验：%s" % e)
        # 证据本身不合格 → 不得保存核验成功状态
        new["status"] = MR.STATUS_UNVERIFIED
        new["verified_at"] = ""
        new["verify_source"] = MR.VERIFY_UNVERIFIED
        vr_new = None

    # ── F06：证据一致性检查（verify_record 与 status/来源/日期对齐）──
    vr_consistency = []
    if vr_new is not None:
        if not vr_new.get("official_url"):
            vr_consistency.append("verify_record 缺 official_url")
        if not vr_new.get("evidence_location"):
            vr_consistency.append("verify_record 缺 evidence_location")
        if not vr_new.get("clauses"):
            vr_consistency.append("verify_record 缺 clauses（无条号证据）")
        va = new.get("verified_at") or ""
        if va and vr_new.get("verified_on") != va:
            vr_consistency.append("verify_record.verified_on 与 verified_at "
                                  "不一致（**不改写** verified_on 伪装无冲突，"
                                  "本次核验失败关闭）")
        if new.get("verify_source") and \
                new["verify_source"] not in MR.VERIFY_REAL_SOURCES:
            vr_consistency.append("verify_source=%r 不在真实来源白名单内"
                                  % new["verify_source"])
        if vr_consistency:
            gaps.extend("证据一致性：%s" % c for c in vr_consistency)
    else:
        vr_consistency = ["本轮未取得可用证据（查询未成功 / 目标不匹配 / "
                          "证据不完整）→ 不写回 verify_record"]

    return {
        "path": rel,
        "old": old,
        "new": new,
        "changed_fields": [k for k in WRITABLE_KEYS
                           if old.get(k, "") != new.get(k, "")],
        "basis": {k: v["basis"] for k, v in res["computed"].items()},
        "manual_overrides": {k: v[0] for k, v in ov.items()},
        "override_conflicts": conflicts,
        "gaps": gaps,
        "notes": res["notes"],
        "verify_record_new": vr_new,
        "verify_record_consistency": vr_consistency,
        # ── G02/G03 可观察标志 ──
        "binding_present": binding_present,
        "binding_ok": binding_ok,
        "binding_errors": binding_errors,
        "binding_checks": binding_details.get("checks", []),
        "evidence_ok": evidence_ok,
        "evidence_errors": evidence_errors,
        "page_verified": page_verified,
        "publish_known": pr_known,
        "publish_errors": pr_errors,
        "text": text,
        "fm": fm,
        # ── G02（v4 补正）：**已核验输入**的原文与指纹 ──
        #   写回层据此在替换前复核「目标文件是否仍与已核验输入一致」，
        #   避免用旧内容生成的文本覆盖核验之后的用户修改。
        #   ⚠️ `text` 即本函数**实际读到并据以校验**的那一份内容；
        #      `verified_fingerprint` 是它的 sha256（`page_fingerprint` 口径）。
        "verified_input": text,
        "verified_fingerprint": MR.page_fingerprint(text),
    }, None


# ────────────────────────────────────────────────────────────
# 写回路径边界（F04）——在最靠近写入的位置强制校验
# ────────────────────────────────────────────────────────────

#: 允许写入的目标层（相对 ROOT 的顶层目录）
ALLOWED_WRITE_DIRS = ("wiki", "draft")

#: 明确**禁止**写入的顶层目录（即使在 ROOT 之内）
FORBIDDEN_WRITE_DIRS = ("raw",)


def resolve_write_path(path: str, root: str = None) -> tuple:
    """解析并**强制校验**写入目标路径。

    返回 (abs_path, rel_path, error)：
      · error 为 None → 通过校验；
      · error 为字符串 → 拒绝写入的原因。

    ⚠️ **F04（Codex v1 反例）——写回必须有强制边界**：
    旧实现只做 `os.path.join(ROOT, path)`，对 `raw/x.md`、绝对路径、`../`
    穿越、库外路径**一律照写**，且返回 rc=0。

    本实现的校验顺序（**先 resolve 真实路径，再判断范围**）：
      ① `os.path.realpath()` 解析符号链接 / junction / `..`；
      ② 目标必须**真实位于** `ROOT` 之内（`os.path.commonpath` 比较）；
      ③ 顶层目录必须在 `ALLOWED_WRITE_DIRS` 内（默认 `wiki` / `draft`）；
      ④ 顶层目录不得在 `FORBIDDEN_WRITE_DIRS` 内（默认 `raw`）；
      ⑤ **父目录链上不得存在符号链接 / junction**（防止链接绕过）；
      ⑥ 目标文件本身若已是符号链接 → 拒绝。

    ⚠️ 本函数**只做范围判定，不写文件**——调用方在**真正 open(..., "w") 之前**
    必须调用它；这是「最靠近写入的位置」。
    """
    root_abs = os.path.realpath(root if root is not None else ROOT)
    raw_path = path
    if not os.path.isabs(raw_path):
        raw_path = os.path.join(root_abs, raw_path)
    # ① 解析真实路径（含 .. 与链接）
    real = os.path.realpath(raw_path)

    # ② 必须真实位于 ROOT 之内
    try:
        common = os.path.commonpath([real, root_abs])
    except ValueError:
        return None, None, "目标路径不在库内（跨盘符或不同根）：%s" % raw_path
    if common != root_abs:
        return None, None, ("拒绝写入：目标不在授权根目录内（%s）"
                           % raw_path)

    # ③ 顶层目录白名单
    try:
        rel = os.path.relpath(real, root_abs).replace("\\", "/")
    except ValueError:
        return None, None, "无法计算相对路径：%s" % raw_path
    parts = [p for p in rel.split("/") if p]
    if not parts:
        return None, None, "拒绝写入：目标就是库根目录"
    top = parts[0]
    if top in FORBIDDEN_WRITE_DIRS:
        return None, None, ("拒绝写入：`%s/` 为原件只读区（raw/ 不得由脚本改写）"
                           % top)
    if top not in ALLOWED_WRITE_DIRS:
        return None, None, ("拒绝写入：目标层 `%s/` 不在授权写入层 %s 内"
                           % (top, "/".join(ALLOWED_WRITE_DIRS)))

    # ⑤ 父目录链上不得有链接 / junction
    cur = real
    while True:
        parent = os.path.dirname(cur)
        if not parent or parent == cur:
            break
        if os.path.islink(cur):
            return None, None, ("拒绝写入：路径链上存在符号链接：%s" % cur)
        cur = parent

    # ⑥ 目标文件本身若是符号链接 → 拒绝
    if os.path.islink(real):
        return None, None, "拒绝写入：目标文件本身是符号链接：%s" % real

    return real, rel, None


def write_page(abs_path: str, new_text: str, root: str = None,
               expected_input: str = None, expected_fingerprint: str = None,
               ) -> tuple:
    """**唯一**的写回入口：路径边界 → **输入一致性复核** → 原子落盘。

    返回 (ok: bool, error: str)。

    ⚠️ **G02（v4 补正）——写入前内容冲突检查**：

    v3 的实现只做「路径边界校验 + 原子替换」，**不知道"已核验输入"是什么**：
    `compute_page()` 校验的是**它自己读到的**那一版内容，
    而 `write_page()` 替换的是**调用时刻**磁盘上的内容。
    两者之间若目标页被改动（用户编辑、外部工具、另一进程），
    v3 会**用旧内容生成的文本覆盖新内容**——用户修改被静默丢弃。

    故本函数新增两个**必填于真实写回路径**的参数：

      · `expected_input`      —— **已核验输入的原文**（`compute_page` 读到的
                                 那一份内容）。写回前**重新读取**目标文件，
                                 与它逐字节比对；不一致即**拒绝写入**。
      · `expected_fingerprint`—— 已核验输入的 sha256 指纹（`page_fingerprint`）。
                                 与 `expected_input` 二者至少提供一个；
                                 两者同时提供时**互相交叉校验**，
                                 防止调用方传入自相矛盾的期望值。

    ⚠️ **并发控制边界（不得仅靠"原子替换"宣称不覆盖并发修改）**：

    `os.replace()` 的原子性只保证「不会写出半截文件」，
    **不保证**「不会覆盖检查之后才发生的并发修改」——
    检查（TOCTOU）与替换之间存在窗口。

    ⚠️ **v5（G02 补正）——三道可验证的措施**：

      ① **强制独占锁**：锁**拿不到就拒绝写回**（不再"降级继续替换"），
         并区分三类原因——**锁被占用 / 锁机制不支持 / 其它异常**；
      ② **影子取证**：写回前用**硬链接**为标建立**同 inode 的影子**，
         替换后据此**证明**"替换瞬间发生过就地改写"，并把影子
         **原样换回**正式路径——用户字节**不丢失**。
         这是「替换后复验」**做不到**的：后置复验只能发现替换
         **之后**的改动，无法证明替换**之前**没有覆盖用户内容；
      ③ **安全输出**：机制覆盖不到时（例如文件系统不支持硬链接），
         **不覆盖正式目标**，把提议写入 `outputs/_pending/` 下的
         **安全产物**，交人工合并（正式目标零改动）。

    ⚠️ **剩余边界（诚实声明）**：
      · 影子取证覆盖**就地改写**（同一 inode 内改写）；
        对**改名覆盖型**写者（编辑器先写临时文件再改名替换），
        只能在**替换前**的 inode / 内容比对窗口内发现——
        比对与替换之间仍有**不可消除**的极短窗口
        （Windows 无"仅当内容未变才替换"的原子原语）。
        对这类页面请使用**安全输出**（`--write-pending`），
        以**完全不覆盖正式目标**的方式取得提议。
      · 锁仍是**协作式**的——**不遵守本协议**的写入者仍可能改写文件；
        但由 ② 提供的**取证 + 回滚**保证**用户字节不丢失**。
      · `expected_input` 未提供时**不做**已核验输入比对，
        真实写回路径**必须**提供（见 `main()`）。

    ⚠️ **G03：写入必须原子且失败可观察**——
      · **原子**：先写同目录临时文件 → `flush` + `fsync` → `os.replace()`
        原子替换目标文件，**不会出现「写了一半」的页面**；
      · **失败可观察**：任何一步失败都返回 `(False, 原因)`，
        并**清理临时文件**（不留垃圾），目标文件保持原状；
      · 临时文件与目标**同目录**，保证 `os.replace` 不跨文件系统。
    """
    real, rel, err = resolve_write_path(abs_path, root)
    if err:
        return False, err

    # ── ① 强制独占锁：**拿不到锁就拒绝写回**（不降级继续替换）──
    #    `_acquire_target_lock_ex` 区分三类失败原因：
    #    锁被占用 / 锁机制不受支持 / 其它异常。
    lock_fp, lock_reason = _acquire_target_lock_ex(real)
    if lock_fp is None:
        return False, ("写回锁失败（%s）：%s——**未做任何写入**，"
                       "目标文件保持原样；请稍后重试或检查该文件是否正被占用"
                       % (lock_reason, _LOCK_REASON_DETAIL.get(
                           lock_reason, "未知原因")))
    tmp_path = None
    shadow_path = None
    displaced_path = None
    displaced_moved = False
    write_completed = False
    try:
        # ── ② 锁内复核：当前磁盘内容必须仍等于**已核验输入** ──
        #    （锁在库根outputs/_runtime/write-locks的独立锁文件上，故目标文件可自由读取；
        #      遵守本协议的其它写者被同一把锁串行化）
        conflict = _verify_input_unchanged(real, expected_input,
                                           expected_fingerprint)
        if conflict:
            return False, conflict

        d = os.path.dirname(real)
        base = os.path.basename(real)

        # ── ③ 建立**影子硬链接**：与目标同一 inode ──
        #    影子存在的唯一目的：在替换**之后**仍能读到"替换瞬间"的字节，
        #    从而**证明**窗口内是否发生过就地改写，并把用户字节原样换回。
        #    （「替换后复验」只能读到自己写的新文本，**看不到**被覆盖的旧字节。）
        shadow_path = _make_shadow(real, d, base)
        if shadow_path is None:
            # 文件系统不支持硬链接 ⇒ 影子取证不可用。
            # 此时**不覆盖正式目标**，改为安全输出（见 `write_page_pending`）。
            return False, ("写回保护不可用：无法为该文件建立取证影子"
                           "（文件系统不支持硬链接）——**未覆盖正式目标**，"
                           "请改用安全输出模式（--write-pending）取得提议")
        shadow_before = _read_text(shadow_path)
        # 让位副本：旧目标被移出时暂存其 inode 的位置
        # 恢复副本集中存储；唯一名称避免覆盖上一次冲突证据。
        try:
            recovery_dir = _write_aux_dir(real, "recovery")
            fd, displaced_path = tempfile.mkstemp(
                prefix=hashlib.sha256(os.path.normcase(real).encode("utf-8")).hexdigest() + ".",
                suffix=".displaced", dir=recovery_dir)
            os.close(fd)
        except OSError as exc:
            return False, "无法准备恢复副本（未覆盖正式目标）：%s" % exc

        try:
            # ── ④ 写临时文件 ──
            fd, tmp_path = tempfile.mkstemp(
                prefix="." + base + ".", suffix=".tmp", dir=d)
            with os.fdopen(fd, "w", encoding="utf-8", newline="") as f:
                f.write(new_text)
                f.flush()
                os.fsync(f.fileno())

            # ── ④a **移出前**的最后一道取证 ──
            #   影子与目标同 inode：此刻对目标的就地改写会**同步**落在
            #   影子上。此处比对，即可在**移出之前**发现"用户刚刚改过"，
            #   此时用户内容仍在原路径上，**无需任何恢复动作**。
            if _read_text(shadow_path) != shadow_before:
                return False, ("写回冲突：检测到目标在**复核与替换之间**被就地改写，"
                               "本次写入已**撤销**——你的内容保持原样，"
                               "未写入任何字段；请重新执行")

            # ── ④b **移出旧目标**（原子），把目标路径"让"出来 ──
            #   为什么不能直接 os.replace(tmp, real)？
            #   因为那样一旦用户在窗口内改写文件，他们的字节会被本次
            #   替换**清掉**且**无从恢复**（实测：替换后目标 inode
            #   == tmp inode，被覆盖的旧字节已不可读）。
            #
            #   移出（os.replace(real, displaced)）把"替换瞬间目标上的
            #   确切字节"完整搬到让位副本里 ⇒
            #     · 用户在窗口内的**就地改写** ⇒ 改的是旧 inode ⇒
            #       改动随 inode 一起进入让位副本 ⇒ **可取回**；
            #     · 用户在窗口内**改名覆盖** ⇒ 其新文件落在路径上，
            #       此时路径非空 ⇒ 可检出并**不覆盖**它。
            #   移出本身是原子的 rename 语义，不产生"半截文件"。
            os.replace(real, displaced_path)
            displaced_moved = True
            try:
                # 移出后目标路径应为空；若已被占用 ⇒ 用户改名覆盖抢先
                if os.path.exists(real):
                    # 用户的新文件在此 ⇒ 中止，**不覆盖**它
                    #   （其内容完好；旧内容留在让位副本中供比对）
                    return False, ("写回冲突：目标在**复核与替换之间**被"
                                   "**整体替换**（改名覆盖），本次写入已**撤销**"
                                   "——未覆盖你的新文件，未写入任何字段；"
                                   "请重新执行")
                os.replace(tmp_path, real)
                tmp_path = None
            except OSError as exc:
                # 落位失败 ⇒ 把旧内容放回原处，绝不让目标消失
                try:
                    if not os.path.exists(real):
                        os.replace(displaced_path, real)
                        displaced_path = None
                        displaced_moved = False
                except OSError:
                    pass
                return False, ("写入失败（已保留原内容）：%s" % exc)
        except OSError as exc:
            # 移出阶段失败（目标可能已被删除/改名占用）⇒ 旧内容仍在原处
            try:
                if displaced_moved and displaced_path \
                        and os.path.exists(displaced_path) \
                        and not os.path.exists(real):
                    os.replace(displaced_path, real)
                    displaced_path = None
                    displaced_moved = False
            except OSError:
                pass
            return False, "写入失败（已保留原内容）：%s" % exc
        finally:
            # 失败路径：清理临时文件（成功路径 tmp_path 已为 None）
            if tmp_path and os.path.exists(tmp_path):
                try:
                    os.remove(tmp_path)
                except OSError:
                    pass

        # ── ⑤ 取证：让位副本里的字节是否被窗口内的写者改过？ ──
        #    让位副本承载"替换瞬间目标上的**确切字节**"：
        #      · 若它 ≠ 复核时的内容 ⇒ 用户在窗口内**就地改写**了文件；
        #        他们的字节完整保留在让位副本里 ⇒ **原样换回**正式路径，
        #        用户内容**不丢失**（这正是「替换后复验」做不到的：
        #        后置复验只能读到自己写的新文本，看不到被覆盖的旧字节）。
        #      · 若它读不到 ⇒ 旧 inode 在窗口内被删除。
        if displaced_moved and displaced_path:
            displaced_text = _read_text(displaced_path)
            if displaced_text is None:
                # 旧 inode 在窗口内被删除 ⇒ 我们不得凭空重建页面
                if os.path.exists(real):
                    try:
                        os.remove(real)
                    except OSError:
                        pass
                return False, ("写回冲突：目标在**复核与替换之间**被删除，"
                               "本次写入已**撤销**（未重建文件）——"
                               "未写入任何字段，请重新执行")
            if displaced_text != shadow_before:
                # 用户在窗口内就地改写 ⇒ 把让位副本换回正式路径（用户字节原样恢复）
                try:
                    os.replace(displaced_path, real)
                    displaced_path = None
                    displaced_moved = False
                    return False, ("写回冲突：检测到目标在**复核与替换之间**被就地改写，"
                                   "本次写入已**撤销并恢复你的内容**——"
                                   "未写入任何字段，请重新执行")
                except OSError as exc:
                    return False, ("写回冲突：检测到目标在复核与替换之间被就地改写，"
                                   "但恢复原内容失败：%s——需人工核查" % exc)

        # ── ⑥ 替换后复验：落盘内容须即**本次预期写入的文本**（可观察）──
        #    ⚠️ 注意：这里比对的**不是**「已核验输入」的指纹——
        #       已核验输入是**写回前**的旧内容，而落盘的是**写回后**的新内容，
        #       两者本就不同（核验字段已写入）。
        #       复验的目的是确认「落盘的正是我们打算写的那份」，
        #       若不等 ⇒ 说明替换后被第三方改写（并发覆盖）。
        if expected_input is not None or expected_fingerprint is not None:
            written = _read_text(real)
            if written is None:
                return False, ("写回后复验失败：目标文件已不可读，"
                               "可能已被并发删除或替换")
            if written != new_text:
                return False, (
                    "写回后复验失败：落盘内容与本次预期写入的文本不符"
                    "——疑似并发写入覆盖，需人工核查")
        write_completed = True
    finally:
        # 让位副本：旧目标被移出后的暂存位置（承载"替换瞬间的确切字节"）。
        #   · 正常路径：落位成功 ⇒ 目标已是新内容，让位副本删除即可。
        #   · 中止路径：目标路径被用户的新文件占用 ⇒ **不能**覆盖它；
        #     此时让位副本（= 用户的旧内容）须**保留**，供人工比对后合并。
        if displaced_moved and displaced_path and os.path.exists(displaced_path):
            try:
                if not os.path.exists(real):
                    # 目标为空 ⇒ 旧内容放回原处，绝不让页面消失
                    os.replace(displaced_path, real)
                    displaced_path = None
                    displaced_moved = False
                elif write_completed:
                    # 仅成功落盘且复验通过才清除旧副本；冲突证据保留在recovery。
                    os.remove(displaced_path)
            except OSError:
                pass
        elif displaced_path and os.path.exists(displaced_path):
            # 尚未移入旧内容的空占位文件。
            try:
                os.remove(displaced_path)
            except OSError:
                pass
        # 影子只用于取证：成功路径删除；失败路径若已换回则已消失。
        if shadow_path and os.path.exists(shadow_path):
            try:
                os.remove(shadow_path)
            except OSError:
                pass
        _release_target_lock(lock_fp)
    return True, ""


# ────────────────────────────────────────────────────────────
# G02（v5 补正）——安全输出（不覆盖正式目标）
# ────────────────────────────────────────────────────────────

#: 安全产物的目录名（相对库根）：提议写在这里，**正式目标零改动**
PENDING_DIR = os.path.join("outputs", "_pending")


def write_page_pending(abs_path: str, new_text: str, root: str = None,
                       reason: str = "") -> tuple:
    """**安全输出**：把拟写入内容落到 `outputs/_pending/` 下的**安全产物**，
    **完全不触碰正式目标**（正式目标字节不变）。

    返回 `(ok, error)`；`ok=True` 时 `error` 为安全产物的路径说明。

    ⚠️ **何时用这个通道**：
      · 目标处于**并发编辑**中、无法确认写入不会覆盖他人内容；
      · 文件系统不支持硬链接 ⇒ **影子取证不可用**，无法证明
        "替换前未覆盖用户内容"；
      · 人工选择"先出提议、后人工合并"。

    ⚠️ 产物**不进入 wiki 索引、不被门禁统计**（不在 `wiki/` 下，
    且不以 `.md` 结尾）。
    """
    real, rel, err = resolve_write_path(abs_path, root)
    if err:
        return False, err
    base_root = os.path.abspath(root if root is not None else ROOT)
    out_dir = os.path.join(base_root, PENDING_DIR)
    try:
        os.makedirs(out_dir, exist_ok=True)
    except OSError as exc:
        return False, "安全输出失败：无法创建 %s（%s）" % (out_dir, exc)
    # 产物名保留原相对路径（分隔符换成 __），便于回溯目标
    flat = rel.replace("/", "__").replace("\\", "__")
    out_path = os.path.join(out_dir, flat + ".pending")
    header = ""
    if reason:
        header = ("<!-- 安全产物：本次未覆盖正式目标。原因：%s -->\n"
                  % reason.replace("-->", "--&gt;"))
    tmp_path = out_path + ".tmp"
    try:
        with open(tmp_path, "w", encoding="utf-8", newline="") as f:
            f.write(header)
            f.write(new_text)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_path, out_path)
    except OSError as exc:
        try:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
        except OSError:
            pass
        return False, "安全输出失败：%s" % exc
    return True, out_path


# ────────────────────────────────────────────────────────────
# G02（v4 补正）——写回前内容冲突检查 + 并发控制
# ────────────────────────────────────────────────────────────

#: 写回冲突的**专有错误前缀**（供调用方与测试稳定识别）
CONFLICT_PREFIX = "写回冲突："

#: 锁获取失败的**三类原因**（供调用方与测试稳定识别）
LOCK_REASON_BUSY = "锁被占用"
LOCK_REASON_UNSUPPORTED = "锁机制不受支持"
LOCK_REASON_ERROR = "其它异常"

#: 三类锁失败原因的可读说明
_LOCK_REASON_DETAIL = {
    LOCK_REASON_BUSY: "该目标的独占锁已被另一个写者持有（并发写回中）",
    LOCK_REASON_UNSUPPORTED: "当前平台/文件系统不支持可靠的独占锁",
    LOCK_REASON_ERROR: "加锁时发生未预期异常",
}

#: 目标文件的**独占锁**在当前平台是否可用（None = 未知/未探测）
_LOCK_SUPPORTED = None


def _make_shadow(real: str, d: str, base: str):
    """为 `real` 建立**同 inode 的影子硬链接**，返回影子路径（失败为 None）。

    ⚠️ **为什么必须用硬链接（影子）而不是复制？**

    「替换后复验」只能读到**我们自己写的新文本**，因此**无法证明**
    "替换之前"用户的内容有没有被我们覆盖。影子链接则让**旧 inode**
    在替换之后依然可读：

      · 用户在窗口内**就地改写**（同一 inode 内 truncate+write）⇒
        影子内容随之变化 ⇒ **可检出**，并可把影子**原样换回**正式路径，
        用户字节**不丢失**（探针 P3/P5 实测：影子与目标同 inode，
        就地写入后影子同步变化；`os.replace(影子, 目标)` 可完整回滚）。
      · 用户**改名覆盖**（另写临时文件再 rename 过来）⇒ 影子仍是旧 inode，
        内容不变 ⇒ **检不出**。这是本机制**覆盖不到**的边界，
        故另设**安全输出**通道（`--write-pending`）作为不覆盖正式目标的选项。

    影子文件名为点号开头（`.<基名>.shadow`），不匹配 `*.md`，
    因此**不进入 wiki 索引、不被门禁统计**。
    """
    shadow = os.path.join(d, ".%s.shadow" % base)
    try:
        if os.path.exists(shadow):
            os.remove(shadow)
        os.link(real, shadow)
        return shadow
    except OSError:
        return None


def _write_aux_dir(real: str, kind: str) -> str:
    """锁与恢复证据置于库根outputs/_runtime；不污染wiki/draft正文目录。"""
    current = os.path.dirname(os.path.realpath(real))
    root = current
    probe = current
    while True:
        if os.path.basename(probe).lower() in ("wiki", "draft"):
            root = os.path.dirname(probe)
            break
        parent = os.path.dirname(probe)
        if parent == probe:
            break
        probe = parent
    folder = os.path.join(root, "outputs", "_runtime", kind)
    os.makedirs(folder, exist_ok=True)
    return folder


def _acquire_target_lock_ex(real: str):
    """取得同目录锁文件的独占锁，返回 `(handle, reason)`。

    `handle` 为 None 时，`reason` ∈ {LOCK_REASON_BUSY, LOCK_REASON_UNSUPPORTED,
    LOCK_REASON_ERROR}，供调用方**区分三类失败**并**拒绝写回**。

    ⚠️ **失败绝不降级**：v4 实现里锁失败只置 `_LOCK_SUPPORTED=False`
    就继续写回，等于"没锁也照写"——这正是 v5 审查指出的缺陷 1。
    v5 起，**锁拿不到 ⇒ 一律拒绝写回**，并按上述三类原因分别报告。

    ⚠️ **三类原因的判定口径**：
      · **锁被占用**：锁原语报告"冲突"（Windows `ERROR_LOCK_VIOLATION`
        / `EACCES`；POSIX `EWOULDBLOCK`/`EACCES`）——锁本身工作正常，
        只是**别人正持有**。
      · **锁机制不受支持**：平台无 `msvcrt`/`fcntl`，或锁原语返回
        "不支持/未实现"（`ENOSYS`/`ENOTSUP`/`EINVAL`）——锁**不可用**。
      · **其它异常**：以上都不是（IO 错误、权限错误等）。
    """
    global _LOCK_SUPPORTED
    if not os.path.isdir(os.path.dirname(real)):
        _LOCK_SUPPORTED = False
        return None, LOCK_REASON_ERROR
    try:
        # 固定锁路径长期保留，不能在每次解锁后删锁导致inode互斥失效。
        lock_dir = _write_aux_dir(real, "write-locks")
        key = hashlib.sha256(os.path.normcase(os.path.realpath(real)).encode("utf-8")).hexdigest()
        lock_path = os.path.join(lock_dir, key + ".lock")
    except OSError:
        _LOCK_SUPPORTED = False
        return None, LOCK_REASON_ERROR
    try:
        if os.name == "nt":
            import msvcrt
        else:
            import fcntl
    except ImportError:
        # 平台无锁原语 ⇒ 机制不受支持
        _LOCK_SUPPORTED = False
        return None, LOCK_REASON_UNSUPPORTED
    try:
        fp = open(lock_path, "a+b")
    except OSError:
        # 打不开锁文件：可能是目录不可写等 ⇒ 其它异常
        _LOCK_SUPPORTED = False
        return None, LOCK_REASON_ERROR
    try:
        if os.name == "nt":
            if fp.seek(0, os.SEEK_END) == 0:
                fp.write(b"0")
                fp.flush()
            fp.seek(0)
            msvcrt.locking(fp.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            fcntl.flock(fp.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError as exc:
        try:
            fp.close()
        except OSError:
            pass
        _LOCK_SUPPORTED = False
        # 冲突类错误码：Windows 上 msvcrt.locking 锁冲突报 EACCES(13)，
        # 同一进程二次加锁同样如此（探针 P2/P9 实测）。
        if getattr(exc, "errno", None) in (errno.EACCES, errno.EAGAIN,
                                           errno.EDEADLK):
            return None, LOCK_REASON_BUSY
        if getattr(exc, "errno", None) in (errno.ENOSYS, errno.ENOTSUP,
                                           errno.EINVAL):
            return None, LOCK_REASON_UNSUPPORTED
        return None, LOCK_REASON_ERROR
    _LOCK_SUPPORTED = True
    return ("msvcrt" if os.name == "nt" else "fcntl", fp, lock_path), None


def _read_text(path: str):
    """读取目标文件文本（与 `compute_page` 同样的容错与换行口径）。

    ⚠️ 换行归一：文本模式读取本身已把 `\r\n` 归一为 `\n`
    （Python 通用换行）；此处再显式归一一次 `\r`，
    确保与 `_read_text_from_handle()`（原始字节路径）**完全同口径**，
    避免同一文件两处读出不同文本而把合法写回误判为冲突。
    """
    try:
        with open(path, encoding="utf-8", errors="ignore") as f:
            return f.read().replace("\r\n", "\n").replace("\r", "\n")
    except OSError:
        return None


def _acquire_target_lock(real: str):
    """取得**库根运行目录锁文件**的独占锁（跨平台尽力而为），返回句柄。

    返回 `(kind, fp)`；`None` 表示**未能加锁**（并发保证更弱）。

    ⚠️ **为什么锁「锁文件」而不是「目标文件」本身？**
      Windows 的 `msvcrt.locking` 是**强制锁**：加锁期间**其它句柄**
      无法打开该文件。若直接锁目标文件，则：
        · 复核阶段另开句柄读会被自己的锁挡住（`Permission denied`），
          表现为「文件不存在」的假冲突；
        · **`os.replace()` 本身也会被锁挡住**（`WinError 5` 拒绝访问）——
          即「为了并发安全而加的锁，反过来使正常写回无法进行」。
      故：锁**库根运行目录的独立锁文件**（按规范化目标路径的SHA256命名），
      目标文件本身**不加锁**，从而：
        · 锁内可自由读取目标文件做复核；
        · `os.replace()` 不受阻挡；
        · 遵守本协议的其它写者会在同一把锁上串行化。

    ⚠️ 锁的语义：
      · **Windows**（`msvcrt.locking`）：对锁文件首字节加 `LK_NBLCK` 独占锁；
        已被他人以不兼容方式打开时**立即失败**（不阻塞）——
        这是刻意的：宁可不写、明确报告，也不要在拿不到锁时盲写。
      · **POSIX**（`fcntl.flock`）：`LOCK_EX | LOCK_NB` 非阻塞独占锁。
      · 两者都是**协作式**锁：只有**同样遵守本协议**的写者才会被串行化。

    ⚠️ **v5**：本函数**不再吞掉失败原因**——调用方若需区分
    「锁被占用 / 锁机制不受支持 / 其它异常」，请改用
    `_acquire_target_lock_ex()`（返回 `(handle, reason)`）。
    写回路径（`write_page`）已改用该函数，**拿不到锁即拒绝写回**。
    """
    handle, _reason = _acquire_target_lock_ex(real)
    return handle


def _release_target_lock(handle) -> None:
    """释放 `_acquire_target_lock()` 取得的锁（幂等）。

    ⚠️ 锁文件本身**保留**在磁盘上（内容恒为单字节 `0`）：
    删除锁文件会引入「另一写者正锁着旧 inode、而我新建了新 inode」的竞态，
    反而破坏互斥。故只释放锁、**不删文件**。
    锁文件集中在 outputs/_runtime/write-locks，不参与 wiki 索引与门禁。
    """
    if not handle:
        return
    kind, fp = handle[0], handle[1]
    try:
        if kind == "msvcrt":
            import msvcrt
            try:
                fp.seek(0)
                msvcrt.locking(fp.fileno(), msvcrt.LK_UNLCK, 1)
            except OSError:
                pass
        else:
            import fcntl
            try:
                fcntl.flock(fp.fileno(), fcntl.LOCK_UN)
            except OSError:
                pass
    except Exception:
        pass
    try:
        fp.close()
    except OSError:
        pass


def _verify_input_unchanged(real: str, expected_input, expected_fingerprint):
    """复核：目标文件当前内容是否仍等于**已核验输入**。

    返回 `None` = 一致，可以写回；返回**非空字符串** = 冲突原因（应拒绝写入）。

    ⚠️ 覆盖的冲突类型：
      · **文件已被删除** —— 目标不存在；
      · **文件已被替换** —— 内容与已核验输入不同（含被整体替换为另一版本）；
      · **内容已被修改** —— 指纹与已核验输入不同。

    ⚠️ 换行口径：读取经 `_read_text()` 归一（`\r\n`/`\r` → `\n`），
       与 `compute_page` 的文本模式读取一致，
       故同一文件的两次读出结果相同 ⇒ 合法写回不会被误判为冲突。
    """
    if expected_input is None and expected_fingerprint is None:
        return None
    current = _read_text(real)
    if current is None:
        return (CONFLICT_PREFIX +
                "目标文件已不存在（删除或被移走），无法确认其仍与已核验输入一致"
                "——已保留磁盘现状，未写入任何字段")
    if expected_fingerprint:
        cur_fp = MR.page_fingerprint(current)
        if cur_fp != expected_fingerprint:
            return (CONFLICT_PREFIX +
                    "目标文件内容已被修改（当前指纹 %r ≠ 已核验输入指纹 %r）"
                    "——已保留你当前的修改，未写入任何字段"
                    % (cur_fp[:16], expected_fingerprint[:16]))
        if expected_input is not None and current != expected_input:
            return (CONFLICT_PREFIX +
                    "目标文件内容与已核验输入不一致——已保留你当前的修改，"
                    "未写入任何字段")
    elif current != expected_input:
        return (CONFLICT_PREFIX +
                "目标文件内容已被修改（与已核验输入不一致）"
                "——已保留你当前的修改，未写入任何字段")
    return None


# ────────────────────────────────────────────────────────────
# main
# ────────────────────────────────────────────────────────────

def main() -> int:
    ap = argparse.ArgumentParser(description="元数据自动赋值入口（默认 dry-run）")
    ap.add_argument("--page", help="单页相对路径（如 wiki/01-labor/terms/x.md）")
    ap.add_argument("--scan", help="目录路径，批量预览（不写回）")
    ap.add_argument("--source-result", required=True,
                    help="真实来源查询结果 JSON 文件路径")
    ap.add_argument("--write", action="store_true",
                    help="显式写回（仅与 --page 同用；默认 dry-run）")
    ap.add_argument("--write-pending", action="store_true",
                    help="**安全输出**：把拟写入内容落到 outputs/_pending/ 下的"
                         "安全产物，**不覆盖正式目标**，交人工合并"
                         "（用于目标正被并发编辑、或无法取证影子时）")
    ap.add_argument("--publish-result",
                    help="实际发布结果 JSON（ingest_ok/index_ok/tech_gate_ok/"
                         "human_reviewed）；不提供则按「已在 wiki 正式库」推定前三项成功")
    ap.add_argument("--csv", help="把逐页对照写成 CSV（用于迁移预演）")
    ap.add_argument("--root",
                    help="库根覆盖（**仅供隔离验证**：把 --root 指向一个"
                         "含 wiki/ 的临时目录，即可在副本上真实写回而不"
                         "触碰正式库；路径边界校验仍以该 root 为准）")
    args = ap.parse_args()

    root = os.path.abspath(args.root) if args.root else ROOT

    publish_result = None
    if args.publish_result:
        try:
            publish_result = json.load(open(args.publish_result, encoding="utf-8"))
        except Exception as exc:
            print("错误：读取 --publish-result 失败：%s: %s"
                  % (type(exc).__name__, exc), file=sys.stderr)
            return 2

    try:
        sr = json.load(open(args.source_result, encoding="utf-8"))
    except Exception as exc:
        print("错误：读取 --source-result 失败：%s: %s" % (type(exc).__name__, exc),
              file=sys.stderr)
        return 2

    if not args.page and not args.scan:
        print("错误：必须给 --page 或 --scan 之一", file=sys.stderr)
        return 2
    if args.write and not args.page:
        print("错误：--write 只能与 --page 同用（批量写回不在本轮授权范围）",
              file=sys.stderr)
        return 2
    if args.write_pending and not args.page:
        print("错误：--write-pending 只能与 --page 同用",
              file=sys.stderr)
        return 2

    targets = []
    if args.page:
        targets = [args.page]
    else:
        scan_root = (args.scan if os.path.isabs(args.scan)
                     else os.path.join(root, args.scan))
        targets = sorted(glob.glob(os.path.join(scan_root, "**", "*.md"),
                                    recursive=True))

    rows = []
    errors = []
    for t in targets:
        r, err = compute_page(t, sr, publish_result, root=root)
        if err:
            errors.append(err)
            continue
        rows.append(r)

    # ── 输出 ──
    print("=" * 74)
    print("元数据自动赋值入口 | 模式：%s | 目标 %d 页"
          % ("WRITE（单页）" if args.write else "DRY-RUN（不写文件）", len(targets)))
    print("规则版本：%s（%s）" % (MR.RULE_VERSION, MR.RULE_TASK_ID))
    print("来源路由：法规 %s ｜ 案例 %s"
          % (" → ".join(MR.SOURCE_ROUTES["法规"]),
             " → ".join(MR.SOURCE_ROUTES["案例"])))
    print("=" * 74)

    n_changed = 0
    n_override = 0
    for r in rows:
        if r["changed_fields"]:
            n_changed += 1
        if r["override_conflicts"]:
            n_override += 1
        if args.write:
            continue
        print("\n· %s" % r["path"])
        for k in WRITABLE_KEYS:
            o, n = r["old"].get(k, ""), r["new"].get(k, "")
            if o != n:
                print("    %-18s %r → %r" % (k, o, n))
        for f, b in r["basis"].items():
            print("    依据[%s] %s" % (f, b))
        for c in r["override_conflicts"]:
            print("    ⚠ 人工覆盖冲突：%s" % c["basis"])
        for g in r["gaps"]:
            print("    ⚠ 缺口：%s" % g)

    print("\n" + "-" * 74)
    print("共 %d 页｜拟改字段有变化的 %d 页｜含人工覆盖冲突 %d 页｜解析失败 %d 页"
          % (len(rows), n_changed, n_override, len(errors)))
    for e in errors:
        print("  ✘ %s" % e)

    # ── 写回（仅单页且显式 --write / --write-pending）──
    if (args.write or args.write_pending) and rows:
        r = rows[0]
        updates = {}
        for k in WRITABLE_KEYS:
            if r["old"].get(k, "") != r["new"].get(k, ""):
                updates[k] = r["new"][k]
        # 人工覆盖的字段一律不写回
        for f in r["manual_overrides"]:
            updates.pop(f, None)
        # ── F06：来源证据与状态/来源/日期**一致保存** ──
        vr_new = r.get("verify_record_new")
        if vr_new:
            updates["verify_record"] = vr_new

        # ── G03：**核验未成立 → 本次写回一律不落任何字段** ──
        #   「本页核验成功」= 查询成功 ∧ 绑定通过 ∧ 证据完整且一致。
        #   任一不成立 → status / verified_at / verify_source / verify_record
        #   一律不得落盘（原文件保持不变）。
        #
        #   ⚠️ 通知原文：「未成功则原有文件保持不变或仅明确降为待核实，
        #      不保存新来源/核验日期/残缺证据」；且「写入必须原子且失败可观察，
        #      避免部分成功」。
        #   ⚠️ 故此处**不做任何部分写回**（连 review_status 也不写）——
        #      否则会出现「只写了发布状态、却把核验状态留在旧值」的
        #      **部分成功**，与通知要求相悖。
        if not r.get("page_verified"):
            print("\n⚠️ 本页核验未成立（查询/绑定/证据未全部通过）→ "
                  "**本次写回一律不落任何字段**"
                  "（status / verified_at / verify_source / verify_record "
                  "及 review_status 均保持原值，原文件不变）。")
            for g in r["gaps"]:
                print("    ⚠ 缺口：%s" % g)
            print("写回：核验未成立——**文件未被改动**。", file=sys.stderr)
            return 4

        if not updates:
            print("\n写回：无可写字段（拟改值与现值一致，或命中人工覆盖）——未改动文件。")
            return 0
        try:
            new_text = apply_to_text(r["text"], r["fm"], updates)
        except RuntimeError as exc:
            print("写回失败：%s" % exc, file=sys.stderr)
            return 1
        abs_p = os.path.join(root, r["path"])
        # ── G02（v5 补正）：**安全输出**通道 ──
        #   `--write-pending`：**不覆盖正式目标**，把拟写入内容落到
        #   `outputs/_pending/` 下的安全产物，交人工合并。
        #   用于「目标正在被并发编辑」或「影子取证不可用」等
        #   无法证明"写入不会覆盖他人内容"的场合。
        if args.write_pending:
            ok_p, res_p = write_page_pending(
                abs_p, new_text, root=root,
                reason="按 --write-pending 要求生成安全产物，未覆盖正式目标")
            if not ok_p:
                print("安全输出失败：%s" % res_p, file=sys.stderr)
                return 3
            print("\n✅ 安全产物已生成（**正式目标未被改动**）：%s" % res_p)
            print("   请人工比对待合并内容后，再决定是否应用到正式页面。")
            return 0
        # ── G02（v4 补正）：把**已核验输入**传给写回层 ──
        #   `r["verified_input"]` 是 compute_page 实际读到并据以校验的那份原文；
        #   `r["verified_fingerprint"]` 是它的 sha256。
        #   写回层在**替换前**重新读取目标文件并复核二者是否仍一致——
        #   不一致（被修改 / 被删除 / 被替换）即拒绝写入、保留用户当前文件。
        #   v5 追加：**影子取证**（硬链接）——替换后据此证明窗口内是否发生
        #   过就地改写，并可把用户字节**原样换回**。
        ok, err = write_page(abs_p, new_text, root=root,
                             expected_input=r.get("verified_input"),
                             expected_fingerprint=r.get("verified_fingerprint"))
        if not ok:
            print("写回被拒绝：%s" % err, file=sys.stderr)
            print("文件未被改动。", file=sys.stderr)
            if err.startswith(CONFLICT_PREFIX):
                # 写回冲突 → 专有退出码，便于调用方与自动化区分
                print("⚠️ 目标文件在核验之后发生了变更，已**保留你当前的内容**，"
                      "未写入任何核验成功字段；请重新执行以基于最新内容核验。",
                      file=sys.stderr)
                return 5
            if err.startswith("写回锁失败"):
                # v5：锁失败 → 专有退出码（区别于内容冲突 rc=5）
                print("⚠️ 未获取到该目标的独占锁，**未做任何写入**；"
                      "请确认无并发写回后重试。", file=sys.stderr)
                return 6
            if err.startswith("写回保护不可用"):
                # v5：影子取证不可用 → 建议改用安全输出
                print("⚠️ 无法建立取证影子，**未覆盖正式目标**；"
                      "可改用 --write-pending 生成安全产物。", file=sys.stderr)
                return 7
            return 3
        print("\n已写回：%s（改动字段：%s）" % (r["path"], "、".join(updates)))
        print("⚠️ 未改动 last_verified（人工核验日期，AI 不填）；"
              "raw/ 与 id 均未触碰。")

    # ── CSV 导出 ──
    if args.csv:
        out = args.csv if os.path.isabs(args.csv) else os.path.join(root, args.csv)
        with open(out, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.writer(f)
            w.writerow(["页面路径", "字段", "旧值", "拟改值", "依据",
                        "人工覆盖", "覆盖冲突", "缺口"])
            for r in rows:
                for k in WRITABLE_KEYS:
                    o, n = r["old"].get(k, ""), r["new"].get(k, "")
                    if o == n:
                        continue
                    w.writerow([
                        r["path"], k, o, n,
                        r["basis"].get(k, ""),
                        "是" if k in r["manual_overrides"] else "否",
                        "是" if r["override_conflicts"] else "否",
                        "；".join(r["gaps"]),
                    ])
        print("\nCSV 已写出：%s" % out)

    return 0


if __name__ == "__main__":
    from _auto_meta_v5 import main as v5_main
    sys.exit(v5_main())
