"""Publish explicit pages/directories/manifests. Preview unless --write is supplied."""
from pathlib import Path
import argparse,json
from _paths import ROOT
import _knowledge_policy as K
from _publication import publish_page

def main():
    ap=argparse.ArgumentParser(description=__doc__);g=ap.add_mutually_exclusive_group(required=True)
    g.add_argument('--page');g.add_argument('--directory');g.add_argument('--manifest')
    ap.add_argument('--basis',required=True,help='真实作者操作/批次批准依据')
    ap.add_argument('--write',action='store_true');ap.add_argument('--accept-revision',action='store_true')
    ap.add_argument('--withdraw',action='store_true');ap.add_argument('--report',default='lint-reports/发布回执.md');a=ap.parse_args();root=Path(ROOT)
    if a.manifest:
        entries=json.loads((root/a.manifest).read_text(encoding='utf-8'));entries=entries.get('pages',[]) if isinstance(entries,dict) else entries
        paths=[root/(x['path'] if isinstance(x,dict) else x) for x in entries]
    else:
        target=root/(a.page or a.directory);paths=[target] if a.page else sorted(target.rglob('*.md'))
    rows=[]
    for p in paths:
        try:
            p=p.resolve()
            if not p.is_relative_to((root/'wiki').resolve()):raise ValueError('仅允许wiki范围')
            d,b=K.read_raw(p.read_text(encoding='utf-8-sig'));r=K.page_record(d['id'])
            if not a.withdraw and K.usable_gate(d)[0]:rows.append((d['id'],'已发布可检索（保持）'));continue
            if not a.write:
                from _publication import prepare
                prepare(d,b,r,a.basis,'withdraw' if a.withdraw else 'publish',a.accept_revision)
                rows.append((d['id'],'可执行；预览未写入'));continue
            publish_page(p,a.basis,root,a.accept_revision,'withdraw' if a.withdraw else 'publish')
            rows.append((d['id'],'已撤回' if a.withdraw else '已发布可检索'))
        except Exception as e:rows.append((str(p),'失败：'+str(e)))
    out=root/a.report;out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text('# 发布回执\n\n模式：'+('写入' if a.write else '预览')+'\n\n| 页面 | 结果 |\n| --- | --- |\n'+'\n'.join('| '+i+' | '+s.replace('|','/')+' |' for i,s in rows)+'\n',encoding='utf-8',newline='\n')
    failed=sum(s.startswith('失败') for _,s in rows);print('处理',len(rows),'页；失败',failed,'；回执',out)
    return bool(failed)
if __name__=='__main__':raise SystemExit(main())
