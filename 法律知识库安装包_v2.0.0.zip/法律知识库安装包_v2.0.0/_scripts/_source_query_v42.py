# -*- coding: utf-8 -*-
"""_source_query.py —— **真实来源查询执行器**（RULE-20261025-001 v2 补正 F06）

**为什么需要这个模块（Codex v1 的 F06 缺口）**：

v1 的 `_auto_meta.py` 只是「消费调用者提供的 source-result JSON」——
入口本身**不执行任何真实查询**，来源路由 `SOURCE_ROUTES` 只是一组常量。
于是形成如下缺口：

    「真实查询 → 目标版本/条款匹配 → 来源证据写回」

这条链路**没有任何运行证明**。补正通知要求：
「公开资料做一例真实来源流程验证」「不能把模拟当联网结果」。

**本模块就是那条链路的执行端**：

  ① `query_flk_npc()` —— 对国家法律法规数据库（flk.npc.gov.cn）**发起真实
     HTTP 请求**（搜索 + 详情），取得真实的效力事实（`sxx`）、版本信息
     （`gbrq`/`sxrq`）、条号目录树；
  ② `match_target()` —— 把查询结果与**目标页面声明的**对象/版本/条款
     **逐项比对**，不一致即判「不匹配」（不写成功）；
  ③ `build_source_result()` —— 产出**符合 `validate_source_result()` 契约**
     的 source-result JSON（含 `verify_record` 证据），供 `_auto_meta.py`
     消费与写回。

**红线**：
  · 本模块**只读**远端 + **只写**自己指定的输出 JSON 文件；
  · **不改**任何 wiki 页面（写回由 `_auto_meta.py` 统一入口执行）；
  · **不**把模拟数据当作联网结果——任何一步失败都如实记录 `query_ok=false`
    与失败原因，绝不构造「看起来成功」的假证据；
  · `verified_at` 取**真实核验当日**（查询执行日），**不得**用编译时间冒充。

用法：

    # 对一个目标页执行真实查询，产出 source-result JSON
    python _scripts/_source_query.py \
        --page wiki/01-labor/terms/劳动合同法第30条-工资支付与支付令.md \
        --out _work_temp/_source_result_flk.json

    # 只查不写（dry-run，打印将要产出的内容）
    python _scripts/_source_query.py --title 中华人民共和国劳动合同法 --dry-run
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import re
import sys
import urllib.parse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _paths import ROOT  # noqa: E402
import _meta_rules as MR  # noqa: E402


# ────────────────────────────────────────────────────────────
# 远端来源标识与常量（**必须与 rules.md 的来源口径一致**）
# ────────────────────────────────────────────────────────────

#: 法规首选来源（rules.md：法规先 flk-npc）
LAW_SOURCE = MR.SOURCE_LAW_FIRST          # 'flk-npc'

#: flk-npc 的 API 基址与端点
FLK_BASE = "https://flk.npc.gov.cn/law-search/"
FLK_SEARCH_PATH = "search/list"
FLK_DETAIL_PATH = "search/flfgDetails"

#: flk `sxx`（时效性）→ 本库 status 口径
#: 依据 `references/05-flk-api-reference.md`：3=现行有效, 2=已修改,
#: 1=已废止, 4=尚未生效
SXX_MAP = {
    3: "现行有效",
    2: "已修改",
    1: "已废止",
    4: "尚未生效",
}

#: 可公开引用的 flk **详情 API** URL 模板
#:
#: ⚠️ 实测说明（2026-10-25）：`https://flk.npc.gov.cn/detail2.html?<base64>`
#:    返回的是前端 SPA 空壳（552 字节的 HTML，条文内容由 JS 异步加载），
#:    **不能**作为可定位的证据地址；
#:    而 `GET /law-search/search/flfgDetails?bbbs=<id>` **实测返回 200 +
#:    application/json + 完整详情数据（17KB）**，是真实可定位的证据地址。
FLK_DETAIL_URL = FLK_BASE + "search/flfgDetails?bbbs=%s"


def flk_detail_url(bbbs: str) -> str:
    """生成 flk-npc 的详情证据 URL（可定位、可引用，实测 HTTP 200）。"""
    return FLK_DETAIL_URL % urllib.parse.quote(bbbs or "", safe="")


def strip_highlight(s: str) -> str:
    """去掉搜索结果标题里的 `<em class='highlight'>` 包裹。"""
    return re.sub(r"<[^>]+>", "", s or "")


# ────────────────────────────────────────────────────────────
# ① 真实查询（flk-npc）
# ────────────────────────────────────────────────────────────

def _flk_client():
    """载入 flk-npc MCP 的 HTTP 客户端（**不启动 MCP server**，直接复用其
    API 协议，保证与 MCP 工具完全一致的请求语义）。"""
    here = os.path.dirname(os.path.abspath(__file__))
    candidates = [
        os.path.join(ROOT, "tools", "legal-tools", "国家法律法规数据库MCP",
                     "scripts"),
    ]
    for c in candidates:
        if os.path.isdir(c):
            if c not in sys.path:
                sys.path.insert(0, c)
            break
    try:
        from client import FlkClient  # type: ignore
        return FlkClient()
    except Exception as exc:
        raise RuntimeError("无法载入 flk-npc 客户端（client.py）：%s: %s"
                           % (type(exc).__name__, exc))


async def _query_flk_npc_async(title: str, *, sxx_filter=None,
                               page_size: int = 20,
                               retries: int = 3) -> dict:
    """对 flk-npc 发起**真实**搜索请求。

    返回 dict：
      · `ok`       —— 是否成功取得响应且 code=200
      · `rows`     —— 搜索结果行
      · `error`    —— 失败原因（成功时为 ""）

    ⚠️ flk-npc 偶发 ReadTimeout（实测：同一请求首次超时时重试即成功），
    故此处做**有限次重试**（默认 3 次，退避 1.5s/3s）；
    重试全部失败才如实报失败——**绝不**构造假结果。
    """
    client = _flk_client()
    body = {
        "searchContent": title,
        "searchType": 1,          # 1=精确匹配标题
        "searchRange": 1,         # 1=标题
        "flfgCodeId": [],
        "zdjgCodeId": [],
        "gbrqYear": [],
        "sxx": ([sxx_filter] if sxx_filter is not None else []),
        "orderByParam": {"order": "", "sort": ""},
        "pageNum": 1,
        "pageSize": page_size,
    }
    last_err = ""
    try:
        for attempt in range(retries):
            try:
                resp = await client.post(FLK_SEARCH_PATH, body)
            except Exception as exc:
                last_err = "%s: %s" % (type(exc).__name__, exc)
                if attempt + 1 < retries:
                    await asyncio.sleep(1.5 * (attempt + 1))
                    continue
                return {"ok": False, "rows": [], "error":
                        "flk-npc 搜索请求失败（重试 %d 次均失败）：%s"
                        % (retries, last_err)}
            if not isinstance(resp, dict) or resp.get("code") != 200:
                return {"ok": False, "rows": [], "error":
                        "flk-npc 返回异常：code=%r msg=%r"
                        % (resp.get("code") if isinstance(resp, dict) else None,
                           resp.get("msg") if isinstance(resp, dict) else None)}
            return {"ok": True, "rows": resp.get("rows") or [], "error": "",
                    "total": resp.get("total")}
    finally:
        try:
            await client.close()
        except Exception:
            pass
    return {"ok": False, "rows": [], "error":
            "flk-npc 搜索请求失败：%s" % last_err}


async def _query_flk_detail_async(bbbs: str, retries: int = 3) -> dict:
    """对 flk-npc 发起**真实**详情请求（取得条号目录树与元数据）。

    ⚠️ 同搜索：偶发 ReadTimeout → 有限次重试，全部失败才报失败。
    """
    client = _flk_client()
    last_err = ""
    try:
        for attempt in range(retries):
            try:
                resp = await client.get("%s?bbbs=%s"
                                        % (FLK_DETAIL_PATH,
                                           urllib.parse.quote(bbbs)))
            except Exception as exc:
                last_err = "%s: %s" % (type(exc).__name__, exc)
                if attempt + 1 < retries:
                    await asyncio.sleep(1.5 * (attempt + 1))
                    continue
                return {"ok": False, "data": {}, "error":
                        "flk-npc 详情请求失败（重试 %d 次均失败）：%s"
                        % (retries, last_err)}
            if not isinstance(resp, dict) or resp.get("code") != 200:
                return {"ok": False, "data": {}, "error":
                        "flk-npc 详情返回异常：code=%r msg=%r"
                        % (resp.get("code") if isinstance(resp, dict) else None,
                           resp.get("msg") if isinstance(resp, dict) else None)}
            return {"ok": True, "data": resp.get("data") or {}, "error": ""}
    finally:
        try:
            await client.close()
        except Exception:
            pass
    return {"ok": False, "data": {}, "error":
            "flk-npc 详情请求失败：%s" % last_err}


def collect_clause_titles(content) -> set:
    """从 flk 详情 `content` 目录树中收集**全部条号节点标题**。

    实测：flk 详情树的条文层节点 `title` 就是「第N条」，
    且条文节点的 `children` 为空（正文需另行下载），故此处只做
    **条号存在性**核验，不谎称已比对条文正文。
    """
    out = set()
    stack = [content]
    while stack:
        n = stack.pop()
        if isinstance(n, dict):
            t = n.get("title")
            if isinstance(t, str) and re.match(r"^第[〇零一二三四五六七八九十百千"
                                               r"0-9]+条", t.strip()):
                out.add(t.strip())
            for ch in (n.get("children") or []):
                stack.append(ch)
        elif isinstance(n, list):
            stack.extend(n)
    return out


# ────────────────────────────────────────────────────────────
# ② 目标匹配（版本 / 条款 / 对象）
# ────────────────────────────────────────────────────────────

def _norm_date(s) -> str:
    s = str(s or "").strip()
    return s if re.match(r"^\d{4}-\d{2}-\d{2}$", s) else ""


def _page_expectations(fm: dict) -> dict:
    """从目标页 frontmatter 提取**待核验的期望值**。

    ⚠️ **G02：执行器与消费端同一真源**——
       本函数直接复用 `MR.page_expectations()`（消费端 `check_target_binding()`
       用的同一个函数），杜绝两处期望值口径分裂。
       本函数额外返回执行器内部用的 `expect_status`（页面声明的效力状态）。
    """
    exp = MR.page_expectations(fm)
    exp["expect_status"] = str((fm or {}).get("status") or "").strip()
    # 兼容旧字段名（执行器内部沿用）
    exp["expect_gbrq"] = exp.get("published", "")
    exp["expect_sxrq"] = exp.get("effective", "")
    return exp


def match_target(fm: dict, row: dict, detail: dict,
                 clause_set: set) -> dict:
    """把**真实查询结果**与**目标页声明**逐项比对。

    返回 dict：
      · `matched`   —— 布尔，全部硬性项都一致才为 True
      · `items`     —— 逐项比对明细 [{item, expected, actual, ok, note}]
      · `reason`    —— 不匹配的原因摘要（匹配时为 ""）
    """
    exp = _page_expectations(fm)
    items = []

    def add(item, expected, actual, ok, note=""):
        items.append({"item": item, "expected": expected, "actual": actual,
                      "ok": bool(ok), "note": note})

    # ① 对象（法规标题）：页面的 verify_record.object 去掉「第N条」后缀
    #    应与查询到的 title 一致
    obj = exp["object"]
    base_obj = re.sub(r"第[〇零一二三四五六七八九十百千0-9]+条.*$", "", obj).strip()
    actual_title = strip_highlight(str(row.get("title") or "")).strip()
    if base_obj:
        add("对象（法规标题）", base_obj, actual_title,
            base_obj == actual_title,
            "" if base_obj == actual_title else "标题不一致，不得写成功")
    else:
        add("对象（法规标题）", "（页面未声明）", actual_title, True,
            "页面未声明对象，不作标题硬性比对")

    # ② 效力状态：页面声明 vs 来源事实
    src_status = SXX_MAP.get(row.get("sxx"), "")
    if exp["expect_status"] and src_status:
        # 页面声明「已废止」而来源为「现行有效」→ 矛盾，必须报出
        ok = (exp["expect_status"] == src_status)
        add("效力状态", exp["expect_status"], src_status, ok,
            "" if ok else "页面声明与来源效力事实不一致，须人工判定")

    # ③ 版本：公布日期 / 施行日期
    gbrq = _norm_date(row.get("gbrq"))
    sxrq = _norm_date(row.get("sxrq"))
    if exp["expect_gbrq"]:
        add("公布日期", exp["expect_gbrq"], gbrq or "（来源未给出）",
            exp["expect_gbrq"] == gbrq,
            "" if exp["expect_gbrq"] == gbrq else "版本不一致")
    if exp["expect_sxrq"]:
        add("施行日期", exp["expect_sxrq"], sxrq or "（来源未给出）",
            exp["expect_sxrq"] == sxrq,
            "" if exp["expect_sxrq"] == sxrq else "版本不一致")

    # ④ 条款：条号必须在详情目录树中真实存在
    if exp["clauses"]:
        missing = [c for c in exp["clauses"] if c not in clause_set]
        add("条款存在性", "、".join(exp["clauses"]),
            ("全部命中" if not missing else "缺：" + "、".join(missing)),
            not missing,
            "" if not missing else "条号在官方目录树中不存在")
    else:
        add("条款存在性", "（页面未声明条号）", "—", True, "不作条号比对")

    # ⑤ 详情元数据一致性
    d_sxx = detail.get("sxx")
    if d_sxx is not None and row.get("sxx") is not None:
        add("详情时效性一致", "sxx=%s" % row.get("sxx"), "sxx=%s" % d_sxx,
            str(row.get("sxx")) == str(d_sxx), "")

    matched = all(i["ok"] for i in items)
    bad = [i for i in items if not i["ok"]]
    reason = "" if matched else "；".join(
        "%s：期望 %r ≠ 实际 %r" % (i["item"], i["expected"], i["actual"])
        for i in bad)
    return {"matched": matched, "items": items, "reason": reason,
            "expectations": exp}


# ────────────────────────────────────────────────────────────
# ③ 产出 source-result（符合 validate_source_result 契约）
# ────────────────────────────────────────────────────────────

def build_source_result(*, kind: str, query_ok: bool, effect_fact: str,
                        verify_source: str, verified_at: str, note: str,
                        target: dict = None, evidence: dict = None,
                        verify_record: dict = None,
                        source_ref: dict = None) -> dict:
    """构造 source-result dict（键严格落在 `SR_ALLOWED_KEYS` 内）。"""
    sr = {
        "kind": kind,
        "query_ok": bool(query_ok),
        "effect_fact": effect_fact or "",
        "verify_source": verify_source or "",
        "verified_at": verified_at or "",
        "note": note or "",
    }
    if target is not None:
        sr["target"] = target
    if evidence is not None:
        sr["evidence"] = evidence
    if verify_record is not None:
        sr["verify_record"] = verify_record
    if source_ref is not None:
        sr["source_ref"] = source_ref
    return sr


def run_query(page_path: str = None, title: str = None, *,
              law_title: str = None, clauses: list = None,
              dry_run: bool = False) -> dict:
    """执行一次**真实来源查询**并产出 source-result。

    · `page_path` —— 目标页（相对库根）；提供时从其 frontmatter 取期望值
    · `title`     —— 直接指定查询标题（覆盖从页面提取的标题）
    · `law_title` —— 页面未声明对象时，额外指定法规标题
    """
    fm = {}
    exp = {}
    page_text = ""
    page_id = ""
    if page_path:
        abs_p = (page_path if os.path.isabs(page_path)
                 else os.path.join(ROOT, page_path))
        try:
            with open(abs_p, encoding="utf-8") as f:
                text = f.read()
        except OSError as exc:
            return build_source_result(
                kind="法规", query_ok=False, effect_fact="",
                verify_source="", verified_at="",
                note="读取目标页失败：%s" % exc)
        # ⚠️ G02：绑定所需的**页面原文指纹**（page_id 在 frontmatter 解析后取）
        page_text = text
        m = re.match(r"^---\s*\r?\n(.*?)\r?\n---", text, re.S)
        if not m:
            return build_source_result(
                kind="法规", query_ok=False, effect_fact="",
                verify_source="", verified_at="",
                note="目标页没有 frontmatter，无法确定待核验对象")
        try:
            import yaml
            from _knowledge_policy import hydrate
            fm = hydrate(yaml.safe_load(m.group(1)) or {})
        except Exception as exc:
            return build_source_result(
                kind="法规", query_ok=False, effect_fact="",
                verify_source="", verified_at="",
                note="目标页 frontmatter 解析失败：%s: %s"
                     % (type(exc).__name__, exc))
        if not isinstance(fm, dict):
            return build_source_result(
                kind="法规", query_ok=False, effect_fact="",
                verify_source="", verified_at="",
                note="目标页 frontmatter 不是映射结构")
        page_id = str(fm.get("id") or "").strip()
        exp = _page_expectations(fm)

    # ── 确定查询标题 ──
    q_title = (title or law_title or "").strip()
    if not q_title:
        base_obj = re.sub(r"第[〇零一二三四五六七八九十百千0-9]+条.*$", "",
                           exp.get("object", "")).strip()
        q_title = base_obj
    if not q_title:
        return build_source_result(
            kind="法规", query_ok=False, effect_fact="",
            verify_source="", verified_at="",
            note="无法确定查询标题：既未给 --title/--law-title，"
                 "页面 verify_record.object 也未声明法规名")

    # ── ① 真实搜索 ──
    search = asyncio.run(_query_flk_npc_async(q_title))
    if not search["ok"]:
        return build_source_result(
            kind="法规", query_ok=False, effect_fact="",
            verify_source="", verified_at="",
            note="真实查询失败：%s" % search["error"],
            source_ref={"source": LAW_SOURCE, "query": q_title,
                        "endpoint": FLK_BASE + FLK_SEARCH_PATH})
    rows = search["rows"]
    if not rows:
        return build_source_result(
            kind="法规", query_ok=False, effect_fact="未查到原文",
            verify_source="", verified_at="",
            note="真实查询成功但无命中（%s 检索「%s」共 %s 条）——"
                 "**未检出不推定不存在或已失效**"
                 % (LAW_SOURCE, q_title, search.get("total")),
            source_ref={"source": LAW_SOURCE, "query": q_title,
                        "endpoint": FLK_BASE + FLK_SEARCH_PATH,
                        "total": search.get("total")})

    # ── 选定目标版本行 ──
    #    优先：标题完全一致 且 sxx=3（现行有效）；否则取首行
    base_obj = re.sub(r"第[〇零一二三四五六七八九十百千0-9]+条.*$", "",
                       exp.get("object", "")).strip()
    cands = [r for r in rows
             if strip_highlight(str(r.get("title") or "")).strip() == q_title]
    if not cands:
        cands = rows
    prefer = [r for r in cands if r.get("sxx") == 3]
    row = (prefer or cands)[0]

    # ── ② 真实详情 + 目录树 ──
    bbbs = str(row.get("bbbs") or "")
    detail_res = asyncio.run(_query_flk_detail_async(bbbs))
    detail = detail_res["data"] if detail_res["ok"] else {}
    clause_set = collect_clause_titles(detail.get("content"))

    # ── ③ 目标匹配 ──
    match = {"matched": False, "items": [], "reason": "未执行匹配"}
    if fm:
        match = match_target(fm, row, detail, clause_set)

    src_status = SXX_MAP.get(row.get("sxx"), "")
    gbrq = _norm_date(row.get("gbrq"))
    sxrq = _norm_date(row.get("sxrq"))
    official_url = flk_detail_url(bbbs)

    # ── 证据构造（**只写真实取得的东西**）──
    vr = {}
    if fm:
        old_vr = fm.get("verify_record")
        if isinstance(old_vr, list) and len(old_vr) == 1:
            old_vr = old_vr[0]
        if isinstance(old_vr, dict):
            vr = dict(old_vr)
    clause_list = clauses or exp.get("clauses") or []
    vr.update({
        "object": vr.get("object") or exp.get("object") or q_title,
        "version": vr.get("version") or exp.get("version") or
                   ("%s公布%s施行" % (gbrq or "?", sxrq or "?")),
        "doc_no": vr.get("doc_no") or "",
        "official_url": official_url,
        "clauses": clause_list,
        "verified_on": "",
        "evidence_location": "",
    })
    ev_bits = []
    if detail_res["ok"]:
        ev_bits.append("flk-npc 详情 API（bbbs=%s）返回真实目录树，"
                       "共 %d 个条号节点" % (bbbs, len(clause_set)))
    if match.get("items"):
        ev_bits.append("逐项比对：" + "；".join(
            "%s=%s" % (i["item"], "一致" if i["ok"] else "不一致")
            for i in match["items"]))
    vr["evidence_location"] = "；".join(ev_bits)

    # ── 判定是否可写成功 ──
    query_ok = True
    effect_fact = src_status
    note_bits = []
    if not detail_res["ok"]:
        query_ok = False
        note_bits.append("详情查询失败：%s" % detail_res["error"])
    if fm and not match["matched"]:
        query_ok = False
        note_bits.append("目标匹配不通过：%s" % match["reason"])

    today = MR.today().isoformat()
    if query_ok:
        vr["verified_on"] = today
    else:
        vr["verified_on"] = ""
        vr["evidence_location"] = "（查询未成功，不得记录核验证据）"

    verify_source = LAW_SOURCE if query_ok else ""

    # ── G02：target 绑定块（**执行器与消费端同一契约**）────────────
    #   由 `MR.build_target_binding()` 构造，消费端由
    #   `MR.check_target_binding()` 校验——两处同源，契约不分裂。
    #
    #   ⚠️ `object` 取**来源实际标题**、`version` 取**来源实际版本日期**
    #      （gbrq/sxrq）、`clauses` 取**本次实际命中条号**——
    #      消费端拿这些与「当前页声明」比对，跨对象/跨版本/跨页套用即被拒。
    src_title = strip_highlight(str(row.get("title") or ""))
    src_version = " ".join(x for x in (gbrq, sxrq) if x)
    found_clauses = sorted(c for c in clause_set if c in clause_list) \
        if clause_list else []
    target_block = MR.build_target_binding(
        matched=bool(match.get("matched")) if fm else False,
        page_id=page_id,
        page_fingerprint=MR.page_fingerprint(page_text),
        object=src_title,
        version=src_version,
        clauses=found_clauses,
        page_path=(page_path or ""),
        query_title=q_title,
        bbbs=bbbs,
        title=src_title,
        gbrq=gbrq,
        sxrq=sxrq,
        flxz=row.get("flxz") or "",
        zdjg_name=row.get("zdjgName") or "",
        sxx=row.get("sxx"),
        clauses_expected=clause_list,
        clauses_found=found_clauses,
    )

    sr = build_source_result(
        kind="法规",
        query_ok=query_ok,
        effect_fact=effect_fact if query_ok else "",
        verify_source=verify_source,
        verified_at=today if query_ok else "",
        note="；".join(note_bits) if note_bits else
             ("真实查询命中并完成目标匹配（flk-npc 搜索 %d 条命中，取 bbbs=%s）"
              % (search.get("total") or len(rows), bbbs)),
        target=target_block,
        evidence={
            "search_endpoint": FLK_BASE + FLK_SEARCH_PATH,
            "detail_endpoint": FLK_BASE + FLK_DETAIL_PATH + "?bbbs=" + bbbs,
            "search_total": search.get("total"),
            "match_items": match.get("items", []),
            "match_reason": match.get("reason", ""),
            "clause_tree_size": len(clause_set),
            "detail_fetch_ok": bool(detail_res["ok"]),
            "search_fetch_ok": True,
        },
        verify_record=vr if fm else None,
        source_ref={
            "source": LAW_SOURCE,
            "query": q_title,
            "route": list(MR.SOURCE_ROUTES["法规"]),
            "retrieved_at": today,
        },
    )
    return sr


# ────────────────────────────────────────────────────────────
# main
# ────────────────────────────────────────────────────────────

def main() -> int:
    ap = argparse.ArgumentParser(
        description="真实来源查询执行器（flk-npc 首选来源）")
    ap.add_argument("--page", help="目标页相对路径（取其 frontmatter 期望值）")
    ap.add_argument("--title", help="直接指定查询标题")
    ap.add_argument("--law-title", help="指定法规标题（页面未声明对象时用）")
    ap.add_argument("--clause", action="append",
                    help="目标条号（可重复），如 --clause 第三十条")
    ap.add_argument("--out", help="输出 source-result JSON 路径")
    ap.add_argument("--dry-run", action="store_true",
                    help="只打印，不写文件")
    args = ap.parse_args()

    if not args.page and not args.title and not args.law_title:
        print("错误：必须给 --page / --title / --law-title 之一", file=sys.stderr)
        return 2

    sr = run_query(args.page, args.title, law_title=args.law_title,
                   clauses=args.clause)

    print("=" * 74)
    print("真实来源查询执行器 | 来源：%s" % MR.SOURCE_ROUTES["法规"][0])
    print("=" * 74)
    print("query_ok      = %r" % sr.get("query_ok"))
    print("effect_fact   = %r" % sr.get("effect_fact"))
    print("verify_source = %r" % sr.get("verify_source"))
    print("verified_at   = %r" % sr.get("verified_at"))
    print("note          = %s" % sr.get("note"))
    tgt = sr.get("target") or {}
    if tgt:
        print("target        = %s | bbbs=%s | sxx=%s | 公布=%s 施行=%s"
              % (tgt.get("title"), tgt.get("bbbs"), tgt.get("sxx"),
                 tgt.get("gbrq"), tgt.get("sxrq")))
        print("clauses       = 期望 %s / 命中 %s"
              % (tgt.get("clauses_expected"), tgt.get("clauses_found")))
    ev = sr.get("evidence") or {}
    for it in (ev.get("match_items") or []):
        print("  比对 %-18s 期望=%-22r 实际=%-22r %s"
              % (it["item"], it["expected"], it["actual"],
                 "✓" if it["ok"] else "✗"))

    # 契约自检：产出必须能通过 `validate_source_result()`
    ok, norm, errors = MR.validate_source_result(sr)
    print("契约自检 validate_source_result：%s%s"
          % ("通过" if ok else "**不通过**",
             "" if ok else " → " + "；".join(errors)))

    if args.dry_run:
        print("\n（dry-run：未写文件）")
        return 0 if ok else 1

    if not args.out:
        print("\n未给 --out，未写文件。", file=sys.stderr)
        return 0 if ok else 1

    out = args.out if os.path.isabs(args.out) else os.path.join(ROOT, args.out)
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, "w", encoding="utf-8") as f:
        json.dump(sr, f, ensure_ascii=False, indent=2)
    print("\n已写出：%s" % os.path.relpath(out, ROOT))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
