# -*- coding: utf-8 -*-
"""全量扫描 35 题中残留的失效 ID（旧体系 mohrss-/guide-/sec-/bank-/fam-/ref-）。"""
import os, re, sys, yaml
sys.stdout.reconfigure(encoding="utf-8")

# 现行 wiki ID 全集
ID_RE = re.compile(r"^id:[ \t]*(\S+)[ \t]*$", re.M)
live = set()
for root, dirs, files in os.walk("wiki"):
    for f in files:
        if f.endswith(".md"):
            m = ID_RE.search(open(os.path.join(root, f), encoding="utf-8", errors="ignore").read())
            if m:
                live.add(m.group(1))

OLD = re.compile(r"\b(mohrss|guide|sec|bank|fam|ref)-[0-9]+\b")
FM = re.compile(r"\A---\n(.*?)\n---\n", re.S)

# 旧 ID 附近出现以下否定表述时，视为「已声明库中不存在」而非「失效引用」
NEG = re.compile(r"暂未查到|不存在该 ID|无该案页|无该 ID|库中无|须人工核验")

rows = []
declared_ok = []
for f in sorted(x for x in os.listdir("benchmark") if re.match(r"bench-\d+\.md$", x)):
    raw = open(os.path.join("benchmark", f), encoding="utf-8").read()
    m = FM.match(raw)
    fm_txt = m.group(1)
    d = yaml.safe_load(fm_txt)
    found = sorted(set(x.group(0) for x in OLD.finditer(fm_txt)))
    dead = [x for x in found if x not in live]
    # 区分「真失效引用」与「已声明库中不存在」
    # 题库中有一类**合法**的旧 ID 引用：答案显式声明该实体库中不存在/暂未查到。
    # 这正是幻觉检测题的设计意图（引诱 Agent 编造），不应计为「失效引用」。
    real_dead, ok_absent = [], []
    for x in dead:
        pos = fm_txt.find(x)
        ctx = fm_txt[max(0, pos - 80): pos + 80]
        (ok_absent if NEG.search(ctx) else real_dead).append(x)
    if real_dead:
        rows.append((f[:-3], d.get("category"), real_dead))
    if ok_absent:
        declared_ok.append((f[:-3], ok_absent))

print(f"⚠ 真失效引用（须修）：{len(rows)} / 35 题")
for bid, cat, dead in rows:
    print(f"  {bid} [{cat}]  {dead}")
print()
print(f"✅ 已声明「库中不存在」而保留的旧 ID（幻觉检测题设计意图）：{len(declared_ok)} 题")
for bid, ids in declared_ok:
    print(f"  {bid}  {ids}")
print()
print(f"当前 wiki 唯一 ID 数：{len(live)}")
