"""Read-only current default-search inventory; optionally verify exclusions with real MCP calls."""
from pathlib import Path
import sys,json,datetime as dt,collections,argparse,asyncio,re
ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT/'_scripts'))
import _knowledge_policy as K
from _publish_gate import publish_gate

def main(interfaces=False):
    checked=dt.datetime.now(dt.timezone(dt.timedelta(hours=8)))
    out=ROOT/'outputs'/('检索可用性检测_'+checked.strftime('%Y%m%d_%H%M%S'));out.mkdir(parents=True)
    pages=[];malformed=[]
    for p in sorted((ROOT/'wiki').rglob('*.md')):
        text=p.read_text(encoding='utf-8-sig');rel=p.relative_to(ROOT).as_posix()
        try:d,body=K.read_raw(text)
        except Exception as e:
            malformed.append({'path':rel,'title':p.stem,'reason':str(e),'note':'操作说明不属于结构化法律知识页' if not text.startswith('---') else '知识页解析失败，需修复'})
            continue
        hydrated=K.hydrate(d);usable,reasons=K.usable_gate(hydrated);verified,vreasons=publish_gate(hydrated)
        title=next((line.lstrip('# ').strip() for line in body.splitlines() if line.startswith('# ')),p.stem)
        pages.append({'id':d.get('id'),'path':rel,'title':title,'type':d.get('type'),'domain':d.get('domain'),'publish_status':d.get('publish_status'),'usable':usable,'reasons':reasons,'official_source_verified':verified,'official_source_reasons':vreasons})
    contents=[r for r in pages if r['type']!='index'];excluded=[r for r in contents if not r['usable']];indices=[r for r in pages if r['type']=='index' and not r['usable']]
    stats={'all_wiki_markdown':len(pages)+len(malformed),'structured_pages':len(pages),'content_pages':len(contents),'default_usable_content':sum(r['usable'] for r in contents),'default_excluded_content':len(excluded),'default_excluded_indices':len(indices),'unstructured_or_parse_errors':len(malformed),'official_source_verified_content':sum(r['official_source_verified'] for r in contents),'usable_but_outside_official_filter':sum(r['usable'] and not r['official_source_verified'] for r in contents)}
    result={'checked_at':checked.isoformat(timespec='seconds'),'scope':'usable (default)','read_only':True,'counts':stats,'excluded_content':excluded,'excluded_indices':indices,'unstructured_or_parse_errors':malformed,'all_pages':pages}
    if interfaces:
        sys.path.insert(0,str(ROOT/'tools/legal-tools/自建知识库MCP/scripts'));import server as S
        async def verify():
            checks=[]
            for i,row in enumerate(excluded+indices):
                res=await S.kb_search(S.SearchInput(keyword=row['id'],domain=row['domain'],max_results=50,include_content=False,include_excluded=False,include_raw_fallback=False))
                found=any(line.startswith('### ') and row['path'] in line for line in res.splitlines())
                if found:raise AssertionError('排除页实际被默认返回：'+row['path'])
                actual=json.loads(await S.kb_read_page(S.ReadPageInput(path=row['path'],body_only=True,limit=1)))
                if actual['usable']:raise AssertionError('读取资格与扫描不一致：'+row['path'])
                checks.append({'id':row['id'],'default_search_returns_page':False,'read_usable':False,'actual_reasons':actual['usage_reasons']})
                if (i+1)%25==0:print('已核对实际排除',i+1,'/',len(excluded+indices),flush=True)
            # Positive controls distinguish valid exclusions from a globally broken search.
            for ident in ('labor-topic-031','labor-case-025'):
                row=next(r for r in pages if r['id']==ident)
                res=await S.kb_search(S.SearchInput(keyword=ident,domain=row['domain'],include_content=False,include_excluded=False,include_raw_fallback=False))
                assert any(line.startswith('### ') and row['path'] in line for line in res.splitlines())
                checks.append({'id':ident,'positive_control_found':True})
            return checks
        result['actual_mcp_checks']=asyncio.run(verify())
        result['actual_mcp_mode']='real local functions; no claim about every remote client connection'
    (out/'检测数据.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8',newline='\n')
    names={'01-labor':'劳动与人事','02-contract':'合同','03-tort':'侵权与不当得利','04-ip':'知识产权','05-family':'婚姻家事','06-admin':'行政','07-corporate':'公司商事','08-data':'数据与AI合规','09-criminal':'刑事','10-cross':'跨领域'}
    lines=['# 当前默认检索不可用内容清单','',f'检测时间：{result["checked_at"]}（北京时间）。重新读取当前文件与V5.2策略；本次只检测，不修改正文、属性或发布状态。','',f'内容页共{len(contents)}篇：默认可用{stats["default_usable_content"]}篇，不可用{len(excluded)}篇。另有{len(indices)}个索引和{len(malformed)}份非结构化说明/解析异常，分别附后，不混入内容篇数。','',f'已有{stats["usable_but_outside_official_filter"]}篇可默认检索、但未进入verified/official过滤器；它们不属于本清单的“不可检索内容”。个人总结无需进入官方来源过滤才算发布成功。','','## 按领域统计','','| 领域 | 默认不可用内容篇数 |','| --- | ---: |']
    counts=collections.Counter(r['domain'] for r in excluded)
    for domain,count in sorted(counts.items()):lines.append(f'| {names.get(domain,domain)} | {count} |')
    lines+=['','## 逐篇清单','']
    def cell(s):return str(s).replace('|','/').replace('\n',' ')
    for domain in sorted(counts):
        lines+=['',f'### {names.get(domain,domain)}','','| ID | 页面 | 当前状态 | 实际排除原因 |','| --- | --- | --- | --- |']
        for row in excluded:
            if row['domain']!=domain:continue
            link=f'[{cell(row["title"])}](<{(ROOT/row["path"]).as_posix()}>)'
            lines.append('| '+ ' | '.join([cell(row['id']),link,cell(row['publish_status']),'；'.join(map(cell,row['reasons']))])+' |')
    lines+=['','## 附录：未放行索引','','索引不等于独立法律知识正文，单独列出。','','| ID | 页面 | 排除原因 |','| --- | --- | --- |']
    for row in indices:lines.append(f'| {cell(row["id"])} | [{cell(row["title"])}](<{(ROOT/row["path"]).as_posix()}>) | {"；".join(map(cell,row["reasons"]))} |')
    lines+=['','## 附录：非结构化说明或解析异常','','| 文件 | 诊断 | 说明 |','| --- | --- | --- |']
    for row in malformed:lines.append(f'| [{cell(row["title"])}](<{(ROOT/row["path"]).as_posix()}>) | {cell(row["reason"])} | {cell(row["note"])} |')
    lines+=['','## 口径与验证','',f'- 当前{len(excluded)}篇被排除不等于内容错误；具体原因以逐页记录为准。历史或不再参照案例可以按历史范围使用，不能仅因其历史身份自动判定正文无价值。','- raw、draft、outputs不属于默认usable知识页发布范围。PDF、DOC等二进制正文不由此MCP直接全文索引；其来源线索和已提取文字应分别理解。','- “已发布但本次关键词未命中”、max_results限制、客户端未调用MCP，与页面资格排除是不同问题。',('- 已对每个结构化排除页实际调用本地MCP默认搜索和读取资格检查，并验证2篇正常页面仍可命中。' if interfaces else '- 已按同一可用性策略逐页计算；本次未执行MCP接口调用。'),'- 本地实现验收不代表已经检查每个外部聊天客户端的连接状态。','']
    report=out/'当前不可检索内容清单.md';report.write_text('\n'.join(lines),encoding='utf-8',newline='\n')
    assert len(excluded)==sum(counts.values())
    print(json.dumps({'counts':stats,'by_domain':dict(counts),'reason_counts':dict(collections.Counter(reason for r in excluded for reason in r['reasons'])),'report':str(report),'data':str(out/'检测数据.json')},ensure_ascii=False),flush=True)
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--interfaces',action='store_true');args=ap.parse_args();main(args.interfaces)
