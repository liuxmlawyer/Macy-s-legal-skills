# -*- coding: utf-8 -*-
"""_evidence_rules.py —— 核验证据（verify_record）严格校验（**共享真源**）

═══════════════════════════════════════════════════════════════════════
一、为什么抽出这个模块（v3 / G03）
═══════════════════════════════════════════════════════════════════════

Codex v3 审查指出的 **G03**：「`verify_record` 一致性缺口只追加 `gaps`，
不阻止写回；来源契约允许 `query_ok=true` 但证据为空壳。`verify_record`
只有 `object` 时 CLI `--write` 仍 rc0，把现行有效、flk-npc、`verified_at`
和不完整证据写入隔离页。」

补正通知要求：「**复用或抽出既有严格证据校验**，缺字段、空壳、错误类型、
未来日期、证据日期与查询日期不一致，都不能只写 gaps 后 rc0 落成功。」

本模块就是把 `_publish_gate.py` 里那套**既有严格证据校验**原样抽出，
成为**一处实现、两处复用**：

  · `_publish_gate.py` —— 发布资格门禁（official scope 是否放行）；
  · `_meta_rules.py` / `_auto_meta.py` —— 自动赋值写回闸门
    （本页核验是否成功、能否保存 `status=现行有效` / `verified_at` /
    `verify_source` / `verify_record`）。

**抽取原则**：函数体、判定口径、**错误文案逐字保留**（既有回归
`_test_publish_gate.py` 断言「缺少关键字段 …」「缺少关键字段
evidence_location」等精确文案，**不得**因重构而改变）。

═══════════════════════════════════════════════════════════════════════
二、判定口径（与 `_publish_gate.py` v2/R02 完全一致）
═══════════════════════════════════════════════════════════════════════

`verify_record` 的 7 个关键字段**全部必须存在、非空、类型正确**：

    object / version / doc_no      —— 必须是**非空文本标量**
    official_url                    —— 必须是 http(s) 地址文本
    clauses                         —— 条号 list[str] 或顿号串接文本
    evidence_location               —— 非空文本定位
    verified_on                     —— 真实存在的日历日期（YYYY-MM-DD）

**空壳证据一律拒绝**（v2/R02）：
  · `clauses=[null]` / `["  "]` / `[]` / `{x: null}`；
  · `evidence_location={x: null}` / `""` / `null`；
  · list/dict 冒充文本标量（object/version/doc_no/official_url/verified_on）。
"""

from __future__ import annotations

import datetime
import re


#: verify_record 的关键字段（全部必须存在且非空）
VERIFY_RECORD_REQUIRED = ("object", "version", "doc_no",
                          "official_url", "clauses",
                          "verified_on", "evidence_location")


def is_real_date(s) -> bool:
    """是否为真实存在的日历日期（YYYY-MM-DD）。

    ⚠️ 严格日历校验：`2026-02-30` / `2026-13-01` / `2026-10-23` 等一律 False。
    """
    if not re.match(r"^\d{4}-\d{2}-\d{2}$", s or ""):
        return False
    try:
        y, m, d = (int(x) for x in s.split("-"))
        return datetime.date(y, m, d).isoformat() == s
    except (ValueError, TypeError):
        return False


def is_shell(value) -> bool:
    """判断一个值是否为空壳（无实际内容的容器）。

    空壳定义（v2/R02）：
      * 空列表 / 空字典；
      * 列表中含 None 元素，或全部元素为空白文本；
      * 字典中所有叶子值均为 None 或空白文本（例：{'x': None}）。
    """
    if value is None:
        return True
    if isinstance(value, dict):
        if not value:
            return True
        return all(is_shell(v) for v in value.values())
    if isinstance(value, list):
        if not value:
            return True
        return any(is_shell(v) for v in value)
    if isinstance(value, str):
        return not value.strip()
    return False


def record_field(rec: dict, name: str) -> str:
    """取 verify_record 的字段值文本（**只认标量文本**）。

    ⚠️ v2/R02 旧实现：list/dict 只要非空即返回 "有内容" →
    `clauses=[null]`、`evidence_location={x: null}` 等**空壳证据**被放行。
    现改为：list/dict **不**能充当文本字段值，返回 ""（= 缺失/非法），
    由 `check_one_record()` 做分类校验并给出精确原因。
    """
    v = rec.get(name)
    if v is None:
        return ""
    if isinstance(v, (dict, list)):
        return ""
    if isinstance(v, bool):
        return "true" if v else "false"
    return str(v).strip()


def clauses_fault(rec: dict) -> str:
    """校验 clauses 字段（条号证据）。

    接受形态（真实既有记录形式）：
      * list[str]：条号列表，如 ['第三十条', '第三十一条']；
      * str：顿号/逗号串接的条号串，如 '第21条、第22条……'。
    拒绝形态（空壳证据）：
      * None / 空串 / 纯空白；
      * [] 空列表；
      * [None]、['']、['  ']、含 None 元素或全空白元素的列表；
      * dict（空壳或以字典冒充文本）。
    """
    if "clauses" not in rec:
        return "缺少关键字段 clauses"
    v = rec["clauses"]
    if v is None:
        return "缺少关键字段 clauses（值为 null，空壳证据）"
    if isinstance(v, dict):
        return ("clauses 类型非法：应为条号列表或条号文本，实际为 dict"
                + ("（且为空壳字典）" if is_shell(v) else ""))
    if isinstance(v, list):
        if not v:
            return "缺少关键字段 clauses（空列表，空壳证据）"
        bad = []
        for i, item in enumerate(v):
            if item is None:
                bad.append("第%d项为 null" % (i + 1))
            elif isinstance(item, (dict, list)):
                bad.append("第%d项为 %s（不能用结构冒充条号文本）"
                           % (i + 1, "dict" if isinstance(item, dict) else "list"))
            elif not str(item).strip():
                bad.append("第%d项为空白" % (i + 1))
        if bad:
            return "缺少关键字段 clauses（含空壳条目：%s）" % "、".join(bad)
        return ""
    if isinstance(v, bool):
        return "clauses 类型非法：应为条号列表或条号文本，实际为 bool"
    if not str(v).strip():
        return "缺少关键字段 clauses（值为空白，空壳证据）"
    return ""


def evidence_location_fault(rec: dict) -> str:
    """校验 evidence_location 字段（证据定位）。

    接受形态：非空白文本字符串（库内既有形态均为文本定位）。
    拒绝形态：None / 空串 / 纯空白 / dict / list
    （含 {'x': None} 这类空壳字典）。
    """
    if "evidence_location" not in rec:
        return "缺少关键字段 evidence_location"
    v = rec["evidence_location"]
    if v is None:
        return "缺少关键字段 evidence_location（值为 null，空壳证据）"
    if isinstance(v, (dict, list)):
        return ("evidence_location 类型非法：应为文本定位，实际为 %s%s"
                % ("dict" if isinstance(v, dict) else "list",
                   "（且为空壳，无任何有效定位内容）" if is_shell(v) else ""))
    if isinstance(v, bool):
        return "evidence_location 类型非法：应为文本定位，实际为 bool"
    if not str(v).strip():
        return "缺少关键字段 evidence_location（值为空白，空壳证据）"
    return ""


def text_field_fault(rec: dict, name: str) -> str:
    """校验必须为非空文本的字段（object / version / doc_no）。"""
    if name not in rec:
        return "缺少关键字段 %s" % name
    v = rec[name]
    if v is None:
        return "%s 为空（空壳证据）" % name
    if isinstance(v, (dict, list)):
        return ("%s 类型非法：应为文本标量，实际为 %s（不能用结构冒充文本）"
                % (name, "dict" if isinstance(v, dict) else "list"))
    if isinstance(v, bool):
        return "%s 类型非法：应为文本标量，实际为 bool" % name
    if not str(v).strip():
        return "缺少关键字段 %s（值为空白，空壳证据）" % name
    return ""


def check_one_record(rec: dict, idx: int = 0) -> list:
    """校验单条 verify_record，返回问题列表。

    ⚠️ v2/R02：逐字段做**类型 + 内容**双重校验，空壳证据一律拒绝；
    真实既有记录形态（dict / list-of-dict、条号列表或条号串）仍然支持。

    ⚠️ v3/G03：本函数是**本页核验能否写回**的前置判定依据，
    任何一条问题都意味着**不得**保存核验成功状态。
    """
    tag = "" if idx == 0 else "（第%d条）" % (idx + 1)
    problems = []

    # ① 文本类字段：object / version / doc_no
    for f in ("object", "version", "doc_no"):
        msg = text_field_fault(rec, f)
        if msg:
            problems.append("verify_record%s %s" % (tag, msg))

    # ② 条号证据：clauses
    msg = clauses_fault(rec)
    if msg:
        problems.append("verify_record%s %s" % (tag, msg))

    # ③ 证据定位：evidence_location
    msg = evidence_location_fault(rec)
    if msg:
        problems.append("verify_record%s %s" % (tag, msg))

    # ④ 链接字段：official_url（必须是 http(s) 文本）
    if "official_url" not in rec:
        problems.append("verify_record%s 缺少关键字段 official_url" % tag)
    else:
        url = rec["official_url"]
        if url is None:
            problems.append("verify_record%s 缺少关键字段 official_url"
                            "（值为 null，空壳证据）" % tag)
        elif isinstance(url, (dict, list)):
            problems.append("verify_record%s official_url 类型非法："
                            "应为 http(s) 地址文本，实际为 %s"
                            % (tag, "dict" if isinstance(url, dict) else "list"))
        elif isinstance(url, bool):
            problems.append("verify_record%s official_url 类型非法："
                            "应为 http(s) 地址文本，实际为 bool" % tag)
        else:
            url = str(url).strip()
            if not url:
                problems.append("verify_record%s 缺少关键字段 official_url"
                                "（值为空白，空壳证据）" % tag)
            elif not re.match(r"^https?://[^\s]+$", url):
                problems.append("verify_record%s 的 official_url 不是可定位的 "
                                "http(s) 地址：%r" % (tag, url))

    # ⑤ 日期字段：verified_on（必须是真实日历日期文本）
    if "verified_on" not in rec:
        problems.append("verify_record%s 缺少关键字段 verified_on" % tag)
    else:
        von = rec["verified_on"]
        if von is None:
            problems.append("verify_record%s 缺少关键字段 verified_on"
                            "（值为 null，空壳证据）" % tag)
        elif isinstance(von, (dict, list)):
            problems.append("verify_record%s verified_on 类型非法："
                            "应为日期文本，实际为 %s"
                            % (tag, "dict" if isinstance(von, dict) else "list"))
        elif isinstance(von, bool):
            problems.append("verify_record%s verified_on 类型非法："
                            "应为日期文本，实际为 bool" % tag)
        else:
            von = str(von).strip()
            if not von:
                problems.append("verify_record%s 缺少关键字段 verified_on"
                                "（值为空白，空壳证据）" % tag)
            elif not is_real_date(von):
                problems.append("verify_record%s 的 verified_on=%r 不是合法日历日期"
                                % (tag, von))
    return problems


def check_record(rec) -> list:
    """校验 verify_record（dict 形态），返回问题列表；非 dict 一律不合格。"""
    if not isinstance(rec, dict):
        return ["verify_record 必须是对象（dict），实际为 %s"
                % type(rec).__name__]
    if not rec:
        return ["verify_record 为空（空壳证据）"]
    return check_one_record(rec, 0)


def future_date_fault(date_text: str, today=None) -> str:
    """日期晚于今天 → 返回问题描述（合法且不晚于今天则返回 ""）。"""
    if not date_text:
        return ""
    if not is_real_date(date_text):
        return "%r 不是合法日历日期" % date_text
    if today is None:
        today = datetime.date.today()
    if datetime.date.fromisoformat(date_text) > today:
        return "%s 晚于今天（未来日期，疑似脚本批量填充）" % date_text
    return ""
