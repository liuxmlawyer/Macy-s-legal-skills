# -*- coding: utf-8 -*-
"""_run_all_gates.py —— 全门禁统一入口

把分散的校验脚本串成一条命令，便于：
  · 本地批量跑（改完页面一次跑完）
  · 定时巡检时作为**发布前拦截**
  · 避免「只跑了 G1-G6 就以为没问题」

【2026-10-24 重构】
原实现的三个致命缺陷（均已修复）：
  ① **通过标志可被伪造输出覆盖**：判定顺序是「先看输出里有没有 FAIL 字样，
     再看有没有 PASS 标志，最后才看退出码」。一个「先打印『结论：PASS』再
     以非零码退出」的脚本会被判为 PASS。→ 现改为**退出码优先**，
     非零退出码一律 FAIL，输出文字仅作辅助。
  ② **必需脚本缺失只报 SKIP，不阻断**：缺脚本被当成「跳过」而非「无法验证」。
     → 现区分 required / optional：必需脚本缺失直接阻断发布。
  ③ **TIMEOUT / 异常被降级为警告**：超时的门禁等于没跑，等于放行。
     → 现一律视为 FAIL 并阻断。
另：**G11（公司法条号）此前根本不在门禁清单里**，2026-10-24 已纳入。

用法：
    python _scripts/_run_all_gates.py                # 增量模式（发布前）
    python _scripts/_run_all_gates.py --full         # 全库模式
    python _scripts/_run_all_gates.py --quick        # 跳过耗时项
    python _scripts/_run_all_gates.py --json out.json

退出码：
    0 = 全部必需门禁通过（且无必需门禁被跳过）
    1 = 有门禁失败 / 缺失 / 超时 / 异常 / 非零退出 / **必需门禁被跳过**
        （**不得发布**）
    2 = 参数或环境错误

【2026-10-24 第二轮修复（KB-20261024-001 / B01）】
前一版 `--full` **只影响标题与 JSON**，执行循环仍把 `['--changed']`
传给 `_check_gate.py`，导致「全库模式」实际只查 git 变更文件，全库门禁
形同虚设。本版改为**按模式解析每个门禁的实际入参**：

  · G1-G6 的 `args_incr = ['--changed']`、`args_full = []`
    （`_check_gate.py` 不带 `--changed` 即走全库入口：glob 全库 wiki 页）
  · 其余门禁两种模式入参相同（本来就是全库扫描）
  · `quick` 模式若跳过**必需**门禁 → 结论不得为 PASS，退出码 1

回归测试见 `_scripts/_test_run_all_gates.py`：它捕获**实际子进程 argv**，
并用隔离夹具证明「只在未变更页设错」时 full 能拦截、changed 不能。
"""

import json
import os
import subprocess
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _paths import ROOT  # noqa: E402

PY = sys.executable
TIMEOUT = 600

# (编号, 脚本, 增量入参, 全库入参, 说明, required, slow)
#
# ⚠️ B01 修复要点：**入参必须随模式变化**，否则 `--full` 只是标签。
#   · G1-G6 增量传 ['--changed']（只查 git 变更文件）
#   · G1-G6 全库传 []          → `_check_gate.py` 走 glob 全库入口
#   · 其余门禁两种模式入参相同（本来就是全库扫描）
# required=True 的门禁：缺失 / 超时 / 异常 / 非零退出 / 被 quick 跳过
#                        一律阻断发布。
GATES = [
    ("G14", "_verify_property_choices.py", [], [], "属性选择枚举与必填边界", True, False),
    ("G1-G6", "_check_gate.py", ["--changed"], [],
     "发布前强校验（YAML/字段/核验自洽/id/索引/写法）", True, False),
    ("G7", "_verify_bm.py", [], [],
     "benchmark 前后台一致性", True, False),
    ("G8", "_scan_dead_ids.py", [], [],
     "失效 ID 扫描（幻觉检测题除外）", True, False),
    ("G9", "_verify_answer_ids.py", [], [],
     "benchmark 答案 ID 存在性", True, False),
    ("G10", "_verify_no_hardcoded_paths.py", [], [],
     "硬编码路径扫描", True, False),
    ("G11", "_verify_company_law.py", [], [],
     "公司法条号位移检测（内容指纹）", True, False),
    ("G12", "_verify_inspect_result.py", [], [],
     "精简字段与证据完整性", True, False),
    ("G13", "_verify_wikilinks.py", ["--strict"], ["--strict"],
     "wiki 双链完整性", True, False),
]

# 退出码 -> 判定。**非零一律 FAIL**，不看输出文字。
EXIT_OK = 0


def classify_output(out):
    """仅作说明用：抓一行最像失败原因的文本。"""
    for line in out.split("\n"):
        s = line.strip()
        if ("FAIL" in s or "🔴" in s or "错误" in s or "Error" in s
                or "Traceback" in s) and s:
            return s[:70]
    return ""


def run_one(name, script, args, desc, required, slow):
    """执行单个门禁。

    `args` 是**本次模式实际应传给子进程的参数列表**，由调用方按模式解析，
    本函数不再自行拼接 —— 避免「模式只体现在标签上」的老问题。
    """
    p = os.path.join(ROOT, "_scripts", script)
    if not os.path.exists(p):
        if required:
            return {"gate": name, "status": "FAIL", "reason": "必需脚本缺失：%s" % script,
                    "detail": "", "elapsed": 0.0, "required": True}
        return {"gate": name, "status": "SKIP", "reason": "可选脚本不存在：%s" % script,
                "detail": "", "elapsed": 0.0, "required": False}

    t0 = time.time()
    try:
        r = subprocess.run([PY, p] + args, cwd=ROOT, capture_output=True,
                           text=True, encoding="utf-8", errors="replace",
                           timeout=TIMEOUT)
    except subprocess.TimeoutExpired:
        return {"gate": name, "status": "FAIL",
                "reason": "超时（>%ds），视为未完成验证" % TIMEOUT,
                "detail": "", "elapsed": time.time() - t0, "required": required}
    except Exception as e:
        return {"gate": name, "status": "FAIL",
                "reason": "执行异常：%s: %s" % (type(e).__name__, e),
                "detail": "", "elapsed": time.time() - t0, "required": required}

    el = time.time() - t0
    out = (r.stdout or "") + (r.stderr or "")
    detail = classify_output(out)

    if r.returncode != EXIT_OK:
        # 关键：退出码优先。**输出里印「结论：PASS」也不能掩盖非零退出。**
        return {"gate": name, "status": "FAIL",
                "reason": "退出码 %d（非零）" % r.returncode,
                "detail": detail, "elapsed": el, "required": required,
                "stdout_tail": out[-1200:]}

    if not out.strip():
        return {"gate":name,"status":"FAIL","reason":"脚本无输出，未能验证","detail":"","elapsed":el,"required":required}
    # 退出码为 0，但输出里明确写着失败 —— 同样不放行
    if "结论：FAIL" in out or "FAIL ——" in out:
        return {"gate": name, "status": "FAIL", "reason": "输出声明 FAIL",
                "detail": detail, "elapsed": el, "required": required,
                "stdout_tail": out[-1200:]}

    return {"gate": name, "status": "PASS", "reason": desc, "detail": detail,
            "elapsed": el, "required": required}


def main() -> int:
    import argparse
    parser=argparse.ArgumentParser(description="统一技术门禁及可选批次发布验收")
    parser.add_argument('--full',action='store_true');parser.add_argument('--quick',action='store_true')
    parser.add_argument('--json');parser.add_argument('--report');parser.add_argument('--release',action='store_true')
    parser.add_argument('--manifest');parser.add_argument('--deployment',action='store_true')
    options=parser.parse_args();quick=options.quick;full=options.full or options.release
    json_out=options.json;gates=list(GATES)
    if options.release:
        if not options.manifest:parser.error('--release必须指定--manifest')
        gates.append(('R1','verify_release.py',['--manifest',options.manifest],['--manifest',options.manifest],'批准范围与可用性',True,False))
    if options.deployment:
        if not all(os.path.isdir(os.path.join(ROOT,x)) for x in ('raw','tools')):
            print('结论：FAIL —— 部署素材目录缺失');return 1
        gates.append(('RAW','_check_index.py',[],[],'原始资料索引',True,False))
    mode = "full（全库发布模式）" if full else "incremental（增量检查模式）"
    print("=" * 78)
    print("全门禁统一入口 | %s%s" % (mode, " | quick" if quick else ""))
    print("=" * 78)

    results = []
    for name, script, args_incr, args_full, desc, required, slow in gates:
        # ★ B01 核心：入参随模式解析，full 模式**不传** --changed，
        #   让 _check_gate.py 走全库入口（glob 全库 wiki 页）。
        sargs = list(args_full) if full else list(args_incr)
        if quick and slow:
            # 被 quick 跳过的门禁记为 SKIP；若它是必需门禁，
            # 下面的「必需门禁被跳过」分支会把结论压到 FAIL。
            results.append({"gate": name, "status": "SKIP", "reason": "quick 模式跳过",
                            "detail": "", "elapsed": 0.0, "required": required,
                            "args": sargs})
            continue
        r = run_one(name, script, sargs, desc, required, slow)
        # 记录实际入参，便于 JSON 报告与回归测试核对
        r["args"] = sargs
        results.append(r)
        flag = {"PASS": "✅", "FAIL": "🔴", "SKIP": "⏭"}.get(r["status"], "🟡")
        extra = "" if r["status"] == "PASS" else "  ← " + r["reason"]
        print("%-6s %-4s %-52s %5.1fs%s" % (
            name, flag, r["reason"][:52], r["elapsed"], extra))

    npass = sum(1 for r in results if r["status"] == "PASS")
    nfail = sum(1 for r in results if r["status"] == "FAIL")
    nskip = sum(1 for r in results if r["status"] == "SKIP")
    req_fail = [r for r in results if r["status"] == "FAIL" and r["required"]]
    opt_fail = [r for r in results if r["status"] == "FAIL" and not r["required"]]
    # ★ B01：必需门禁被跳过（quick 模式）同样不得给发布通过。
    req_skip = [r for r in results if r["status"] == "SKIP" and r["required"]]

    print("\n" + "=" * 78)
    print("通过 %d ｜ 失败 %d ｜ 跳过 %d" % (npass, nfail, nskip))

    if nfail:
        print("\n🔴 失败项：")
        for r in results:
            if r["status"] == "FAIL":
                print("   %s — %s%s" % (r["gate"], r["reason"],
                                        ("  " + r["detail"]) if r["detail"] else ""))
        if opt_fail and not req_fail:
            print("\n结论：FAIL —— 存在非必需门禁失败项，须人工确认后方可发布。")
            rc = 1
        else:
            print("\n结论：FAIL —— 存在未通过的门禁，不得发布。")
            rc = 1
    elif req_skip:
        # ★ B01：跳过了必需门禁 = 未能验证，不得以「全部通过」放行。
        print("\n⏭ 被跳过的必需门禁：")
        for r in req_skip:
            print("   %s — %s" % (r["gate"], r["reason"]))
        print("\n结论：FAIL —— 必需门禁未执行（quick 模式跳过），"
              "未能完成验证，不得据此发布。")
        rc = 1
    else:
        print("\n结论：PASS —— 全部必需门禁通过 ✅")
        rc = 0

    if json_out:
        payload = {
            "mode": "full" if full else "incremental",
            "quick": quick,
            "generated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "summary": {"pass": npass, "fail": nfail, "skip": nskip,
                        "required_skipped": len(req_skip)},
            "result": rc,
            "gates": results,
        }
        p = json_out if os.path.isabs(json_out) else os.path.join(ROOT, json_out)
        with open(p, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)
        print("结构化结果：%s" % p)

    if options.report:
        p=options.report if os.path.isabs(options.report) else os.path.join(ROOT,options.report)
        os.makedirs(os.path.dirname(os.path.abspath(p)),exist_ok=True)
        with open(p,'w',encoding='utf-8') as f:
            f.write('# V5统一验收结果\n\n结论：'+('PASS' if rc==0 else 'FAIL')+'\n\n'+ '\n'.join('- '+r['gate']+' '+r['status']+' '+r['reason'] for r in results)+'\n')
    return rc


if __name__ == "__main__":
    sys.exit(main())
