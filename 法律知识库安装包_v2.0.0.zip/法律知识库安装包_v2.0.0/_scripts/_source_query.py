"""V5 executable route; legacy FLK implementation remains available to the router."""
from _source_query_v42 import *
from _source_router_v5 import main
if __name__ == "__main__":
    raise SystemExit(main())
