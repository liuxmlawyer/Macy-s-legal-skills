# -*- coding: utf-8 -*-
"""核验改写后 benchmark 答案中引用的所有现行 ID 是否真实存在（防推测 ID）。"""
import os, re, sys, yaml
sys.stdout.reconfigure(encoding="utf-8")

ID_RE = re.compile(r"^id:[ \t]*(\S+)[ \t]*$", re.M)
live = {}
for root, dirs, files in os.walk("wiki"):
    for f in files:
        if f.endswith(".md"):
            p = os.path.join(root, f)
            m = ID_RE.search(open(p, encoding="utf-8", errors="ignore").read())
            if m:
                live[m.group(1)] = os.path.basename(p)[:-3]

# 形如 xxx-012 的现行 ID（现行体系：域前缀-term/case-序号）
CUR = re.compile(r"\b((?:labor|corp|admin|ip|family|data|tort|cross)-\d+)\b")
FM = re.compile(r"\A---\n(.*?)\n---\n", re.S)

print("现行 ID 总数:", len(live))
bad_total = 0
for f in sorted(x for x in os.listdir("benchmark") if re.match(r"bench-\d+\.md$", x)):
    raw = open(os.path.join("benchmark", f), encoding="utf-8").read()
    m = FM.match(raw)
    d = yaml.safe_load(m.group(1))
    txt = d["expected_answer"]
    ids = sorted(set(x.group(1) for x in CUR.finditer(txt)))
    dead = [i for i in ids if i not in live]
    if dead:
        bad_total += len(dead)
        print(f"[推测ID] {f[:-3]}: {dead}")

print("=" * 70)
print("疑似推测 ID 总数:", bad_total)

# 顺带核验双链目标文件名是否存在
print()
LINK = re.compile(r"\[\[([^\]|#]+)")
bad_link = 0
for f in sorted(x for x in os.listdir("benchmark") if re.match(r"bench-\d+\.md$", x)):
    raw = open(os.path.join("benchmark", f), encoding="utf-8").read()
    links = sorted(set(x.group(1).strip() for x in LINK.finditer(raw)))
    dead = [t for t in links if t not in live.values()]
    if dead:
        bad_link += len(dead)
        print(f"[断链] {f[:-3]}: {dead}")
print("=" * 70)
print("断链总数:", bad_link)
