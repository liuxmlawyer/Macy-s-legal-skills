# -*- coding: utf-8 -*-
"""
G13 · wiki 双链完整性门禁

为什么需要这个门禁（2026-10-22 实测发现）：
  G9只扫 `benchmark/` 的答案链，**wiki 332 页内部的双链完全无门禁覆盖**。
  当日改名词条文件时，双链同步全靠人工记得——这是流程漏洞。

本脚本检查三类断链：
  1. **wiki 内部双链**——`[[某页名]]` 指向的页面不存在
  2. **文件名与 id 不一致**——frontmatter 的 id 与文件名对不上
  3. **索引页漏登记**——页面存在但所属域索引里没有登记

用法：
    python _scripts/_verify_wikilinks.py            # 全量
    python _scripts/_verify_wikilinks.py --strict   # 索引漏登记也判FAIL
"""

import os
import re
import sys
from collections import defaultdict

import yaml

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _paths import ROOT, WIKI  # noqa: E402

FM_RE = re.compile(r"^---\r?\n(.*?)\r?\n---", re.S)
WIKILINK_RE = re.compile(r"\[\[([^\]|]+?)(?:\|[^\]]*?)?\]\]")
ID_RE = re.compile(r"^id:\s*(\S+)\s*$", re.M)

# ── 白名单：非页面引用（模板示例、外部链接锚点等）──
IGNORE_TARGETS = {
    "index", "README", "rules", "知识库巡检制度",
}
# 搭建指南等说明文档中的模板示例，含转义符，不计入断链
TEMPLATE_DOCS = {
    "法律知识库搭建指南.md", "法律知识库使用手册.md",
    "法律工具使用手册.md", "法律工具速查卡.md",
    "排版效果示例.md",
}


def load_pages():
    """返回 {页面名: 相对路径} 与 {id: (页面名, 路径)}"""
    by_name, by_id, meta = {}, {}, {}
    for dp, _, fns in os.walk(WIKI):
        for fn in sorted(fns):
            if not fn.endswith(".md"):
                continue
            p = os.path.join(dp, fn)
            rel = os.path.relpath(p, WIKI).replace(os.sep, "/")
            name = os.path.splitext(fn)[0]
            by_name[name] = rel
            try:
                text = open(p, encoding="utf-8", errors="replace").read()
            except OSError:
                continue
            m = FM_RE.match(text)
            d = {}
            if m:
                try:
                    d = yaml.safe_load(m.group(1)) or {}
                except Exception:
                    d = {}
            if isinstance(d, dict) and d.get("id"):
                by_id[str(d["id"])] = (name, rel)
            meta[rel] = {"id": str(d.get("id", "")), "type": str(d.get("type", "")),
                         "domain": str(d.get("domain", "")), "text": text,
                         "name": name}
    return by_name, by_id, meta


def main() -> int:
    strict = "--strict" in sys.argv
    by_name, by_id, meta = load_pages()

    print("=" * 72)
    print("G13 · wiki 双链完整性")
    print("=" * 72)
    print("页面总数：%d ｜ id 总数：%d" % (len(by_name), len(by_id)))

    # ── 检查 1：断链 ──
    dead = []
    for rel, info in meta.items():
        if os.path.basename(rel) in TEMPLATE_DOCS:
            continue
        for m in WIKILINK_RE.finditer(info["text"]):
            target = m.group(1).strip()
            if not target or target in IGNORE_TARGETS:
                continue
            if target in by_name:
                continue
            # 可能是 id 而非文件名
            if target in by_id:
                continue
            # 带路径的双链
            if any(v == target or v.endswith("/" + target) for v in by_name.values()):
                continue
            dead.append((rel, target))

    # ── 检查 2：孤儿页（文件名从未被任何双链引用）──
    # ⚠️ 2026-10-22 两次修正记录：
    #   初版查「id 与文件名一致」→ 误报 241 处（本库设计是中文名 + 英文 id）；
    #   二版查「id 未被引用」→ 误报 244 处（索引用**文件名**双链，不用 id）；
    #   **现版查「文件名未被任何双链引用」**——这才是真正的孤儿页。
    linked = set()
    for rel, info in meta.items():
        for m in WIKILINK_RE.finditer(info["text"]):
            t = m.group(1).strip()
            if t:
                linked.add(t)
    orphans = []
    for rel, info in meta.items():
        if rel.endswith("-index.md") or rel.count("/") == 0:
            continue
        if info["type"] not in ("term", "case", "topic"):
            continue
        if info["name"] not in linked:
            orphans.append((rel, info["name"]))

    # ── 检查 3：索引漏登记 ──
    # 索引按 type 分文件：{域}-cases-index.md / {域}-terms-index.md 等
    unindexed = []
    for rel, info in meta.items():
        t = info["type"]
        if t not in ("term", "case", "topic"):
            continue
        if rel.endswith("-index.md") or rel.count("/") == 0:
            continue
        dom = info["domain"]
        if not dom:
            continue
        # 按 type 定位对应索引文件
        sub = {"case": "cases", "term": "terms", "topic": "topics"}.get(t)
        cands = []
        if sub:
            cands.append(os.path.join(WIKI, dom, sub, "%s-%s-index.md" % (dom, sub)))
        cands.append(os.path.join(WIKI, dom, "%s-index.md" % dom))
        idxs = [c for c in cands if os.path.exists(c)]
        if not idxs:
            continue
        itext = "".join(open(c, encoding="utf-8", errors="replace").read() for c in idxs)
        if info["name"] not in itext and info["id"] not in itext:
            unindexed.append(rel)

    print()
    print("【检查 1】断链")
    if dead:
        print("  🔴 断链 %d 处" % len(dead))
        for rel, t in dead[:20]:
            print("      %-46s → [[%s]]" % (rel[:46], t[:50]))
        if len(dead) > 20:
            print("      ... 另 %d 处" % (len(dead) - 20))
    else:
        print("  ✅ 断链 0 处")

    print("\n【检查 2】孤儿页（从未被双链引用）")
    if orphans:
        print("  🟡 孤儿页 %d 处" % len(orphans))
        for rel, nm in orphans[:12]:
            print("      %-46s %s" % (rel[:46], nm[:40]))
        if len(orphans) > 12:
            print("      ... 另 %d 处" % (len(orphans) - 12))
    else:
        print("  ✅ 无孤儿页")

    print("\n【检查 3】索引漏登记")
    if unindexed:
        print("  🟡 漏登记 %d 处" % len(unindexed))
        for rel in unindexed[:12]:
            print("      %s" % rel)
        if len(unindexed) > 12:
            print("      ... 另 %d 处" % (len(unindexed) - 12))
    else:
        print("  ✅ 无漏登记")

    # ── 判定 ──
    print("\n" + "=" * 72)
    fail = len(dead) > 0 or (strict and len(unindexed) > 0)
    if fail:
        print("结论：FAIL —— %s" % ("存在断链" if dead else "存在索引漏登记"))
        return 1
    print("结论：PASS —— 双链完整，无断链%s"
          % ("（strict 模式：索引亦齐备）" if strict and not unindexed else ""))
    return 0


if __name__ == "__main__":
    sys.exit(main())