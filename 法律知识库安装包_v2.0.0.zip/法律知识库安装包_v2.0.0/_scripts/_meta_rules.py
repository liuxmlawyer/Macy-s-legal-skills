# -*- coding: utf-8 -*-
"""_meta_rules.py —— 知识库元数据默认规则引擎（RULE-20261025-001 / rules.md V4.1）

本模块是《知识库元数据默认规则调整方案》与《方案人工批准记录》的**唯一可执行真源**：
rules.md §1.3 / §2.2 / §2.6 / §3.4 / §4.1 与 `_check_gate.py`、`_publish_gate.py`、
MCP `server.py`、页面模板中关于 `status` / `authority_level` / `review_status`
的语义**全部以本模块为准**，避免「规则允许自动填写、脚本仍以人工条件拒绝」。

═══════════════════════════════════════════════════════════════════════
一、总体口径（方案第一节）
═══════════════════════════════════════════════════════════════════════
**自动查询、规则赋值、人工可改、证据留存。**

「不必人工核验」指**不把人工核验设为这三个字段自动填写及入库的前置条件**；
不等于没有查询就标记有效、没有证据也伪称已核验。

═══════════════════════════════════════════════════════════════════════
二、来源路由（方案第二节 + 本轮用户口径）
═══════════════════════════════════════════════════════════════════════
⚠️ **口径差异（已记入《规则新旧差异表》）**：
  · 方案原文第二节写「法律…：国家法律法规数据库 → 北大法宝 → 联网官方原文」；
  · 本轮用户口径明确「**法规先 flk-npc**、**案例先人民法院案例库**，其次 pkulaw、再官方原文」。
  · 本模块按**用户口径**实现：`flk-npc` 即国家法律法规数据库（官方 MCP 名称），
    `人民法院案例库` 为案例首选源。
  · 一律**逐级降级**，每级失败与实际采用来源均留痕（`verify_source` + `verify_record`）。

═══════════════════════════════════════════════════════════════════════
三、authority_level 映射（方案第三节，**严格从上到下优先匹配**）
═══════════════════════════════════════════════════════════════════════
| # | source_type / 前提                     | 其他条件                        | authority_level |
|---|----------------------------------------|---------------------------------|-----------------|
| 1 | 任一材料，已明确失效/裁判被推翻；或案例已明确不再参照 | 有依据支持，不能由未检出推定 | 低 |
| 2 | 任一材料，当前有效性或材料类型无法判断              | 包括 status=待核实             | unknown        |
| 3 | 裁判文书，已取得充分状态依据               | case_effect=指导性、公报        | 高（不限地域）  |
| 4 | 裁判文书，已取得充分状态依据               | 典型案例，jurisdiction=全国或北京 | 高             |
| 5 | 裁判文书，已取得充分状态依据               | 典型案例，其他明确地域           | 中             |
| 6 | 裁判文书，已取得充分状态依据               | 普通案例，任何地域              | 中             |
| 7 | 裁判文书，已取得充分状态依据               | case_effect=unknown             | 低             |
| 8 | 法律/司法解释/地方规则/行政法规/部门规章        | status=现行有效                 | 高             |
| 9 | 实务分析                                | 未另设可解释的评分办法           | unknown        |
|10 | 其余未匹配/字段冲突                       | 如典型案例缺地域                 | unknown（记录缺口）|

**已批准的两项优化（人工批准记录）**：
  ① 指导性 / 公报案例**不受地域限制**；「全国 / 北京」地域条件**仅用于典型案例**；
  ② `status=待核实` → `authority_level=unknown`（信息不足 ≠ 明确负面状态）。

**语义边界**：`authority_level` 是**本库参考优先级**（排序 / 选材用），
**不是法定效力位阶**，也不代表案件拘束力或结论正确性。

═══════════════════════════════════════════════════════════════════════
四、review_status 语义（方案第四节）
═══════════════════════════════════════════════════════════════════════
· draft 内新编译页 → 草稿
· 确实经人工审核、尚未入 wiki → 已审核（由人工或有明确批准记录的流程设置）
· **入 wiki 且写入 / 索引 / 必要技术校验全部成功 → 已发布**（无需逐页人工核验）
· 写入失败 / 索引失败 / 技术门禁失败 → **仍为草稿**，不得仅按目标路径预先标记成功

「已发布」**只表示内部知识库已入库**，**不表示已人工审核**，
不表示可不核对原文直接出具法律意见。

═══════════════════════════════════════════════════════════════════════
五、核验链分离（方案第一节第 4 点 + 第五节）
═══════════════════════════════════════════════════════════════════════
· `last_verified` —— **仅记录真实人工核验日期**，AI 不填；无人工核验留空。
· `verified_at`   —— 记录**真实自动 / 来源核验时间**；未执行核验**不填**，
                    **不得填编译时间冒充**。
· `verify_source` —— 实际来源（人工核验 / flk-npc / 人民法院案例库 / pkulaw / wk /
                    官方站点直查 / 未核验）。「批量推定」仅为历史兼容值，
                    **不视为本次查询已完成**。
· **不再以「人工日期缺失」阻断真实自动核验**——自动核验以
  `verified_at` + 真实来源证据判定。

═══════════════════════════════════════════════════════════════════════
六、人工覆盖优先（方案第一节第 5 点）
═══════════════════════════════════════════════════════════════════════
`manual_overrides` 为**可选列表**，记录三字段中哪些由人工固定：

    manual_overrides:
      - field: status
        value: 现行有效
        reason: 经人工核对官方公告，该版本仍为现行版本
        at: 2026-10-25

规则：
  1. 命中人工覆盖的字段，**自动流程不得直接覆盖**；
  2. 出现新来源与人工选择**矛盾**时，**只报告、不擅自抹去人工选择**；
  3. 人工覆盖理由记录在变更日志，不要求给所有旧页新增复杂结构。

═══════════════════════════════════════════════════════════════════════
七、保留不动的防线（任务单要求）
═══════════════════════════════════════════════════════════════════════
YAML 真实解析失败、空壳证据、日期合法性、路径隔离、分页重组——
由 `_publish_gate.py` / `_check_gate.py` / MCP server 各自继续负责，
本模块**不削弱**其中任何一项，仅新增自动赋值与语义映射。
"""

from __future__ import annotations

import datetime
import hashlib
import re

# ════════════════════════════════════════════════════════════════════
# 0. 常量与值域
# ════════════════════════════════════════════════════════════════════

RULE_VERSION = "V4.2"
RULE_TASK_ID = "RULE-20261025-001"

# ---- status 值域（沿用现有枚举以减少迁移；方案第二节末段）------------
STATUS_CURRENT = "现行有效"
STATUS_REPEALED = "已废止"
STATUS_OVERTURNED = "被推翻"
STATUS_UNVERIFIED = "待核实"
STATUS_VALUES = (STATUS_CURRENT, STATUS_REPEALED, STATUS_OVERTURNED,
                 STATUS_UNVERIFIED)

# 案例「不再参照」由 case_effect 承载，不写进 status（方案第二节案例说明）
CASE_EFFECT_VALUES = ("指导性", "公报", "典型案例", "普通案例", "不再参照", "unknown")

# case_effect 输入别名归一化（方案第三节：不能同时保留两套正式值域）
CASE_EFFECT_ALIASES = {
    "指导": "指导性", "指导性案例": "指导性",
    "最高人民法院指导性案例": "指导性",
    "公报案例": "公报", "公报": "公报",
    "典型": "典型案例", "典型案例汇编": "典型案例",
    "普通": "普通案例", "参考案例": "普通案例",
    "不再参照": "不再参照",
    "": "unknown", "none": "unknown", "null": "unknown",
    "未单独标注": "unknown", "有效": "unknown",
    "人民法院案例库入库案例": "unknown",
}

# ---- source_type 值域（方案第三节末段：补行政法规、部门规章）--------
NORMATIVE_TYPES = ("法律", "司法解释", "地方规则", "行政法规", "部门规章")
CASE_TYPES = ("裁判文书",)
ANALYSIS_TYPES = ("实务分析",)
SOURCE_TYPE_VALUES = NORMATIVE_TYPES + CASE_TYPES + ANALYSIS_TYPES

# ---- authority_level 值域 ------------------------------------------------
AL_HIGH, AL_MID, AL_LOW, AL_UNKNOWN = "高", "中", "低", "unknown"
AUTHORITY_LEVEL_VALUES = (AL_HIGH, AL_MID, AL_LOW, AL_UNKNOWN)

# ---- review_status 值域 --------------------------------------------------
RS_DRAFT, RS_REVIEWED, RS_PUBLISHED = "草稿", "已审核", "已发布"
REVIEW_STATUS_VALUES = (RS_DRAFT, RS_REVIEWED, RS_PUBLISHED)

# ---- 来源路由（用户口径）--------------------------------------------------
SOURCE_LAW_FIRST = "flk-npc"            # 法规首选：国家法律法规数据库
SOURCE_CASE_FIRST = "人民法院案例库"      # 案例首选：人民法院案例库
SOURCE_SECOND = "pkulaw"                # 次选：北大法宝
SOURCE_THIRD = "官方站点直查"            # 末选：联网定位官方原文

SOURCE_ROUTES = {
    "法规": (SOURCE_LAW_FIRST, SOURCE_SECOND, SOURCE_THIRD),
    "案例": (SOURCE_CASE_FIRST, SOURCE_SECOND, SOURCE_THIRD),
    "实务分析": (SOURCE_LAW_FIRST, SOURCE_CASE_FIRST, SOURCE_SECOND,
                 SOURCE_THIRD),
}

# ---- verify_source 值域 --------------------------------------------------
VERIFY_MANUAL = "人工核验"
VERIFY_UNVERIFIED = "未核验"
VERIFY_LEGACY_ESTIMATE = "批量推定"      # 历史兼容值，不视为本次查询已完成
VERIFY_REAL_SOURCES = (
    VERIFY_MANUAL, SOURCE_LAW_FIRST, SOURCE_CASE_FIRST, SOURCE_SECOND,
    "wk", SOURCE_THIRD, "samr", "npc.gov.cn",
)

# 自动核验来源（用于区分「人工核验」与「自动核验」两条日期路径）
AUTO_VERIFY_SOURCES = {
    SOURCE_LAW_FIRST, SOURCE_CASE_FIRST, SOURCE_SECOND,
    "wk", SOURCE_THIRD, "samr", "npc.gov.cn",
}

# ---- jurisdiction 识别 ---------------------------------------------------
# 非地域的误填值（法源类型 / 机关名）——不视为「明确地域」
NON_GEO_JURISDICTIONS = {
    "", "全国", "法律", "行政法规", "司法解释", "部门规章", "地方性法规",
    "unknown", "最高人民法院", "最高法", "法院", "全国人大",
}
# 「全国 / 北京」地域条件**仅用于典型案例**
HIGH_TYPICAL_JURISDICTIONS = {"全国", "北京"}


# ════════════════════════════════════════════════════════════════════
# 1. 通用小工具
# ════════════════════════════════════════════════════════════════════

def _text(v) -> str:
    """取标量文本（list/dict 视为非标量 → 空）。"""
    if v is None:
        return ""
    if isinstance(v, (dict, list)):
        return ""
    if isinstance(v, bool):
        return "true" if v else "false"
    return str(v).strip()


def is_real_date(s: str) -> bool:
    """真实存在的日历日期（YYYY-MM-DD）。

    不能只靠正则或 `datetime.date.fromisoformat`——后者在 Python 3.11+
    对 "2026-10-23" 这类溢出值会**静默容忍**。
    """
    s = _text(s)
    if not re.match(r"^\d{4}-\d{2}-\d{2}$", s):
        return False
    try:
        y, m, d = (int(x) for x in s.split("-"))
        return datetime.date(y, m, d).isoformat() == s
    except (ValueError, TypeError):
        return False


def today() -> datetime.date:
    return datetime.date.today()


# ════════════════════════════════════════════════════════════════════
# 1b. 来源查询结果的**严格结构与类型校验**（F05）
# ════════════════════════════════════════════════════════════════════

#: 来源结果中允许出现的键（多出的键忽略，不报错）
SR_ALLOWED_KEYS = frozenset((
    "kind", "query_ok", "effect_fact", "verify_source", "verified_at",
    "note", "target", "evidence", "verify_record", "source_ref",
))

#: `kind` 的合法取值
SR_KINDS = ("法规", "案例", "实务分析", "专题")

#: `query_ok` 必须是**真正的布尔值**；字符串 "false"/"true"、0/1、"" 一律**不接受**
_SR_BOOL = (bool,)


def validate_source_result(sr) -> tuple:
    """严格校验来源查询结果的结构与类型。

    返回 (ok: bool, normalized: dict, errors: list)。

    规则（F05，Codex v1 反例）：
      · `query_ok` **必须是布尔 `True`** 才表示查询成功；
        字符串 `"false"` / `"true"` / `""` / `0` / `1` / list / dict
        **一律不算成功**（此前 `bool(sr.get("query_ok"))` 会把 `"false"` 当成功）；
      · `kind` / `effect_fact` / `verify_source` / `verified_at` / `note`
        必须是**字符串**；传 list/dict 视为结构错误；
      · `verified_at` 若给出，必须是**合法日历日期**；
      · **失败/缺结果/结构错误时不得返回来源与日期**
        （否则会把"未查询成功"写成"已核验来源 + 核验日期"）。

    ⚠️ 本函数**不放宽**任何既有防线，只做**加严**。
    """
    errors = []
    if not isinstance(sr, dict):
        return False, {}, ["source_result 必须是对象（dict），实际为 %s"
                           % type(sr).__name__]

    unknown = [k for k in sr.keys() if k not in SR_ALLOWED_KEYS]
    if unknown:
        errors.append("source_result 含未定义键：%s（已忽略）"
                      % "、".join(sorted(map(str, unknown))))

    # ── query_ok：必须是真布尔 ──
    raw_ok = sr.get("query_ok", None)
    if "query_ok" not in sr:
        errors.append("source_result 缺 query_ok（未提供查询是否成功）")
        query_ok = False
    elif not isinstance(raw_ok, _SR_BOOL):
        errors.append("query_ok 必须是布尔值，实际为 %s（%r）——"
                      "字符串/数字/list/dict 均不代表查询成功"
                      % (type(raw_ok).__name__, raw_ok))
        query_ok = False
    else:
        query_ok = bool(raw_ok)

    # ── 字符串字段类型校验 ──
    def _str_field(key, required=False):
        v = sr.get(key, None)
        if v is None:
            if required:
                errors.append("source_result 缺 %s" % key)
            return ""
        if not isinstance(v, str):
            errors.append("%s 必须是字符串，实际为 %s（%r）"
                          % (key, type(v).__name__, v))
            return ""
        return v.strip()

    kind = _str_field("kind")
    if kind and kind not in SR_KINDS:
        errors.append("kind=%r 不在允许取值 %s 内" % (kind, "/".join(SR_KINDS)))
    effect_fact = _str_field("effect_fact")
    verify_source = _str_field("verify_source")
    note = _str_field("note")
    verified_at = _str_field("verified_at")
    if verified_at and not is_real_date(verified_at):
        errors.append("verified_at=%r 非合法日历日期" % verified_at)
        verified_at = ""

    # ── 目标匹配与证据（可选，但用于闭环校验）──
    target = sr.get("target", None)
    if target is not None and not isinstance(target, dict):
        errors.append("target 必须是对象（dict），实际为 %s"
                      % type(target).__name__)
        target = None
    evidence = sr.get("evidence", None)
    if evidence is not None and not isinstance(evidence, dict):
        errors.append("evidence 必须是对象（dict），实际为 %s"
                      % type(evidence).__name__)
        evidence = None
    vr = sr.get("verify_record", None)
    if vr is not None and not isinstance(vr, dict):
        errors.append("verify_record 必须是对象（dict），实际为 %s"
                      % type(vr).__name__)
        vr = None

    # ── 结构错误 ⇒ 整份结果视为"查询未成功" ──
    hard_errors = [e for e in errors
                   if not e.startswith("source_result 含未定义键")]
    ok = query_ok and not hard_errors

    normalized = {
        "kind": kind,
        "query_ok": ok,
        "query_ok_raw": raw_ok,
        "effect_fact": effect_fact,
        "verify_source": verify_source,
        "verified_at": verified_at,
        "note": note,
        "target": target,
        "evidence": evidence,
        "verify_record": vr,
        "source_ref": sr.get("source_ref", None),
    }
    return ok, normalized, errors


# ════════════════════════════════════════════════════════════════════
# 1c. 发布结果的**严格类型校验**（G01）
# ════════════════════════════════════════════════════════════════════

#: 发布结果中必须为**真布尔**的字段
PUBLISH_BOOL_KEYS = ("ingest_ok", "index_ok", "tech_gate_ok", "human_reviewed")


def validate_publish_result(publish_result) -> tuple:
    """严格校验「实际发布结果」的整体与逐字段类型（**G01 真源**）。

    返回 (known: bool, flags: dict, errors: list)。

    规则（Codex v3 G01）：
      · **整体**必须是对象（dict）；`None` 表示「未提供」，
        其它类型（list / str / 数字）一律视为**不可用**（`known=False`）；
      · `ingest_ok` / `index_ok` / `tech_gate_ok` 三项**必须是真正的布尔值**：
        `'false'` / `'true'` / `0` / `1` / `None` / `[]` / `{}` **一律不算成功**
        （此前 `bool(pr.get(...))` 会把字符串 `'false'` 当成 True
        → 直接导致「已发布」被凭空升级）；
      · 三项中任一**缺键**或**非布尔** → `known=False`（发布状态不可追溯），
        按「未提供实际发布结果」的保守语义处理：**不得**升级为「已发布」，
        也**不得**据此把已有「已发布」页静默降级；
      · `human_reviewed` 只有**真布尔 True** 才算人工审核
        （字符串 `'true'` / `1` **不得**冒充 `human_reviewed`）。

    ⚠️ 本函数**只做加严**，不放宽任何既有防线。
    """
    flags = {k: False for k in PUBLISH_BOOL_KEYS}
    errors = []

    if publish_result is None:
        return False, flags, ["未提供实际发布结果（发布状态不可追溯）"]

    if not isinstance(publish_result, dict):
        return False, flags, ["发布结果必须是对象（dict），实际为 %s"
                              % type(publish_result).__name__]

    # ① 三项发布环节：必须**全部**为真布尔，否则整体视为不可追溯
    gates_ok = True
    for key in ("ingest_ok", "index_ok", "tech_gate_ok"):
        if key not in publish_result:
            gates_ok = False
            errors.append("发布结果缺字段 %s（按未成功处理，不得默认成功）" % key)
            continue
        value = publish_result[key]
        if not isinstance(value, bool):
            gates_ok = False
            errors.append("发布结果字段 %s 必须是布尔值，实际为 %s（%r）——"
                          "字符串/数字/list/dict 均不代表成功"
                          % (key, type(value).__name__, value))
            continue
        flags[key] = value

    # ② human_reviewed：只有真布尔 True 才算人工审核
    if "human_reviewed" not in publish_result:
        errors.append("发布结果缺字段 human_reviewed（按未人工审核处理）")
    else:
        hr = publish_result["human_reviewed"]
        if not isinstance(hr, bool):
            errors.append("发布结果字段 human_reviewed 必须是布尔值，"
                          "实际为 %s（%r）——非布尔值不得冒充人工审核"
                          % (type(hr).__name__, hr))
        else:
            flags["human_reviewed"] = hr

    return gates_ok, flags, errors


# ════════════════════════════════════════════════════════════════════
# 1d. 目标绑定契约（G02）——执行器与消费端**同一契约**
# ════════════════════════════════════════════════════════════════════

#: `target` 中用于「绑定到具体目标页」的必备字段（**v3 / G02 共享契约**）
#:
#: ⚠️ 这份清单是**执行器（`_source_query.py`）与消费端（`_auto_meta.py`）
#:    共用的唯一契约**——两处必须同源同字段，任一处改口径即视为契约破裂。
#:
#:  · `matched`          —— 真布尔；执行器逐项比对（对象/版本/条款存在性/时效）
#:                        的**总结果**；只有 `True` 才允许进入写回判断；
#:  · `page_id`          —— 目标页 frontmatter 的**稳定 ID**；
#:  · `page_fingerprint` —— 目标页**内容指纹**（sha256，覆盖 frontmatter+正文），
#:                        用于识别「查询之后页面又被改动」；
#:  · `object`           —— 本次核验的**法律对象**（法规名）；
#:  · `version`          —— 本次核验的**版本**（来自来源的公布/施行日期）；
#:  · `clauses`          —— 本次核验**实际命中**的条号集合。
#:
#: 可选（仅作追溯，不参与放行判定）：`page_path`（原始页面相对路径）。
TARGET_BINDING_KEYS = ("matched", "page_id", "page_fingerprint",
                       "object", "version", "clauses")


def page_fingerprint(text: str) -> str:
    """计算页面内容指纹（sha256十六进制，换行统一为 \\n）。

    ⚠️ 指纹覆盖**整页内容**（frontmatter + 正文）——
    目标页在查询之后被改动过（哪怕只改了正文一个字），
    旧的来源结果就**不得**再用于保存核验成功状态。
    """
    if text is None:
        return ""
    norm = str(text).replace("\r\n", "\n").replace("\r", "\n")
    return hashlib.sha256(norm.encode("utf-8")).hexdigest()


def _norm_title(text: str) -> str:
    """法规对象名归一：去空白、去「第N条」后缀。"""
    s = re.sub(r"\s+", "", str(text or ""))
    s = re.sub(r"第[〇零一二三四五六七八九十百千0-9]+条.*$", "", s)
    return s.strip()


def _norm_dates(text: str) -> set:
    """抽取文本中的全部 YYYY-MM-DD 日期（用于版本一致性比对）。"""
    return set(re.findall(r"\d{4}-\d{2}-\d{2}", str(text or "")))


def _date_seq(text: str) -> list:
    """按出现顺序抽取 YYYY-MM-DD 日期（**公布日期在前、施行日期在后**）。

    ⚠️ 版本核对必须用**有序**序列而非集合：
    集合比对会把「公布日期相同、施行日期不同」的两个版本判为一致，
    导致跨版本套用漏检（G02 明确要求「错版本…不得保存核验成功状态」）。
    本函数与 `_source_query._page_expectations()` 的
    「首个日期=公布日期、次个日期=施行日期」口径**保持一致**。
    """
    return re.findall(r"\d{4}-\d{2}-\d{2}", str(text or ""))


def _norm_clause_list(value) -> list:
    """条款归一为「去空白后的字符串列表」（接受 list 或顿号串接文本）。"""
    if isinstance(value, str):
        items = [c.strip() for c in re.split(r"[、,，]", value) if c.strip()]
    elif isinstance(value, list):
        items = [str(c).strip() for c in value if str(c).strip()]
    else:
        items = []
    return items


def _norm_ver(text) -> str:
    """版本文本归一：去全部空白（保留标点与括号内容）。"""
    return re.sub(r"\s+", "", str(text or ""))


def _norm_iso(value) -> str:
    """日期归一为 YYYY-MM-DD 文本；非合法日历日期返回 ""。

    接受 `datetime.date`（PyYAML 会把未加引号的日期解析成 date 对象）
    与字符串；**非法日期（如 2026-02-30）返回 ""**，不静默通过。
    """
    if value is None:
        return ""
    if isinstance(value, datetime.datetime):
        value = value.date()
    if isinstance(value, datetime.date):
        return value.isoformat()
    s = str(value).strip()
    if not s:
        return ""
    if not re.match(r"^\d{4}-\d{2}-\d{2}$", s):
        return ""
    try:
        return datetime.date.fromisoformat(s).isoformat()
    except ValueError:
        return ""


def build_target_binding(*, matched, page_id, page_fingerprint,
                         object, version, clauses, **extra) -> dict:
    """构造 source-result 的 `target` 绑定块（**执行器与消费端同一契约**）。

    ⚠️ 执行器（`_source_query.py`）**只能**用本函数构造 `target`，
    消费端（`_auto_meta.py`）**只能**用 `check_target_binding()` 校验——
    两处口径分裂即视为契约破裂。

    参数含义：
      · `matched`          —— 执行器逐项比对的总结果（布尔）；
      · `page_id`          —— 目标页 frontmatter 的稳定 ID；
      · `page_fingerprint` —— 目标页内容指纹（`page_fingerprint()`）；
      · `object`           —— 本次核验的法律对象（**来源实际标题**）；
      · `version`          —— 本次核验的版本（**页面声明版本**，
                             来源的公布/施行日期另记于 `gbrq`/`sxrq`）；
      · `clauses`          —— 本次核验的条款集合。

    其余键（`gbrq`/`sxrq`/`bbbs`/`match_items` 等）经 `**extra` 传入，
    仅作**追溯**，不参与放行判定。
    """
    t = {
        "matched": bool(matched),
        "page_id": str(page_id or ""),
        "page_fingerprint": str(page_fingerprint or ""),
        "object": str(object or ""),
        "version": str(version or ""),
        "clauses": [str(c) for c in (clauses or [])],
    }
    for k, v in (extra or {}).items():
        t.setdefault(k, v)
    return t


def check_match_evidence(sr: dict) -> tuple:
    """核验「执行器逐项比对证据」（**G02/G03 同一契约的组成部分**）。

    返回 (ok: bool, errors: list)。

    ⚠️ `matched=True` 是执行器的**结论**；本函数核对的是**结论所依据的
    明细**——`evidence.match_items` 必须存在、非空，且**每一项** `ok` 都为
    真布尔 `True`。缺明细、明细为空、或存在未通过项 → 一律失败关闭，
    不得只凭 `matched=True` 就保存核验成功状态。
    """
    errors = []
    ev = (sr or {}).get("evidence")
    if not isinstance(ev, dict):
        return False, ["来源结果缺 evidence（执行器逐项比对证据）——"
                       "不得保存核验成功状态"]
    items = ev.get("match_items")
    if not isinstance(items, list) or not items:
        return False, ["evidence 缺 match_items（执行器逐项比对明细为空）——"
                       "不得保存核验成功状态"]
    bad = []
    for it in items:
        if not isinstance(it, dict):
            bad.append("（非对象条目）")
            continue
        if it.get("ok") is not True:
            bad.append("%s=%s" % (it.get("item") or "（未命名项）",
                                  it.get("actual")))
    if bad:
        return False, ["evidence.match_items 存在未通过项：%s——"
                       "不得保存核验成功状态" % "；".join(bad)]
    return True, []


def page_expectations(fm: dict) -> dict:
    """从**目标页** frontmatter 提取待核验的期望值（**执行器与消费端同一真源**）。

    返回：
      · `object`     —— 核验对象（法律名）；
      · `version`    —— 版本文本；
      · `clauses`    —— 条号集合；
      · `published`  —— **公布日期**（YYYY-MM-DD，取自版本文本首个日期）；
      · `effective`  —— **施行日期**（YYYY-MM-DD）：

        优先取版本文本的**第二个日期**；版本文本只给一个日期时，
        依次回落到 `verify_record.effective_date_of_law` →
        `verify_record.effective_date` → frontmatter 的
        `effective_date_of_law` → `effective_date`。

        ⚠️ 只取 `effective_date_of_law`（法条的施行日期），
           **不与**页面自身的 `effective_date`（页面效力日期）混用
           ——rules.md §6.3.4 明文禁止三者混填；
           `effective_date` 仅在 `effective_date_of_law` 缺失时作为兜底。

    ⚠️ 本函数是 `_source_query.py`（执行器）与 `_auto_meta.py`（消费端）
       **共用的唯一期望值定义**——两处口径分裂即视为契约破裂。
    """
    fm = fm or {}
    vr = fm.get("verify_record")
    rec = vr if isinstance(vr, dict) else (vr[0] if isinstance(vr, list) and len(vr) == 1 and isinstance(vr[0], dict) else {})
    version = str(rec.get("version") or "").strip()
    dates = _date_seq(version)

    published = dates[0] if dates else ""
    effective = dates[1] if len(dates) > 1 else ""
    if not effective:
        for src in (rec, fm):
            for key in ("effective_date_of_law", "effective_date"):
                raw = src.get(key)
                d = _norm_iso(raw)
                if d:
                    effective = d
                    break
            if effective:
                break

    return {
        "object": str(rec.get("object") or "").strip(),
        "version": version,
        "clauses": _norm_clause_list(rec.get("clauses")),
        "published": published,
        "effective": effective,
    }


def check_target_binding(target, page_fm: dict, page_text: str,
                         page_rel_path: str = "",
                         source_result: dict = None) -> tuple:
    """核对来源结果的 `target` 与**当前目标页**是否一致（G02 真源）。

    返回 (ok: bool, errors: list, details: dict)。

    ⚠️ **核对维度**（通知要求「文件 / 稳定 ID / 对象版本 / 条款 /
    当前页内容指纹」全部核对）：
      ① `matched` —— 必须是**真布尔 True**（`False` / 缺键 / 非布尔一律失败）；
      ② `page_id` —— 稳定页面 ID 与目标页 `id` 一致；
      ③ `page_fingerprint` —— 与**当前页内容**指纹一致
         （→ 同页修改后旧结果失效）；
      ④ `object` / `version` / `clauses` —— 与目标页自身声明的
         `verify_record` 期望值一致（→ 跨法律 / 跨版本套用被拒）；
      ⑤ **逐项比对证据** —— `evidence.match_items` 必须存在、非空且
         逐项 `ok=True`（→ 不得只凭 `matched=True` 的结论就放行）。

    任何一项不通过 → `ok=False` → **不得保存核验成功状态**。
    """
    errors = []
    details = {"checks": []}

    def note(item, expected, actual, ok, message):
        details["checks"].append({"item": item, "expected": expected,
                                  "actual": actual, "ok": bool(ok),
                                  "note": message})
        if not ok:
            errors.append(message)

    if not isinstance(target, dict) or not target:
        return False, ["来源结果缺少目标绑定信息（target 为空或非对象）——"
                       "不得保存核验成功状态"], details

    # ① 匹配结论
    matched = target.get("matched")
    if "matched" not in target:
        note("目标匹配结论", True, "（缺失）", False,
             "target 缺 matched（目标匹配结论缺失）")
    elif not isinstance(matched, bool):
        note("目标匹配结论", True, repr(matched), False,
             "target.matched 必须是布尔值，实际为 %s（%r）"
             % (type(matched).__name__, matched))
    elif matched is not True:
        note("目标匹配结论", True, matched, False,
             "目标匹配未通过（matched=False）——来源结果不适用于本页")

    # ② 稳定页面 ID
    page_id = target.get("page_id")
    cur_id = str((page_fm or {}).get("id") or "").strip()
    if not isinstance(page_id, str) or not page_id.strip():
        note("稳定页面 ID", cur_id or "（目标页无 id）", page_id, False,
             "target 缺稳定页面 ID（page_id）")
    elif not cur_id:
        note("稳定页面 ID", page_id.strip(), "（目标页无 id）", False,
             "目标页没有 id，无法核对稳定页面 ID")
    elif page_id.strip() != cur_id:
        note("稳定页面 ID", cur_id, page_id.strip(), False,
             "稳定页面 ID 不一致（来源 %r ≠ 目标页 %r）"
             % (page_id.strip(), cur_id))

    # ③ 当前页内容指纹
    fp = target.get("page_fingerprint")
    cur_fp = page_fingerprint(page_text)
    if not isinstance(fp, str) or not fp.strip():
        note("页面内容指纹", cur_fp, fp, False,
             "target 缺页面内容指纹（page_fingerprint）")
    elif fp.strip() != cur_fp:
        note("页面内容指纹", cur_fp, fp.strip(), False,
             "页面内容指纹不一致——目标页在查询后已被改动（或来源结果属于"
             "另一份内容），旧结果不得用于保存核验成功状态")

    # ④ 对象 / 版本 / 条款
    exp = page_expectations(page_fm)

    t_obj = target.get("object")
    if not isinstance(t_obj, str) or not t_obj.strip():
        note("对象一致性", exp["object"] or "（页面未声明）", t_obj, False,
             "target 缺对象标识（object）")
    elif not exp["object"]:
        note("对象一致性", "（页面未声明）", t_obj.strip(), False,
             "目标页未声明 verify_record.object，无法核对对象一致性")
    elif _norm_title(t_obj) != _norm_title(exp["object"]):
        note("对象一致性", exp["object"], t_obj.strip(), False,
             "对象不一致（来源 %r ≠ 目标页 %r）——跨法律套用被拒"
             % (t_obj.strip(), exp["object"]))

    t_ver = target.get("version")
    if not isinstance(t_ver, str) or not t_ver.strip():
        note("版本一致性", exp["version"] or "（页面未声明）", t_ver, False,
             "target 缺版本标识（version）")
    elif not exp["version"]:
        note("版本一致性", "（页面未声明）", t_ver.strip(), False,
             "目标页未声明 verify_record.version，无法核对版本一致性")
    else:
        # ⚠️ G02：**版本必须逐维核对「公布日期 + 施行日期」**——
        #    只比一个日期会漏检「公布日期相同、施行日期不同」的跨版本套用；
        #    只比日期集合会漏检「同日期、不同修正批次」。
        #    故：① 公布日期须一致；② 施行日期（双方都有时）须一致；
        #         ③ 目标页声明的全部日期都必须出现在来源版本中。
        seq_page = _date_seq(exp["version"])
        seq_src = _date_seq(t_ver)
        if not seq_page:
            note("版本一致性", exp["version"], t_ver.strip(), False,
                 "目标页版本未包含可核对日期，无法核对版本一致性")
        elif not seq_src:
            note("版本一致性", exp["version"], t_ver.strip(), False,
                 "来源版本未包含可核对日期，无法核对版本一致性")
        else:
            # ⚠️ G02：页面声明了施行日期时，来源**必须**给出且一致——
            #    否则「页面要 2013-07-01 施行、来源却只说 2012-12-28」
            #    这种跨版本套用会被放过。
            if exp.get("effective"):
                if len(seq_src) < 2:
                    note("版本一致性", exp["version"], t_ver.strip(), False,
                         "目标页声明施行日期 %s，但来源版本未给出施行日期"
                         "——无法确认同一版本，拒绝写回核验成功状态"
                         % exp["effective"])
                elif exp["effective"] != seq_src[1]:
                    note("版本一致性", exp["version"], t_ver.strip(), False,
                         "版本施行日期不一致（来源 %r ≠ 目标页 %r）"
                         "——跨版本套用被拒"
                         % (seq_src[1], exp["effective"]))
                elif seq_page[0] != seq_src[0]:
                    note("版本一致性", exp["version"], t_ver.strip(), False,
                         "版本公布日期不一致（来源 %r ≠ 目标页 %r）"
                         "——跨版本套用被拒"
                         % (seq_src[0], seq_page[0]))
            elif seq_page[0] != seq_src[0]:
                note("版本一致性", exp["version"], t_ver.strip(), False,
                     "版本公布日期不一致（来源 %r ≠ 目标页 %r）——跨版本套用被拒"
                     % (seq_src[0], seq_page[0]))
            else:
                missing = [d for d in seq_page if d not in seq_src]
                if missing:
                    note("版本一致性", exp["version"], t_ver.strip(), False,
                         "目标页版本日期 %r 未出现在来源版本中——跨版本套用被拒"
                         % (missing,))

    t_cls = target.get("clauses")
    t_clauses = _norm_clause_list(t_cls)
    if not t_clauses:
        note("条款一致性", exp["clauses"] or "（页面未声明）", t_cls, False,
             "target 缺条款标识（clauses）")
    elif not exp["clauses"]:
        note("条款一致性", "（页面未声明）", t_clauses, False,
             "目标页未声明 verify_record.clauses，无法核对条款一致性")
    elif sorted(t_clauses) != sorted(exp["clauses"]):
        note("条款一致性", exp["clauses"], t_clauses, False,
             "条款不一致（来源 %r ≠ 目标页 %r）"
             % (t_clauses, exp["clauses"]))

    # ⑤ 逐项比对证据（`matched=True` 只是结论，明细才是依据）
    ev_ok, ev_errors = check_match_evidence(source_result or {})
    if not ev_ok:
        for e in ev_errors:
            note("逐项比对证据", "全部通过", e, False, e)

    return (not errors), errors, details


# ════════════════════════════════════════════════════════════════════
# 1e. 核验证据的**前置条件**校验（G03）
# ════════════════════════════════════════════════════════════════════

def _load_evidence_rules():
    """载入 `_evidence_rules`（严格证据校验共享真源）。

    ⚠️ 用 importlib 按**文件位置**载入，不依赖 sys.path——
    `_publish_gate.py` 以 importlib 方式载入本模块时，
    裸 `import _evidence_rules` 可能因 sys.path 不含 `_scripts` 而失败。
    """
    try:
        import importlib.util
        import os
        here = os.path.dirname(os.path.abspath(__file__))
        path = os.path.join(here, "_evidence_rules.py")
        if os.path.isfile(path):
            spec = importlib.util.spec_from_file_location("_evidence_rules", path)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            return mod
    except Exception:
        return None
    try:
        import _evidence_rules as mod      # noqa: F401
        return mod
    except Exception:
        return None


_EVIDENCE_RULES = _load_evidence_rules()


def check_verify_record(sr: dict, page_fm: dict = None,
                        today_date: datetime.date = None) -> tuple:
    """校验「本页核验成功」的**前置条件**（G03 真源）。

    返回 (ok: bool, errors: list)。

    前置条件（缺一即失败关闭）：
      ① 来源结果本身通过 `validate_source_result()`（查询传输成功）；
      ② `verify_record` 存在，且**通过既有严格证据校验**
         （缺字段 / 空壳 / 错误类型 —— 复用 `_evidence_rules`，
         与发布门禁同一份判定）；
      ③ `verified_on` 必须是合法日历日期且**不晚于今天**；
      ④ `verified_on` 与来源结果的 `verified_at` **必须同日**
         （不一致 → 失败关闭，**不得**改写 `verified_on` 伪装无冲突）；
      ⑤ `verify_source` 必须在真实来源白名单内。

    ⚠️ 本函数**只做加严**：任何一项不通过，都**不得**保存
    「现行有效 / verified_at / verify_source / verify_record」。
    """
    if today_date is None:
        today_date = today()
    errors = []
    sr = sr or {}

    vr = sr.get("verify_record")
    if not isinstance(vr, dict) or not vr:
        errors.append("verify_record 缺失或为空——不得保存核验成功状态")
        return False, errors

    if _EVIDENCE_RULES is not None:
        problems = _EVIDENCE_RULES.check_record(vr)
        if problems:
            errors.extend(problems)
    else:
        errors.append("严格证据校验模块不可用（fail-closed）")

    von = str(vr.get("verified_on") or "").strip()
    if not von:
        errors.append("verify_record.verified_on 为空——不得保存核验成功状态")
    elif not is_real_date(von):
        errors.append("verify_record.verified_on=%r 不是合法日历日期" % von)
    else:
        if datetime.date.fromisoformat(von) > today_date:
            errors.append("verify_record.verified_on=%s 晚于今天"
                          "（未来日期，疑似脚本批量填充）" % von)
        va = str(sr.get("verified_at") or "").strip()
        if not va:
            errors.append("来源结果缺 verified_at——无法确认核验日期一致性")
        elif va != von:
            errors.append("证据日期与查询日期不一致（verified_on=%s ≠ "
                          "verified_at=%s）——失败关闭，**不得**改写 "
                          "verified_on 伪装无冲突" % (von, va))

    vs = str(sr.get("verify_source") or "").strip()
    if not vs:
        errors.append("来源结果缺 verify_source——不得保存核验成功状态")
    elif vs not in VERIFY_REAL_SOURCES:
        errors.append("verify_source=%r 不在真实来源白名单内" % vs)

    return (not errors), errors


def normalize_case_effect(value) -> str:
    """把 case_effect 归一化到唯一正式值域。

    未知别名一律归 `unknown`，**不猜测**（方案第三节）。
    """
    v = _text(value)
    if v in CASE_EFFECT_VALUES:
        return v
    return CASE_EFFECT_ALIASES.get(v, "unknown")


def normalize_source_type(value) -> str:
    """source_type 归一化；未知值原样保留（便于报告缺口，不静默改写）。"""
    v = _text(value)
    return v or ""


# ════════════════════════════════════════════════════════════════════
# 2. authority_level 映射（严格从上到下优先匹配）
# ════════════════════════════════════════════════════════════════════

def compute_authority_level(fm: dict) -> tuple:
    """按映射表计算 `authority_level`。

    返回 (level, basis)；`basis` 是**可读依据**，写入 verify_record / 变更日志。
    `level` 恒为 AUTHORITY_LEVEL_VALUES 之一。

    ⚠️ 本函数**不做**人工覆盖判断——覆盖由 `apply_manual_overrides` 统一处理，
    避免「映射表」与「覆盖逻辑」两处各判一次产生不一致。
    """
    st = _text(fm.get("status"))
    stype = normalize_source_type(fm.get("source_type"))
    ce = normalize_case_effect(fm.get("case_effect"))
    jur = _text(fm.get("jurisdiction"))

    # ── 第 1 行：已明确失效 / 被推翻 / 不再参照 → 低 ──────────────
    #    「有依据支持，不能由未检出推定」——未检出不落到本行。
    if st in (STATUS_REPEALED, STATUS_OVERTURNED):
        return AL_LOW, "第1行：status=%s（已明确失效/被推翻，有依据支持）" % st
    if ce == "不再参照":
        return AL_LOW, "第1行：case_effect=不再参照（已明确不再参照，有依据支持）"

    # ── 第 2 行：当前有效性或材料类型无法判断（含 status=待核实）→ unknown ──
    if st in ("", STATUS_UNVERIFIED):
        return AL_UNKNOWN, ("第2行：status=%s（当前有效性无法判断，信息不足）"
                            % (st or "缺失"))
    if not stype:
        return AL_UNKNOWN, "第2行：source_type 缺失（材料类型无法判断）"

    # ── 第 3–7 行：裁判文书 ────────────────────────────────────────
    if stype in CASE_TYPES:
        if ce in ("指导性", "公报"):
            # 已批准优化①：指导性 / 公报**不受地域限制**
            return AL_HIGH, ("第3行：裁判文书＋case_effect=%s（不受地域限制，"
                             "地域=%s）" % (ce, jur or "未标注"))
        if ce == "典型案例":
            if jur in HIGH_TYPICAL_JURISDICTIONS:
                return AL_HIGH, ("第4行：裁判文书＋典型案例＋jurisdiction=%s"
                                 % jur)
            if jur and jur not in NON_GEO_JURISDICTIONS:
                return AL_MID, ("第5行：裁判文书＋典型案例＋其他明确地域=%s" % jur)
            return AL_UNKNOWN, ("第10行：裁判文书＋典型案例但地域缺失或非地域值"
                                "（%s），字段冲突，记录缺口" % (jur or "缺失"))
        if ce == "普通案例":
            return AL_MID, ("第6行：裁判文书＋普通案例（任何地域，地域=%s）"
                            % (jur or "未标注"))
        # 第 7 行：case_effect=unknown → 低
        return AL_LOW, ("第7行：裁判文书＋case_effect=unknown（仅为库内参考"
                        "排序，不代表已证明低效力）")

    # ── 第 8 行：规范类现行有效 → 高 ──────────────────────────────
    if stype in NORMATIVE_TYPES:
        if st == STATUS_CURRENT:
            return AL_HIGH, ("第8行：%s＋status=现行有效（库内参考优先级，"
                             "不表示法定效力相同）" % stype)
        return AL_UNKNOWN, ("第2行：%s 但 status=%s（当前有效性无法判断）"
                            % (stype, st))

    # ── 第 9 行：实务分析 → unknown ────────────────────────────────
    if stype in ANALYSIS_TYPES:
        return AL_UNKNOWN, ("第9行：%s（未另设可解释的评分办法）" % stype)

    # ── 第 10 行：其余未匹配 → unknown，记录缺口 ──────────────────
    return AL_UNKNOWN, ("第10行：source_type=%s 未匹配映射表（记录缺口）" % stype)


# ════════════════════════════════════════════════════════════════════
# 3. status 计算（依真实查询结果）
# ════════════════════════════════════════════════════════════════════

# 真实查询返回的效力事实 → status
_EFFECT_FACT_MAP = {
    "现行有效": STATUS_CURRENT,
    "有效": STATUS_CURRENT,
    "已废止": STATUS_REPEALED,
    "废止": STATUS_REPEALED,
    "已失效": STATUS_REPEALED,
    "被推翻": STATUS_OVERTURNED,
    "撤销": STATUS_OVERTURNED,
    "改判": STATUS_OVERTURNED,
}


def compute_status(source_result: dict) -> tuple:
    """依**真实查询结果**计算 `status`。

    `source_result` 为来源查询的结构化结果，至少包含：
      · `query_ok`（bool）：查询是否成功执行；
      · `effect_fact`（str）：来源明确给出的效力事实
        （现行有效 / 已废止 / 被推翻 / 尚未施行 / 已被修改 …）；
      · `kind`（str）：法规 / 案例 / 实务分析。

    返回 (status, reason)；status 恒为 STATUS_VALUES 之一。

    规则（方案第二节「status 建议写法」表）：
      · 来源明确支持仍有效              → 现行有效
      · 已被明确废止 / 替代              → 已废止（须另存废止说明）
      · 原裁判确被撤销 / 改判且有明确证据  → 被推翻（须记录后续文书）
      · 尚未施行 / 无法确认 / 来源冲突 /
        未查到原文 / 工具失败            → 待核实（记录具体原因）
      · 实务分析 / 专题（未建立独立有效性标准）→ 待核实

    ⚠️ **F05（Codex v1 反例）**：`query_ok` 必须经 `validate_source_result()`
    严格校验为**真布尔 True**；字符串 `"false"` / `""` / 数字 / list / dict
    **一律视为查询未成功**（此前 `bool(sr.get("query_ok"))` 会把 `"false"` 当成功）。
    """
    ok, sr, errors = validate_source_result(source_result)
    kind = sr.get("kind") or "法规"
    fact = sr.get("effect_fact")
    note = sr.get("note")

    # 实务分析 / 专题：没有独立有效性核验标准 → 待核实（但**不禁止入库**）
    if kind in ("实务分析", "专题"):
        return STATUS_UNVERIFIED, ("实务分析/专题未建立独立内容有效性核验标准，"
                                    "status=待核实（不阻断研究入库）")

    if not ok:
        detail = "；".join(errors) if errors else "（未提供原因）"
        return STATUS_UNVERIFIED, ("查询未成功执行（%s），status=待核实"
                                   % (note or detail or "来源不可用"))

    mapped = _EFFECT_FACT_MAP.get(fact)
    if mapped:
        return mapped, ("依来源查询结果（effect_fact=%s）判定为 %s"
                        % (fact, mapped))

    if fact in ("尚未施行", "未生效"):
        return STATUS_UNVERIFIED, ("来源明确显示尚未施行，status=待核实"
                                    "（须另记未来生效日期）")
    if fact in ("已被修改", "已修正"):
        return STATUS_UNVERIFIED, ("来源显示已被修改，须人工确认所存版本是否为"
                                    "现行版本，status=待核实")
    if fact == "未查到原文":
        return STATUS_UNVERIFIED, ("未查到原文（**未检出不推定不存在或已失效**），"
                                    "status=待核实")
    if fact == "来源冲突":
        return STATUS_UNVERIFIED, "来源之间存在冲突且未解决，status=待核实"

    return STATUS_UNVERIFIED, ("来源未给出可判定的效力事实（effect_fact=%s），"
                                "status=待核实" % (fact or "缺失"))


# ════════════════════════════════════════════════════════════════════
# 4. review_status 计算（依实际发布结果）
# ════════════════════════════════════════════════════════════════════

def compute_review_status(*, ingest_ok: bool = False,
                          index_ok: bool = False,
                          tech_gate_ok: bool = False,
                          human_reviewed: bool = False,
                          publish_known: bool = True,
                          current: str = "") -> tuple:
    """依**实际发布结果**计算 `review_status`。

    返回 (review_status, reason)。

    · 入 wiki 且写入 / 索引 / 必要技术校验**全部成功** → 已发布
    · 任一环节失败                                  → 草稿（**不得预先标记成功**）
    · 明确经人工审核但尚未入 wiki                    → 已审核

    ⚠️ **F01（Codex v1 反例）——发布结果未知时不得推定成功**：
    `publish_known=False` 表示**调用方未提供实际发布结果**（布尔值、路径、
    索引、校验结果均不可追溯）。此时：
      · **不得**因为三项全 False 就断言「发布流程失败」并降级已发布页；
      · **更不得**因为「页面在 wiki 目录里」就推定 ingest/index/tech 成功。
      · 一律返回 `草稿`（保守值），并在依据中注明「未提供实际发布结果」。
      已有 `已发布` 页由调用方按「保留原状态」处理（见 `_auto_meta.compute_page`），
      **不得在此处被静默降级**。
    """
    if not publish_known:
        return RS_DRAFT, ("未提供实际发布结果（发布状态不可追溯）→ 保守记为草稿；"
                          "**不得推定成功**，也不得仅因页面位于 wiki 目录就视为已发布")

    if human_reviewed and not ingest_ok:
        return RS_REVIEWED, "已人工审核、尚未入 wiki（由人工或有明确批准记录的流程设置）"
    if ingest_ok and index_ok and tech_gate_ok:
        return RS_PUBLISHED, ("已成功入 wiki 且写入/索引/必要技术校验全部成功 → 已发布"
                              "（**仅表示内部入库成功，不代表已人工审核**）")
    failed = []
    if not ingest_ok:
        failed.append("写入失败")
    if not index_ok:
        failed.append("索引失败")
    if not tech_gate_ok:
        failed.append("技术门禁失败")
    return RS_DRAFT, "发布流程未全部成功（%s）→ 仍为草稿" % "、".join(failed)


# ════════════════════════════════════════════════════════════════════
# 5. 人工覆盖（manual_overrides）
# ════════════════════════════════════════════════════════════════════

MANUAL_OVERRIDABLE = ("status", "authority_level", "review_status")


def read_manual_overrides(fm: dict) -> dict:
    """读出人工覆盖映射 {field: (value, reason, at)}。

    容错：结构不合法时**忽略该条**并返回空映射，绝不因此中断流程。
    """
    out = {}
    raw = (fm or {}).get("manual_overrides")
    if not isinstance(raw, list):
        return out
    for item in raw:
        if not isinstance(item, dict):
            continue
        field = _text(item.get("field"))
        if field not in MANUAL_OVERRIDABLE:
            continue
        value = item.get("value")
        if isinstance(value, (dict, list)) or value is None:
            continue
        out[field] = (_text(value), _text(item.get("reason")),
                      _text(item.get("at")))
    return out


def apply_manual_overrides(computed: dict, fm: dict) -> tuple:
    """把人工覆盖应用到自动计算结果上。

    `computed` —— 自动计算的 {field: (value, basis)}；
    `fm`       —— 页面现有 frontmatter（提供 manual_overrides）。

    返回 (final_values, notes)：
      · final_values —— {field: value} 最终应写入的值；
      · notes —— 每条覆盖的说明（写入变更日志）。

    规则：
      1. 命中人工覆盖 → 采用人工值，**不覆盖**；
      2. 人工值与自动值不同 → 记一条「人工覆盖优先」说明（**不视为错误**）；
      3. 人工值与新来源**矛盾** → 只报告，**不擅自抹去人工选择**。
    """
    final = {}
    notes = []
    ov = read_manual_overrides(fm)
    for field, (value, basis) in computed.items():
        final[field] = value
        notes.append({"field": field, "value": value, "basis": basis,
                      "origin": "auto"})
        if field in ov:
            mv, mreason, mat = ov[field]
            if mv and mv != value:
                notes.append({
                    "field": field, "value": mv, "basis":
                    "人工覆盖优先：保留人工值 %r（人工依据：%s；人工时间：%s）；"
                    "自动计算值为 %r（%s）——如与新来源矛盾，只报告不擅自抹去"
                    % (mv, mreason or "未记录", mat or "未记录", value, basis),
                    "origin": "manual_override",
                    "conflict": True,
                })
            final[field] = mv
            notes.append({"field": field, "value": mv,
                          "basis": "人工覆盖（人工依据：%s）" % (mreason or "未记录"),
                          "origin": "manual"})
    return final, notes


# ════════════════════════════════════════════════════════════════════
# 6. 核验日期的取值（last_verified / verified_at 分离）
# ════════════════════════════════════════════════════════════════════

#: **旧记录回退白名单**：只有 `verify_source` 落在此集合、且页面被识别为
#: 「可确认的旧记录」时，才允许用 `last_verified` 回退充当核验日期。
#:
#: ⚠️ **统一口径（Codex v1 指出：`_meta_rules.verification_date` 要求
#: `verified_at`，而 `_publish_gate` / `_check_gate` 允许 `last_verified` 回退，
#: 两处标准不一致）**——现全部改为调用本模块的 `resolve_verification()`，
#: **只有这一处**决定取哪个日期、是否允许回退、是否阻断。
VERIFY_AUTO_SOURCES = AUTO_VERIFY_SOURCES


def is_legacy_record(fm: dict, legacy_paths=None, rel_path: str = "") -> bool:
    """判断该页是否为**可确认的旧记录**（允许 `last_verified` 回退）。

    ⚠️ 判定必须**可确认**，不得凭「缺 `verified_at`」就推定为旧记录：

      ① `verify_source` 必须属自动核验来源；
      ② 页面**没有** `verified_at` 键（键存在但值为空 → **不是**旧记录，
         那是新记录漏填，属缺陷）；
      ③ 必须能命中**旧记录清单** `legacy_paths`（由调用方提供，
         通常来自基线清单 `_work_temp/_baseline/manifest.json` 的 entries）；
         清单不可用时**一律视为新记录**（fail-closed）。

    返回 bool。
    """
    fm = fm or {}
    vs = _text(fm.get("verify_source"))
    if vs not in VERIFY_AUTO_SOURCES:
        return False
    if "verified_at" in fm:      # 键存在（哪怕值为空）→ 新记录
        return False
    if legacy_paths is None:
        return False              # 清单不可用 → fail-closed
    if not rel_path:
        return False              # 无页面标识 → 无法确认 → fail-closed
    return _match_legacy_path(legacy_paths, rel_path)


def _match_legacy_path(legacy_paths, rel_path: str) -> bool:
    """判断相对路径是否落在旧记录清单内。

    同时接受「相对库根」（`wiki/01-labor/x.md`）与
    「相对 wiki/」（`01-labor/x.md`）两种写法。
    """
    if not legacy_paths or not rel_path:
        return False
    norm = str(rel_path).replace("\\", "/").strip("/")
    if norm in legacy_paths:
        return True
    if norm.startswith("wiki/") and norm[len("wiki/"):] in legacy_paths:
        return True
    if not norm.startswith("wiki/") and ("wiki/" + norm) in legacy_paths:
        return True
    return False


def resolve_verification(fm: dict, *, rel_path: str = "",
                          legacy_paths=None,
                          today_date: datetime.date = None) -> dict:
    """**统一**的核验日期解析（唯一真源）。

    返回 dict：
      · `date`      —— 实际采用的核验日期（"" 表示无）
      · `path`      —— 'manual' | 'auto' | 'legacy' | 'none'
      · `source`    —— verify_source 原值
      · `blockers`  —— 必须阻断的问题列表（空 = 可放行）
      · `notes`     —— 非阻断提示（如「待补 verified_at」）
      · `used_legacy_fallback` —— 是否走了旧记录回退

    口径（**所有门禁与 MCP 均调用本函数**，不得各自实现）：
      ① `verify_source = 人工核验` → 取 `last_verified`；缺失/非法 → **阻断**
      ② `verify_source` 属自动核验来源：
         · 有 `verified_at`（合法）→ 取之（path='auto'）
         · 无 `verified_at` **且**该页是**可确认的旧记录**
           → 回退取 `last_verified`（path='legacy'），**不阻断**，
             记 note「待补 verified_at」
         · 无 `verified_at` **且**属**新记录** → **阻断**
           （**新记录不得以旧人工日期放行**）
      ③ `verify_source` 为 `未核验`/`批量推定`/缺失 → 两个日期字段都必须为空，
         否则 **阻断**（R27 保留）
      ④ 核验日期晚于今天 → **阻断**（疑似脚本批量填充）
    """
    if today_date is None:
        today_date = today()
    fm = fm or {}
    vs = _text(fm.get("verify_source"))
    lv = _text(fm.get("last_verified"))
    va = _text(fm.get("verified_at"))
    has_va_key = "verified_at" in fm

    out = {"date": "", "path": "none", "source": vs,
           "blockers": [], "notes": [], "used_legacy_fallback": False}

    # V5.2: an official case publication is a distinct evidence path, not a
    # declaration that the underlying judgment or every cited statute was reverified.
    if vs == "官方案例发布文本":
        from _case_publication import published_case_gate
        ok, reasons = published_case_gate(fm)
        out['path'] = 'official_publication' if ok else 'none'
        out['blockers'] = reasons
        if ok:out['notes'] = ['已核对正式案例发布身份与文本；不要求原判决书，不生成核验日期']
        return out

    def _future(d):
        try:
            return datetime.date.fromisoformat(d) > today_date
        except ValueError:
            return False

    # ── ③ 未核验 / 历史兼容值 ──
    if vs in (VERIFY_UNVERIFIED, VERIFY_LEGACY_ESTIMATE, ""):
        if lv:
            out["blockers"].append(
                "verify_source=%s（未核验/历史兼容值）却填写了 last_verified=%r"
                % (vs or "缺失", lv))
        if va:
            out["blockers"].append(
                "verify_source=%s（未核验/历史兼容值）却填写了 verified_at=%r"
                % (vs or "缺失", va))
        if vs == VERIFY_LEGACY_ESTIMATE:
            out["notes"].append("verify_source=批量推定 仅为历史兼容值，"
                                "**不视为本次查询已完成**")
        return out

    # ── ① 人工核验 ──
    if vs == VERIFY_MANUAL:
        out["path"] = "manual"
        if not lv:
            out["blockers"].append("verify_source=人工核验 但 last_verified 为空")
        elif not is_real_date(lv):
            out["blockers"].append("last_verified=%r 非合法日历日期" % lv)
        elif _future(lv):
            out["blockers"].append(
                "last_verified=%s 晚于今天（未来日期，疑似脚本批量填充）" % lv)
        else:
            out["date"] = lv
        return out

    # ── ② 自动核验来源 ──
    if vs in VERIFY_AUTO_SOURCES:
        if has_va_key and va:
            out["path"] = "auto"
            if not is_real_date(va):
                out["blockers"].append("verified_at=%r 非合法日历日期" % va)
            elif _future(va):
                out["blockers"].append(
                    "verified_at=%s 晚于今天（未来日期，疑似脚本批量填充）" % va)
            else:
                out["date"] = va
            return out

        # 无 verified_at 值 → 判断是否可确认的旧记录
        legacy_ok = False
        if legacy_paths is not None and not has_va_key and rel_path:
            legacy_ok = _match_legacy_path(legacy_paths, rel_path)
        out["path"] = "legacy" if legacy_ok else "none"

        if legacy_ok and is_real_date(lv):
            out["date"] = lv
            out["used_legacy_fallback"] = True
            out["notes"].append(
                "旧记录兼容：该页为自动核验来源但**尚无 verified_at**，"
                "暂回退 last_verified=%s（仅历史提示；新记录不得如此放行）" % lv)
            if _future(lv):
                out["blockers"].append(
                    "last_verified=%s 晚于今天（未来日期，疑似脚本批量填充）" % lv)
                out["date"] = ""
            return out

        if legacy_ok and lv and not is_real_date(lv):
            out["blockers"].append(
                "旧记录兼容回退失败：last_verified=%r 非合法日历日期" % lv)
            return out

        # 新记录（或旧记录但无合法 last_verified）→ 阻断
        if has_va_key:
            out["blockers"].append(
                "verify_source=%s 属自动核验来源，但 verified_at 为空"
                "（**不得以编译时间冒充核验时间**）" % vs)
        else:
            out["blockers"].append(
                "verify_source=%s 属自动核验来源，但**新记录**无 verified_at"
                "（新记录不得以旧人工日期 last_verified 放行）" % vs)
        if lv and not is_real_date(lv):
            out["blockers"].append("last_verified=%r 非合法日历日期" % lv)
        return out

    out["blockers"].append(
        "verify_source=%s 不在已定义的核验来源白名单内" % vs)
    return out


def verification_date(fm: dict) -> tuple:
    """取出本页的核验日期与核验路径（**兼容旧调用方**的薄封装）。

    返回 (date_text, path, source, note)。

    ⚠️ 本函数现为 `resolve_verification()` 的薄封装，
    **默认按「不识别旧记录」处理**（fail-closed）——
    需要回退兼容的调用方必须显式传 `legacy_paths` 并调用
    `resolve_verification()`。

    规则：
      · `verify_source == 人工核验` → 用 `last_verified`（人工日期）；
      · `verify_source` 属自动核验来源 → 用 `verified_at`；
      · **人工日期缺失不再阻断真实自动核验**（方案第五节）。
    """
    fm = fm or {}
    vs = _text(fm.get("verify_source"))
    lv = _text(fm.get("last_verified"))
    va = _text(fm.get("verified_at"))

    if vs == VERIFY_MANUAL:
        if is_real_date(lv):
            return lv, "manual", vs, "人工核验日期 last_verified=%s" % lv
        return "", "none", vs, ("人工核验来源但 last_verified=%r 非合法日期"
                                % lv)
    if vs in AUTO_VERIFY_SOURCES:
        if is_real_date(va):
            return va, "auto", vs, "自动核验时间 verified_at=%s（来源 %s）" % (va, vs)
        return "", "none", vs, ("自动核验来源 %s 但 verified_at=%r 非合法日期"
                                "（**不得以编译时间冒充**）" % (vs, va))
    if vs in (VERIFY_UNVERIFIED, VERIFY_LEGACY_ESTIMATE, ""):
        return "", "none", vs, ("verify_source=%s（无有效核验来源）"
                                % (vs or "缺失"))
    return "", "none", vs, "verify_source=%s 不在已定义来源白名单内" % vs


def validate_verification(fm: dict, today_date: datetime.date = None) -> list:
    """校验核验链自洽性，返回问题列表（空列表 = 自洽）。

    校验项：
      ① verify_source 与核验日期**路径**匹配（人工→last_verified；自动→verified_at）；
      ② 核验日期不得晚于今天（未来日期＝疑似脚本批量填充）；
      ③ `批量推定` 为历史兼容值，**不视为本次查询已完成**；
      ④ 人工日期缺失**不阻断**真实自动核验（这是本轮的核心放宽点）。
    """
    if today_date is None:
        today_date = today()
    fm = fm or {}
    problems = []
    vs = _text(fm.get("verify_source"))
    lv = _text(fm.get("last_verified"))
    va = _text(fm.get("verified_at"))

    if vs in (VERIFY_UNVERIFIED, VERIFY_LEGACY_ESTIMATE, ""):
        if lv:
            problems.append("verify_source=%s（未核验/历史兼容值）却填写了 "
                            "last_verified=%r" % (vs or "缺失", lv))
        if va:
            problems.append("verify_source=%s（未核验/历史兼容值）却填写了 "
                            "verified_at=%r" % (vs or "缺失", va))
        if vs == VERIFY_LEGACY_ESTIMATE:
            problems.append("verify_source=批量推定 仅为历史兼容值，"
                            "**不视为本次查询已完成**")
        return problems

    if vs == VERIFY_MANUAL:
        if not lv:
            problems.append("verify_source=人工核验 但 last_verified 为空")
        elif not is_real_date(lv):
            problems.append("last_verified=%r 非合法日历日期" % lv)
        else:
            if datetime.date.fromisoformat(lv) > today_date:
                problems.append("last_verified=%s 晚于今天（未来日期，"
                                "疑似脚本批量填充）" % lv)
        return problems

    if vs in AUTO_VERIFY_SOURCES:
        if not va:
            problems.append("verify_source=%s 属自动核验来源，但 verified_at 为空"
                            "（**不得以编译时间冒充核验时间**）" % vs)
        elif not is_real_date(va):
            problems.append("verified_at=%r 非合法日历日期" % va)
        else:
            if datetime.date.fromisoformat(va) > today_date:
                problems.append("verified_at=%s 晚于今天（未来日期，"
                                "疑似脚本批量填充）" % va)
        # ④ 人工日期缺失**不阻断**自动核验——此处刻意不追加任何关于
        #    last_verified 为空的错误。
        return problems

    problems.append("verify_source=%s 不在已定义的核验来源白名单内" % vs)
    return problems


# ════════════════════════════════════════════════════════════════════
# 7. 一次性自动赋值入口（供脚本 / MCP 调用）
# ════════════════════════════════════════════════════════════════════

def auto_assign(fm: dict, source_result: dict,
                *, ingest_ok: bool = False, index_ok: bool = False,
                tech_gate_ok: bool = False,
                human_reviewed: bool = False,
                publish_known: bool = True) -> dict:
    """对单页执行三字段自动赋值（**不写文件**，只返回结果）。

    返回 dict：
      · `status` / `authority_level` / `review_status` —— 最终值；
      · `computed` —— 自动计算原值 {field: (value, basis)}；
      · `notes` —— 逐字段说明（含人工覆盖、冲突）；
      · `verified_at` —— 真实核验时间（无核验则空）；
      · `verify_source` —— 实际来源；
      · `verification` —— 核验链自洽性问题列表。

    ⚠️ **调用方须自行决定是否写回文件**——本函数是纯函数。

    ⚠️ **F03（Codex v1 反例）——依赖顺序**：
      旧实现先用**自动** status 算等级，最后才叠加人工覆盖，
      导致「人工把 status 固定为待核实、等级仍按自动 status 算出高」的不一致。
    现实现改为**三步**：
      ① 先确定**最终 status**（自动值 + status 自身的人工覆盖）；
      ② 再用**最终 status** 计算**未被人工覆盖**的 authority_level；
      ③ 最后处理 **authority_level 自身**的人工覆盖。
    冲突与依据全部保留在 `notes`。
    """
    fm = dict(fm or {})

    # ── ① 最终 status（自动 + 人工覆盖）──
    status, s_reason = compute_status(source_result)
    ov = read_manual_overrides(fm)
    status_final = status
    status_origin = "auto"
    if "status" in ov:
        mv = ov["status"][0]
        if mv and mv != status:
            status_final = mv
            status_origin = "manual_override"

    # ── ② 用最终 status 计算等级（等级自身的人工覆盖留到第③步）──
    probe_for_level = dict(fm)
    probe_for_level["status"] = status_final
    level, l_reason = compute_authority_level(probe_for_level)
    level_basis = l_reason
    if status_origin == "manual_override":
        level_basis = ("按**最终 status=%s**（人工覆盖值）计算：%s"
                       % (status_final, l_reason))

    # ── ③ review_status ──
    review, r_reason = compute_review_status(
        ingest_ok=ingest_ok, index_ok=index_ok, tech_gate_ok=tech_gate_ok,
        human_reviewed=human_reviewed, publish_known=publish_known)

    computed = {
        "status": (status_final, s_reason),
        "authority_level": (level, level_basis),
        "review_status": (review, r_reason),
    }
    final, notes = apply_manual_overrides(computed, fm)

    # ⚠️ F03 修复后的**冲突记录**补回：
    #   现在「最终 status」在进入 `apply_manual_overrides()` 之前就已取人工值，
    #   故该函数看不到「自动值 ≠ 人工值」这一差异 → 不会产出 conflict 记录。
    #   但「人工值与来源矛盾时只报告、不静默抹去」是**必须保留**的语义，
    #   故此处显式补记（人工 status 与自动计算 status 不一致时）。
    if status_origin == "manual_override":
        mv, mreason, mat = ov["status"]
        notes.append({
            "field": "status", "value": mv, "basis":
            "人工覆盖优先：保留人工值 %r（人工依据：%s；人工时间：%s）；"
            "自动计算值为 %r（%s）——如与新来源矛盾，只报告不擅自抹去"
            % (mv, mreason or "未记录", mat or "未记录", status, s_reason),
            "origin": "manual_override",
            "conflict": bool(status and status != mv),
        })

    # ── 核验时间与来源：只承接**真实执行过**的查询 ──
    ok, sr, sr_errors = validate_source_result(source_result)
    verified_at = ""
    verify_source = VERIFY_UNVERIFIED
    if ok:
        verified_at = sr.get("verified_at") or ""
        vs = sr.get("verify_source") or ""
        if vs and vs in VERIFY_REAL_SOURCES:
            verify_source = vs
        else:
            verified_at = ""

    probe = dict(fm)
    probe["status"] = final["status"]
    probe["authority_level"] = final["authority_level"]
    probe["review_status"] = final["review_status"]
    if verified_at:
        probe["verified_at"] = verified_at
    if verify_source:
        probe["verify_source"] = verify_source

    return {
        "status": final["status"],
        "authority_level": final["authority_level"],
        "review_status": final["review_status"],
        "computed": {k: {"value": v[0], "basis": v[1]} for k, v in computed.items()},
        "notes": notes,
        "verified_at": verified_at,
        "verify_source": verify_source,
        "verification": validate_verification(probe),
        "source_result_ok": ok,
        "source_result_errors": sr_errors,
        "status_origin": status_origin,
        "source_route": list(SOURCE_ROUTES.get(_text(sr.get("kind")) or "法规",
                                               SOURCE_ROUTES["法规"])),
        "rule_version": RULE_VERSION,
    }
