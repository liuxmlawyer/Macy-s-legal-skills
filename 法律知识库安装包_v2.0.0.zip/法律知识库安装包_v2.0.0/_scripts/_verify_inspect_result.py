"""V5 independent metadata integrity gate."""
from _verify_compact_metadata import main
if __name__ == "__main__":
    raise SystemExit(main())
