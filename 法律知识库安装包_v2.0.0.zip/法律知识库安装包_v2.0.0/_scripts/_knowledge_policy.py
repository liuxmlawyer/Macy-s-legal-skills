"""V5: one read-only policy for compact notes, sidecar evidence and usable/verified scopes."""
from pathlib import Path
import datetime as dt
import hashlib,json,re,os
import yaml

ROOT=Path(os.environ.get('KNOWLEDGE_ROOT') or os.environ.get('KB_ROOT') or Path(__file__).resolve().parent.parent)
FM=re.compile(r'\A---\s*\n(.*?)\n---(?:\n|$)',re.S)
CORE=('id','type','domain','jurisdiction','source_type','sources','citations','publish_status')
OPTIONAL=('status','effective_on','doc_no','case_no','court','judgment_date','case_effect','manual_overrides')

def read_raw(text):
    m=FM.match(text)
    if not m:raise ValueError('缺少frontmatter')
    data=yaml.safe_load(m[1])
    if not isinstance(data,dict):raise ValueError('frontmatter不是对象')
    return data,text[m.end():]

def semantic_hash(data,body):
    # Only whitespace and pure navigation-only lines are ignored, never arbitrary prose.
    lines=[]
    for line in body.splitlines():
        if re.fullmatch(r'\s*(?:-\s*)?(?:(?:引用|补充|关联|适用|区别)：\s*)?\[\[[^\]]+\]\](?:\s*[·•]\s*\[\[[^\]]+\]\])*\s*',line):continue
        line=line.strip()
        if line:lines.append(line)
    props={k:data.get(k) for k in CORE+OPTIONAL if k not in ('publish_status','manual_overrides')}
    return hashlib.sha256(json.dumps([props,lines],ensure_ascii=False,sort_keys=True,default=str).encode()).hexdigest()

def page_record(ident):
    if not re.fullmatch(r'[\w-]+',str(ident or '')):return None
    p=ROOT/'_meta/pages'/f'{ident}.json'
    if not p.is_file():return None
    return json.loads(p.read_text(encoding='utf-8'))

def hydrate(data):
    """Compatibility view is computed; it is never written back into a note."""
    if 'publish_status' not in data:return dict(data)
    out=dict(data)
    try:
        if (ROOT/'_meta/publish-locks'/f"{data.get('id')}.lock").exists():raise ValueError('页面正在写入；稍后重试，未完成事务不提供可用结果')
        rec=page_record(data.get('id'))
        if not rec:raise ValueError('缺少页面证据记录')
        if rec.get('id')!=data.get('id'):raise ValueError('外置记录ID不匹配')
        path=(ROOT/rec['path']).resolve()
        if not path.is_relative_to((ROOT/'wiki').resolve()):raise ValueError('证据路径越界')
        current,body=read_raw(path.read_text(encoding='utf-8-sig'))
        if current.get('id')!=data.get('id'):raise ValueError('证据ID不匹配')
        if semantic_hash(current,body)!=rec['content_hash']:raise ValueError('主要内容或业务属性已变化，需增量核对')
        old=rec.get('legacy',{})
        out={**old,**data}
        # Removed conditional note fields must not reappear from archived metadata in API output.
        # Legacy status remains the verified-scope compatibility basis, handled separately below.
        for field in OPTIONAL:
            if field not in ('status','manual_overrides') and field not in data:out.pop(field,None)
        # Compact-page lifecycle is authoritative, never resurrect an old published flag.
        out['review_status']={'可用':'已发布','草稿':'草稿','停用':'待复核'}.get(data.get('publish_status'),'草稿')
        out['release_blockers']=rec.get('issues',[])
        out['content_review_required']=bool(rec.get('issues'))
        records=[]
        for key in rec.get('evidence_refs',[]):
            ep=ROOT/'_meta/sources'/f'{key}.json'
            ev=json.loads(ep.read_text(encoding='utf-8'))
            canonical=json.dumps(ev,ensure_ascii=False,sort_keys=True,separators=(',',':'))
            if hashlib.sha256(canonical.encode()).hexdigest()!=key:raise ValueError('来源记录哈希不匹配')
            records.append(ev)
        out['verify_record']=records
        # Historical labels without evidence remain archived, not displayed as fresh verification facts.
        from _evidence_rules import check_one_record
        evidence_faults=[fault for i,ev in enumerate(records) for fault in check_one_record(ev,i)]
        if not records or evidence_faults:
            out['verify_source']='未核验';out['verified_at']='';out['last_verified']=''
            out['_evidence_gaps']=evidence_faults or ['尚无完整核验证据；不冒充已核验']
        out['_v5_record']=rec
        if rec.get('official_publications'):
            from _case_publication import publication_integrity
            faults=publication_integrity(rec)
            if faults:raise ValueError('；'.join(faults))
            if rec.get('official_publications_hash')==rec.get('content_hash'):
                out['verify_source']='官方案例发布文本'
                out['_verification_scope']='官方发布身份及已比对的案例文本；不代表所引法规均为现行版本'
        if data.get('source_type')=='实务分析' or rec.get('usage_class')=='author_summary':
            out['_basis_status']=old.get('status','待核实')
            out['status']='不适用（实务分析）'
        out['authority_level']=ranking(out)
        out['next_review']=next_review(out)
    except (ValueError,KeyError,OSError,TypeError) as exc:
        out['__policy_error__']=str(exc)
    return out

def ranking(data):
    # Preserve the approved priority semantics, separate from legal hierarchy and admission.
    for override in data.get('manual_overrides',[]) or []:
        if override.get('field')=='authority_level':return override['value']
    from _meta_rules import compute_authority_level
    view=dict(data);view['status']=data.get('_basis_status',data.get('status'))
    return compute_authority_level(view)[0]

def next_review(data):
    source=data.get('verify_source','')
    date=data.get('last_verified') if source=='人工核验' else data.get('verified_at')
    try:
        days=90 if data.get('domain') in ('01-labor','08-data') else 180 if data.get('domain') in ('04-ip','05-family','07-corporate') else 365
        return (dt.date.fromisoformat(str(date))+dt.timedelta(days=days)).isoformat()
    except (ValueError,TypeError):return data.get('next_review','')

def usable_gate(data):
    data=hydrate(data) if 'publish_status' in data and '_v5_record' not in data else data
    reasons=[]
    for k in ('__parse_error__','__parse_degraded__','__policy_error__'):
        if data.get(k):reasons.append(str(data[k]))
    status=data.get('publish_status')
    approved=status=='可用' if status is not None else data.get('review_status') in ('已发布','已审核')
    if not approved:reasons.append('未批准使用或已停用')
    issues=data.get('release_blockers') or []
    if not isinstance(issues,list):issues=[str(issues)]
    reasons+=issues
    flag=data.get('content_review_required')
    if flag is True or str(flag).lower()=='true':reasons.append('存在尚未解决的实质内容问题')
    rec=data.get('_v5_record')
    if status=='可用' and (not rec or not rec.get('approval')):reasons.append('缺可追溯的批准记录')
    if rec and rec.get('approval',{}):
        bound=rec['approval'].get('content_hash')
        if bound and bound!=rec.get('content_hash'):reasons.append('作者批准对应旧版本；请保存并发布当前版本')
    return not reasons,reasons

def verified_input(data):
    d=hydrate(data) if 'publish_status' in data and '_v5_record' not in data else dict(data)
    if d.get('source_type')=='实务分析':d['status']=d.get('_basis_status','待核实')
    return d

def usage_note(data):
    ok,reasons=usable_gate(data)
    if not ok:return '> 使用状态：未放行。'+ '；'.join(reasons)
    rec=data.get('_v5_record',{})
    if rec.get('usage_class')=='author_summary':
        return '> 来源身份：作者总结/实务分析，已获作者批准供默认检索；不要求官方发布或人工核验日期，所引依据按来源和适用条件使用。'
    if rec.get('usage_class') in ('local_source_summary','historical_local_summary'):
        return '> 来源范围：本地/历史材料整理，未完成法院官方全文实核；仅用于问题与来源线索定位，不据此直接认定现时个案事实或全国统一规则。'
    if data.get('source_type')=='实务分析':return '> 使用范围：已获准作为知识分析使用；所引规范的版本和适用条件另据来源记录，文章本身不适用法律效力状态。'
    if data.get('status')!='现行有效':return '> 使用范围：已获准使用；效力/版本尚未确证或属于历史材料，不能据此直接认定现行规则。'
    return ''

def split_note(data,body):
    return '---\n'+yaml.safe_dump(data,allow_unicode=True,sort_keys=False,width=100000).rstrip()+'\n---\n'+body

