# -*- coding: utf-8 -*-
"""G10 门禁：扫描残留的硬编码绝对路径（客户版）

【为什么需要】
把「不写死路径」变成可脚本化的门禁。路径写死后，一旦换机或换目录，
链接与索引会整体失效且不易察觉。

【判定口径】
代码目录（_scripts/ tools/）出现绝对路径 = 硬失败（应改用 _paths.py）。
文档目录（wiki/ raw/ draft/ rules.md README.md）出现绝对路径 = 提示，
因为文档里的路径是**写给人看的**，读者需要知道库在哪。

【与作者内部版的差异】
作者内部版按「带编号前缀 / 不带编号前缀」区分库名是否失真，
因为其库名是固定的。客户版的库名由客户自定，无法按名字判定，
因此改为**通用规则**：文档层出现绝对路径只提示不阻断；
代码层出现绝对路径一律阻断（代码里的路径必须走 _paths.py）。

【退出码】
  1 = 代码目录有硬编码绝对路径（真失真，须修）
  0 = 达标
"""

import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _paths import ROOT, SCRIPTS, TOOLS  # noqa: E402

# 通用绝对路径判定：盘符 + 路径分隔符（不限定目录名，客户库名任意）
# 要求盘符前不是字母数字（避免把 "citations:/n" 这类文本误判为路径），
# 且路径段须含分隔符或目录分隔标记，避免命中 "G5 xxx（a:/b）" 之类说明文字。
HARDCODE_RE = re.compile(r"(?<![\w])[A-Za-z]:[\\/]{1,2}(?:[^\s\"'<>|*?]+[\\/])+[^\s\"'<>|*?]*")

# 允许硬编码的文件：路径工具自身与本门禁自身。
SELF_FILES = {"_paths.py", "_verify_no_hardcoded_paths.py"}

# 文档目录：警告级
DOC_DIRS = ["wiki", "draft", "raw", "README.md", "rules.md"]
# 历史存档：不扫
ARCHIVE_DIRS = {"logs", ".git", ".obsidian", "__pycache__", "config"}
ARCHIVE_PREFIX = ("outputs/_skill", "outputs/_shots")


def is_archive(rel):
    if rel.startswith(ARCHIVE_PREFIX):
        return True
    return any(rel == d or rel.startswith(d + "/") for d in ARCHIVE_DIRS)


def doc_path_blocks(rel):
    """只读原始材料里的历史路径文本是证据，不是活动编译引用。"""
    return not rel.replace("\\", "/").startswith("raw/")


def scan_dir(rel_dir, exts):
    """扫描一个目录，返回 (代码层命中, 文档层命中)。"""
    base = os.path.join(ROOT, rel_dir) if not os.path.isabs(rel_dir) else rel_dir
    if os.path.isfile(base):
        files = [base]
    elif os.path.isdir(base):
        files = []
        for r, _sub, fs in os.walk(base):
            rp = os.path.relpath(os.path.join(r), ROOT).replace("\\", "/")
            if is_archive(rp):
                continue
            for f in fs:
                if f.endswith(exts):
                    files.append(os.path.join(r, f))
    else:
        return [], []

    hits = []
    for p in files:
        rp = os.path.relpath(p, ROOT).replace("\\", "/")
        if os.path.basename(p) in SELF_FILES or is_archive(rp):
            continue
        try:
            s = open(p, encoding="utf-8", errors="ignore").read()
        except Exception:
            continue
        for i, ln in enumerate(s.split("\n"), 1):
            if HARDCODE_RE.search(ln):
                hits.append((rp, i, ln.strip()[:110]))
    return hits, []


def main():
    print("=" * 74)
    print("G10 · 硬编码绝对路径扫描（客户版）")
    print("=" * 74)
    print("判定：")
    print("  代码目录出现绝对路径 = 硬失败（应改用 _paths.py）")
    print("  文档目录出现绝对路径 = 提示（文档路径是写给人看的）")
    print("排除：logs/ config/ .git/ __pycache__/ 等历史与配置存档\n")

    fail, doc_hits = [], []

    # 硬失败：代码目录任何绝对路径
    for d in (SCRIPTS, TOOLS):
        code_hits, _ = scan_dir(d, (".py", ".yaml", ".yml"))
        for rec in code_hits:
            fail.append(rec)
            print("  [FAIL] {0}:{1}".format(rec[0], rec[1]))
            print("         {0}".format(rec[2]))

    # 文档目录：仅提示
    from collections import Counter
    for d in DOC_DIRS:
        _c, docs = scan_dir(d, (".md", ".html", ".json"))
        for rec in docs:
            if not doc_path_blocks(rec[0]):
                continue
            doc_hits.append(rec)
            print("  [DOC] {0}:{1}".format(rec[0], rec[1]))
            print("       {0}".format(rec[2]))

    sc = Counter(rp for rp, _i, _l in doc_hits)
    print("\n  文档层绝对路径（提示）：{0} 个文件 / {1} 处".format(len(sc), len(doc_hits)))
    for rp, n in sc.most_common(5):
        print("      {0}  ({1} 处)".format(rp, n))
    if len(sc) > 5:
        print("      ...另 {0} 个文件".format(len(sc) - 5))

    print("\n" + "=" * 74)
    print("硬失败 {0} 处 | 文档提示 {1} 处".format(len(fail), len(doc_hits)))

    if fail:
        print("\n结论：FAIL —— 代码层存在会失效的绝对路径，须改用 _paths.py。")
        print("修复方式：把代码里的绝对路径改为 from _paths import ROOT（或对应常量）。")
        sys.exit(1)
    print("\n结论：PASS —— 代码层无硬编码绝对路径；文档层绝对路径仅为提示。")


if __name__ == "__main__":
    main()
