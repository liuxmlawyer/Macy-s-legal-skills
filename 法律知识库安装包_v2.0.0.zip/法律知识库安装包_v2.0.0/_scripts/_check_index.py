import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _paths import ROOT  # 路径单一真源（V3.7）
import io, os, re, sys
from collections import Counter

os.chdir(ROOT + r"\raw\06-资料包索引")
tot = ok = bad = 0
bads = []
for f in sorted(os.listdir('.')):
    if not f.endswith('-资料包索引.md'):
        continue
    for line in io.open(f, encoding='utf-8'):
        m = re.match(r'^location:\s*(.+?)\s*$', line)
        if not m:
            continue
        tot += 1
        p = os.path.normpath(os.path.join(ROOT, m.group(1)))
        if os.path.exists(p):
            ok += 1
        else:
            bad += 1
            bads.append((f, m.group(1)))

print('location 总条目', tot, '| 有效', ok, '| 失效', bad)
print()
print('失效条目按原目录分布:')
for k, v in Counter(b.split('/')[1] for _, b in bads).most_common():
    print('  ', k, v)
print()
print('失效样例:')
for f, b in bads[:10]:
    print('  ', f, '->', b)

if bad:
    sys.exit(1)
