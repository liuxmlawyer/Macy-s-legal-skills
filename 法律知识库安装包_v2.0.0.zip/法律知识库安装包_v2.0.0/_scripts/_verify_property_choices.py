"""Selectable-property schema validation; selecting usable never substitutes for admission."""
from pathlib import Path
import json,datetime as dt
from _paths import ROOT
from _knowledge_policy import read_raw
def main():
    root=Path(ROOT);schema=json.loads((root/'_meta/property-options.json').read_text(encoding='utf-8'));errors=[];count=0
    for p in (root/'wiki').rglob('*.md'):
        try:d,_=read_raw(p.read_text(encoding='utf-8-sig'))
        except ValueError:continue
        count+=1
        for field in ("judgment_date","effective_on"):
            if field in d:
                try:dt.date.fromisoformat(str(d[field]))
                except ValueError:errors.append(str(d.get("id"))+"：日期必须完整或留空："+field)
        for k,cfg in schema['fields'].items():
            if k not in d:
                if not cfg['optional']:errors.append(f'{d.get("id")}：缺必需选项{k}')
                continue
            if d[k] not in cfg['options']:errors.append(f'{d.get("id")}：{k}不是已定义选择项：{d[k]}')
    for e in errors:print('FAIL',e)
    print(f'属性选择检查：{count}页，{len(errors)}项错误；'+('FAIL' if errors else 'PASS'))
    return bool(errors)
if __name__=='__main__':raise SystemExit(main())
