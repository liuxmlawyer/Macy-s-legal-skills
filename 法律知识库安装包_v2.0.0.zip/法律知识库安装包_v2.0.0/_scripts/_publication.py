"""Explicit author publication: stable intent, version binding and recoverable paired writes."""
from pathlib import Path
import contextlib,datetime as dt,hashlib,json,os,re,uuid
import _knowledge_policy as K

def stamp():return dt.datetime.now().astimezone().isoformat(timespec='seconds')

def prepare(data,body,record,basis,action='publish',accept_revision=False):
    if not str(basis).strip():raise ValueError('缺少作者发布操作依据')
    d=dict(data);rec=json.loads(json.dumps(record,ensure_ascii=False))
    if rec.get('id')!=d.get('id'):raise ValueError('页面与外置记录ID不符')
    if action not in ('publish','withdraw'):raise ValueError('未知发布操作')
    if action=='publish' and rec.get('issues'):raise ValueError('存在实质问题：'+'；'.join(map(str,rec['issues'])))
    current_hash=K.semantic_hash(d,body)
    if current_hash!=rec.get('content_hash') and not accept_revision:raise ValueError('内容已经变化，请使用保存并发布确认当前版本')
    if any(k not in d for k in K.CORE):raise ValueError('缺少基础属性，请先自动编译')
    for field in ('sources','citations'):
        if not isinstance(d[field],list):raise ValueError(field+'必须是列表')
    when=stamp();previous=rec.get('approval')
    if previous:rec.setdefault('approval_history',[]).append(previous)
    d['publish_status']='可用' if action=='publish' else '停用'
    rec['approval']={'kind':'author_publication','basis':basis,'recorded_on':when,'content_hash':current_hash,'not_a_new_human_verification':True} if action=='publish' else None
    rec['content_hash']=current_hash
    rec.setdefault('publication_history',[]).append({'at':when,'action':action,'basis':basis,'previous_status':data.get('publish_status'),'confirmed_revision':accept_revision})
    if d.get('type')=='topic' and not rec.get('official_publications'):
        rec['usage_class']='author_summary'
    return d,rec

def atomic_bytes(path,content):
    tmp=path.with_name(path.name+'.'+uuid.uuid4().hex+'.pending')
    try:
        with tmp.open('xb') as f:f.write(content);f.flush();os.fsync(f.fileno())
        os.replace(tmp,path)
    finally:
        if tmp.exists():tmp.unlink()

@contextlib.contextmanager
def page_lock(root,ident):
    if not re.fullmatch(r'[\w-]+',str(ident)):raise ValueError('无效ID')
    p=Path(root)/'_meta/publish-locks'/f'{ident}.lock';p.parent.mkdir(parents=True,exist_ok=True)
    try:fd=os.open(p,os.O_CREAT|os.O_EXCL|os.O_WRONLY)
    except FileExistsError:raise ValueError('本页正在写入或存在待恢复事务：'+str(p))
    try:
        os.write(fd,str(os.getpid()).encode());os.close(fd)
        yield
    finally:p.unlink(missing_ok=True)

def commit_pair(root,path,expected_note,expected_record,new_note,new_record):
    """All cooperating writers use one exclusive lock; readers reject in-flight writes.

    Journal retains old/new bytes. CAS conflicts never overwrite a later third-party edit.
    """
    root=Path(root).resolve();path=Path(path).resolve()
    if not path.is_relative_to(root/'wiki'):raise ValueError('仅允许wiki知识页')
    ident=new_record['id'];rp=root/'_meta/pages'/f'{ident}.json'
    if new_record.get('path')!=path.relative_to(root).as_posix():raise ValueError('外置记录路径不符')
    newr=(json.dumps(new_record,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
    tx=root/'_meta/transactions'/uuid.uuid4().hex;tx.mkdir(parents=True)
    with page_lock(root,ident):
        if path.read_bytes()!=expected_note or rp.read_bytes()!=expected_record:raise ValueError('并发修改，已停止；请重新读取后发布')
        for name,raw in [('note.before',expected_note),('record.before',expected_record),('note.after',new_note),('record.after',newr)]:
            (tx/name).write_bytes(raw)
        journal={'id':ident,'path':path.relative_to(root).as_posix(),'state':'prepared'}
        def log(state):
            journal['state']=state;atomic_bytes(tx/'journal.json',(json.dumps(journal,ensure_ascii=False)+'\n').encode())
        log('prepared')
        try:
            atomic_bytes(path,new_note)
            if rp.read_bytes()!=expected_record or path.read_bytes()!=new_note:raise ValueError('事务期间文件变化')
            atomic_bytes(rp,newr)
            if path.read_bytes()!=new_note or rp.read_bytes()!=newr:raise ValueError('写后检测到并发变化')
            log('committed')
        except Exception:
            # Roll back only our own bytes; preserve anything written by a non-cooperating editor.
            if path.read_bytes()==new_note:atomic_bytes(path,expected_note)
            if rp.read_bytes()==newr:atomic_bytes(rp,expected_record)
            log('rolled_back' if path.read_bytes()==expected_note and rp.read_bytes()==expected_record else 'conflict_preserved')
            raise
    return tx.relative_to(root).as_posix()

def publish_page(path,basis,root=None,accept_revision=False,action='publish'):
    root=Path(root or K.ROOT).resolve();path=Path(path).resolve()
    old=path.read_bytes();data,body=K.read_raw(path.read_text(encoding='utf-8-sig'))
    if not re.fullmatch(r'[\w-]+',str(data.get('id',''))):raise ValueError('无效ID')
    rp=root/'_meta/pages'/f"{data['id']}.json";oldr=rp.read_bytes();record=json.loads(oldr)
    data,record=prepare(data,body,record,basis,action,accept_revision)
    # Only lifecycle changes are needed in batch publication; preserve body and formatting bytes.
    text=old.decode('utf-8-sig');pattern=r'(?m)^publish_status:[^\r\n]*'
    if len(re.findall(pattern,text))!=1:raise ValueError('发布状态字段不唯一')
    text=re.sub(pattern,'publish_status: '+data['publish_status'],text)
    encoded=(b'\xef\xbb\xbf' if old.startswith(b'\xef\xbb\xbf') else b'')+text.encode('utf-8')
    tx=commit_pair(root,path,old,oldr,encoded,record)
    return {'id':data['id'],'path':path.relative_to(root).as_posix(),'status':data['publish_status'],'transaction':tx}
