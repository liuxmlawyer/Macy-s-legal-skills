"""Official case publications are evidence in their own right, not missing judgments."""
import hashlib,json,re
from urllib.parse import urlsplit
import _knowledge_policy as K

def official_url(url):
    host=(urlsplit(str(url)).hostname or '').lower()
    return host.endswith('.court.gov.cn') or host=='court.gov.cn' or host.endswith('.gov.cn')

def publication_integrity(rec):
    publications=rec.get('official_publications') or []
    if not publications:return ['未登记可追溯的官方案例发布文本']
    for source in publications:
        if not official_url(source.get('url')):return ['官方案例发布地址身份不符']
        if not source.get('locator'):return ['缺案例发布身份定位']
        path=(K.ROOT/str(source.get('cache',''))).resolve()
        if not path.is_relative_to((K.ROOT/'_meta/fetch-cache').resolve()):return ['官方案例缓存路径越界']
        try:raw=path.read_bytes()
        except OSError:return ['已登记的官方案例缓存缺失']
        if hashlib.sha256(raw).hexdigest()!=source.get('sha256'):return ['官方案例发布原文被改动']
        normalized=re.sub(r'\s|<[^>]*>','',raw.decode('utf-8-sig'))
        locator=re.sub(r'\s','',source['locator'])
        if locator not in normalized:return ['编号或标题与官方发布文本不匹配']
    return []

def published_case_gate(data):
    rec=data.get('_v5_record',{})
    faults=publication_integrity(rec)
    if faults:return False,faults
    if rec.get('official_publications_hash')!=rec.get('content_hash'):return False,['官方案例发布内容绑定已变化，需复核差异']
    if data.get('case_effect')=='不再参照':return False,['该指导案例已标记不再参照；仍可按历史范围使用']
    return True,[]
