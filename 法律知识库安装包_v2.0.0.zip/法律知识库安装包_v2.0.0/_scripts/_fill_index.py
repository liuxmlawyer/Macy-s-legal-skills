# -*- coding: utf-8 -*-
"""自动补全领域索引中「（待补充）」的词条/案例/专题章节。

规则：
- 只处理含「（待补充）」占位符的章节
- 双链格式 [[文件名|显示名]]，文件名去掉 .md
- 按文件名排序写入表格
- 不动已有内容的章节
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _paths import ROOT  # 路径单一真源（V3.7）
import os, re, io

ROOT = ROOT
WIKI = os.path.join(ROOT, "wiki")

SEC = {
    "词条": ("terms", "## 词条"),
    "案例": ("cases", "## 案例"),
    "专题": ("topics", "## 实务专题"),
}

report = []
for dom in sorted(os.listdir(WIKI)):
    dpath = os.path.join(WIKI, dom)
    if not os.path.isdir(dpath) or not re.match(r"^\d\d-", dom):
        continue
    idx = os.path.join(dpath, f"{dom}-index.md")
    if not os.path.exists(idx):
        continue
    txt = open(idx, encoding="utf-8", errors="ignore").read()
    orig = txt

    # 定位每个 ## 章节到下一个 ## 或 ---
    for key, (sub, header) in SEC.items():
        m = re.search(rf"(^{re.escape(header)}[^\n]*\n)(.*?)(?=\n## |\n---|\Z)", txt, re.M | re.S)
        if not m:
            continue
        body = m.group(2)
        if "（待补充）" not in body and "待补充" not in body:
            continue
        dsub = os.path.join(dpath, sub)
        if not os.path.isdir(dsub):
            continue
        files = sorted(f for f in os.listdir(dsub) if f.endswith(".md"))
        if not files:
            continue
        lines = [f"- [[{f[:-3]}]]" for f in files]
        newsec = f"## {key}（{len(files)}）\n\n" + "\n".join(lines) + "\n"
        txt = txt[:m.start()] + newsec + txt[m.end():]
        report.append(f"{dom}/{sub}  补登记 {len(files)} 页")

    if txt != orig:
        open(idx, "w", encoding="utf-8", newline="").write(txt)

print("\n".join(report) if report else "无占位符需补")