# -*- coding: utf-8 -*-
"""发布前强校验（gate）。任一项 FAIL 即不得进 wiki。

检查项：
  G1 YAML 可解析（yaml.safe_load 真跑，不是查存在性）
  G2 frontmatter 必填字段非空
  G3 id 全库唯一
  G4 页面已登记到领域索引
  G5 禁用写法残留（citations:/n、index.md 命名、待人工核验占位）
  G6 索引文件名合规（不得用 index.md）

用法：
  python _scripts/_check_gate.py            # 全量体检，写报告
  python _scripts/_check_gate.py --changed  # 只查 git 变更文件（发布前用）
退出码：0 = 通过；1 = 有 FAIL
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _paths import ROOT  # 路径单一真源（V3.7）
import glob, os, re, sys, io, subprocess, collections

ROOT = ROOT
WIKI = os.path.join(ROOT, "wiki")

REQUIRED = ["id", "type", "domain", "status", "authority_level", "review_status"]

# 【V4.1 修订 · RULE-20261025-001】核验字段自洽规则**重写**。
#
# 旧规则（V4.1 前）：
#   verify_source 属真实核验来源 → last_verified 必须非空且合法；
#   verify_source 为「未核验」「批量推定」或缺失 → last_verified 必须留空。
#
# 冲突所在：旧规则把**人工核验日期**当成核验成立的前提，
# 于是「规则允许自动填写、脚本仍要求人工前置」的矛盾长期存在——
# 页面由自动来源（flk-npc / 人民法院案例库 / pkulaw / 官方站点直查）
# 取得真实核验证据后，仍因 last_verified 为空而被判 FAIL，
# 逼使人把 last_verified 填成当前日期（正是 R27 要根除的伪造核验）。
#
# 新规则（rules.md V4.1 / R27 修订）：
#   · verify_source = 人工核验       → last_verified 必须非空且为合法日期；
#   · verify_source = 自动核验来源   → verified_at 必须非空且为合法日期；
#     （**last_verified 允许为空**——它是人工核验日期，AI 不填，
#       不得以「人工日期缺失」阻断真实自动核验）
#   · verify_source 为「未核验」「批量推定」或缺失
#     → last_verified 与 verified_at **都必须留空**；
#       若填写了日期，判为「伪造核验记录」并 FAIL（R27 保留）
#   · 两条路径的日期都**不得晚于今天**（未来日期＝疑似脚本批量填充）
VERIFY_REAL = {"人工核验", "flk-npc", "人民法院案例库", "pkulaw", "wk",
               "官方站点直查", "samr", "npc.gov.cn"}
VERIFY_AUTO = {"flk-npc", "人民法院案例库", "pkulaw", "wk",
               "官方站点直查", "samr", "npc.gov.cn"}
VERIFY_NONE = {"未核验", "批量推定", ""}

DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")

# ── 核验链规则引擎 + 旧记录清单（唯一真源，Codex v1 要求统一口径）──────
# ⚠️ RULE-20261025-001 v2 补正：本文件**不再自行实现**核验日期判定，
#    统一调用 `_meta_rules.resolve_verification()`；旧记录清单由
#    `_legacy_pages.load_legacy_paths()` 提供（基线 manifest 权威来源，
#    不可用时 fail-closed → 一律按新记录处理）。
_META_RULES = None
_META_RULES_TRIED = False
_LEGACY_PATHS = None


def _load_meta_rules():
    """载入 `_meta_rules` 模块（失败返回 None → 调用方 fail-closed）。"""
    global _META_RULES, _META_RULES_TRIED
    if _META_RULES_TRIED:
        return _META_RULES
    _META_RULES_TRIED = True
    try:
        import importlib.util
        here = os.path.dirname(os.path.abspath(__file__))
        path = os.path.join(here, "_meta_rules.py")
        if not os.path.isfile(path):
            return None
        spec = importlib.util.spec_from_file_location("_meta_rules", path)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        _META_RULES = mod
    except Exception:
        _META_RULES = None
    return _META_RULES


def _legacy_paths():
    """加载可确认的旧记录清单（不可用 → 空集合 → fail-closed）。"""
    global _LEGACY_PATHS
    if _LEGACY_PATHS is None:
        try:
            import importlib.util
            here = os.path.dirname(os.path.abspath(__file__))
            path = os.path.join(here, "_legacy_pages.py")
            spec = importlib.util.spec_from_file_location("_legacy_pages", path)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            _LEGACY_PATHS = mod.load_legacy_paths(root=ROOT)
        except Exception:
            _LEGACY_PATHS = set()
    return _LEGACY_PATHS


def _resolve_verification(fm: dict, rel_path: str = "") -> dict:
    """调用唯一真源解析核验日期；规则引擎不可用 → fail-closed（阻断）。"""
    mr = _load_meta_rules()
    if mr is None:
        return {"date": "", "path": "none", "source": "",
                "blockers": ["核验链规则引擎（_meta_rules）不可用，无法判定核验日期"
                             "（fail-closed）"],
                "notes": [], "used_legacy_fallback": False}
    try:
        return mr.resolve_verification(
            fm, rel_path=rel_path, legacy_paths=_legacy_paths())
    except Exception as exc:
        return {"date": "", "path": "none", "source": "",
                "blockers": ["核验日期解析异常（fail-closed）：%s: %s"
                             % (type(exc).__name__, exc)],
                "notes": [], "used_legacy_fallback": False}


def _is_real_date(s):
    """严格日历校验：格式 + 真实存在的日期。

    ⚠️ 不能只靠正则或 `datetime.date.fromisoformat`——后者在 Python 3.11+
    对 "2026-10-23" 这类溢出值会**静默容忍**（回退到 ISO 周日期解析），
    会让 57 页机器填充错位的非法日期蒙混过关。
    """
    if not DATE_RE.match(s or ""):
        return False
    try:
        y, m, d = (int(x) for x in s.split("-"))
        import datetime
        return datetime.date(y, m, d).isoformat() == s
    except (ValueError, TypeError):
        return False

# 合理例外：库级自述文档（非知识页，不需登记内容索引）与跨域文档
EXEMPT_NO_INDEX = re.compile(r"法律知识库(使用手册|搭建指南)|Obsidian排版|排版效果|法律工具|操作指南")
# 索引页自身不需要被别的索引登记
def is_index(p):
    return bool(re.search(r"-index\.md$", os.path.basename(p)))

def yaml_parse(txt):
    """返回 (dict, None) 或 (None, 错误信息)"""
    if not txt.startswith("---"):
        return None, "无 frontmatter"
    end = txt.find("\n---", 3)
    if end == -1:
        return None, "frontmatter 未闭合"
    try:
        import yaml
        d = yaml.safe_load(txt[3:end])
    except Exception as e:
        return None, f"YAML 解析失败: {type(e).__name__}"
    if not isinstance(d, dict):
        return None, "frontmatter 解析结果非字典"
    from _knowledge_policy import hydrate
    return hydrate(d), None

def changed_files():
    """列出 git 变更文件。

    ⚠️ 2026-10-19 修复：原实现用 `git status --porcelain` 逐行取 line[3:]，
    但 git 默认对**非 ASCII 路径做八进制转义并加引号**
    （如 "wiki/04-ip/terms/\345\217\217..."），导致取到的字符串不是真实路径，
    os.path.exists 全部失败 → 中文名文件被静默漏检，门禁显示「全部通过 ✅」。
    改用 -z（NUL 分隔、不转义、不加引号）。
    """
    try:
        r = subprocess.run(["git", "-c", "core.quotepath=false", "status", "--porcelain", "-z"],
                           cwd=ROOT, capture_output=True, text=True,
                           encoding="utf-8", errors="ignore")
        out = []
        # -z 格式：每条记录为 "XY <path>"，改名时为 "XY <new>\0<old>\0"
        entries = [e for e in r.stdout.split("\0") if e.strip()]
        for i, e in enumerate(entries):
            if len(e) <= 3:
                continue
            p = e[3:].strip()
            if " -> " in p:          # 改名记录
                p = p.split(" -> ", 1)[1]
            # 跳过 --porcelain -z 中紧随改名记录之后的 old-path 记录
            nxt = entries[i + 1] if i + 1 < len(entries) else ""
            if nxt and len(nxt) > 3 and not nxt[:2].strip():
                pass
            out.append(os.path.join(ROOT, p.replace("/", os.sep)))
        return out
    except Exception:
        return []

def main():
    import yaml  # 依赖；缺失则明确报错

    only_changed = "--changed" in sys.argv
    targets = []
    if only_changed:
        for p in changed_files():
            if p.endswith(".md") and os.path.exists(p) and "wiki" in p:
                targets.append(p)
    else:
        targets = [p for p in glob.glob(os.path.join(WIKI, "**", "*.md"), recursive=True)]

    fails = collections.defaultdict(list)
    # 提示项（不阻断）：如「待补 verified_at」的存量页兼容提示
    notes = collections.defaultdict(list)

    # 收集全部页面用于 id / 索引检查
    all_pages = [p for p in glob.glob(os.path.join(WIKI, "**", "*.md"), recursive=True)]

    # 索引文本池
    idx_pool = []
    for p in all_pages:
        if re.search(r"-index\.md$", os.path.basename(p)):
            try:
                idx_pool.append(open(p, encoding="utf-8", errors="ignore").read())
            except Exception:
                pass
    idx_text = "\n".join(idx_pool)

    # 全库 id 唯一性（只在全量模式检查，changed 模式下仍需全库扫描）
    id_map = collections.defaultdict(list)
    for p in all_pages:
        d, _ = yaml_parse(open(p, encoding="utf-8", errors="ignore").read())
        if d and d.get("id"):
            id_map[str(d["id"])].append(os.path.relpath(p, ROOT))

    for p in targets:
        rel = os.path.relpath(p, ROOT)
        txt = open(p, encoding="utf-8", errors="ignore").read()

        # G5 禁用写法
        if ":/n" in txt:
            fails["G5 禁用写法(/n 残留)"].append(rel)
        if os.path.basename(p) == "index.md":
            fails["G5 禁用写法(index.md 命名)"].append(rel)

        d, err = yaml_parse(txt)
        if err:
            if "无 frontmatter" in err:
                # 允许：wiki 根目录的操作手册/工具文档
                if not re.search(r"wiki\\(操作指南|法律|排版|Obsidian)", p):
                    fails["G1 YAML 可解析"].append(f"{rel} — {err}")
            else:
                fails["G1 YAML 可解析"].append(f"{rel} — {err}")
            continue

        # G2 必填字段
        if not EXEMPT_NO_INDEX.search(os.path.basename(p)):
            miss = [f for f in REQUIRED if not d.get(f)]
            if miss:
                fails["G2 必填字段非空"].append(f"{rel} — 缺 {','.join(miss)}")

        # G2b 核验字段自洽 —— **统一调用 _meta_rules.resolve_verification()**
        #    （唯一真源；`_publish_gate` 与 MCP 也调同一函数）
        #    ⚠️ Codex v1 指出：旧实现在本文件内另行判定，且允许
        #    「自动来源缺 verified_at → 回退 last_verified」，
        #    与 `_meta_rules.verification_date`（要求 verified_at）标准分裂。
        #    现全部收敛到唯一实现；旧记录回退**仅限可确认的旧记录**
        #    （命中基线清单且无 verified_at 键），新记录缺 verified_at 一律阻断。
        rv = _resolve_verification(d, rel_path=rel)
        for b in rv["blockers"]:
            fails["G2b 核验字段自洽"].append(f"{rel} — {b}")
        for n in rv.get("notes", []):
            notes.setdefault("待补 verified_at", []).append(f"{rel} — {n}")

        # G3 id 唯一
        idv = str(d.get("id", ""))
        if idv and len(id_map.get(idv, [])) > 1:
            fails["G3 id 唯一"].append(f"{rel} — id={idv} 与 {len(id_map[idv])-1} 处冲突")

        # G4 索引登记
        stem = os.path.splitext(os.path.basename(p))[0]
        if not is_index(p) and stem not in idx_text \
                and not EXEMPT_NO_INDEX.search(os.path.basename(p)):
            fails["G4 已登记索引"].append(rel)

    # G6 索引命名合规（全量）
    if not only_changed:
        for p in all_pages:
            if os.path.basename(p) == "index.md":
                fails["G6 索引命名合规"].append(os.path.relpath(p, ROOT))

    # 输出
    buf = io.StringIO()
    total = sum(len(v) for v in fails.values())
    print(f"发布前强校验 | 模式：{'仅变更文件' if only_changed else '全量'} | 目标 {len(targets)} 页")
    print("=" * 60)
    if total == 0:
        print("全部通过 ✅")
        print(f"  检查项：G1 YAML可解析 / G2 必填字段 / G2b 核验字段自洽 / G3 id唯一 / G4 索引登记 / G5 禁用写法 / G6 索引命名")
    else:
        for k in sorted(fails):
            print(f"\n✘ {k} —— {len(fails[k])} 项")
            for x in fails[k][:25]:
                print(f"    - {x}")
            if len(fails[k]) > 25:
                print(f"    ... 另有 {len(fails[k]) - 25} 项")
        print("\n" + "=" * 60)
        print(f"合计 FAIL：{total} 项 —— 按 rules.md 不得发布")

    # 提示项（不阻断）
    if notes:
        print("\nℹ 提示（不阻断）：")
        for k in sorted(notes):
            print(f"  · {k} —— {len(notes[k])} 项")
            for x in notes[k][:10]:
                print(f"      - {x}")
            if len(notes[k]) > 10:
                print(f"      ... 另有 {len(notes[k]) - 10} 项")

    # 写报告
    rep = os.path.join(ROOT, "lint-reports", "发布前强校验报告.txt")
    with open(rep, "w", encoding="utf-8") as f:
        f.write(f"发布前强校验 {time_str()}\n")
        f.write(f"模式：{'仅变更文件' if only_changed else '全量'}  目标 {len(targets)} 页\n")
        f.write("=" * 60 + "\n")
        if total == 0:
            f.write("全部通过\n")
        else:
            for k in sorted(fails):
                f.write(f"\nFAIL {k} —— {len(fails[k])} 项\n")
                for x in fails[k]:
                    f.write(f"  - {x}\n")
            f.write(f"\n合计 {total} 项\n")
        if notes:
            f.write("\n提示（不阻断）\n")
            for k in sorted(notes):
                f.write(f"\nNOTE {k} —— {len(notes[k])} 项\n")
                for x in notes[k]:
                    f.write(f"  - {x}\n")
    print(f"\n报告：{os.path.relpath(rep, ROOT)}")
    sys.exit(1 if total else 0)

def time_str():
    import datetime
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

if __name__ == "__main__":
    main()