"""Independent V5 field/evidence integrity gate. No blanket human-review requirement."""
import json,re,hashlib
from pathlib import Path
import yaml
from _paths import ROOT

def main():
    root=Path(ROOT);errors=[];count=0;fields=[]
    for p in (root/'wiki').rglob('*.md'):
        text=p.read_text(encoding='utf-8-sig');m=re.match(r'^---\s*\n(.*?)\n---\n?',text,re.S)
        if not m:continue
        count+=1
        try:
            d=yaml.safe_load(m[1]);fields.append(len(d))
            required={'id','type','domain','jurisdiction','source_type','sources','citations','publish_status'}
            if not required.issubset(d):raise ValueError('缺基础属性')
            if d['publish_status'] not in {'可用','草稿','停用'}:raise ValueError('发布状态非法')
            rec=json.loads((root/'_meta/pages'/f"{d['id']}.json").read_text(encoding='utf-8'))
            if rec['id']!=d['id'] or rec['path']!=p.relative_to(root).as_posix():raise ValueError('证据身份/路径不符')
            if d['publish_status']=='可用' and (not rec.get('approval') or rec.get('issues')):raise ValueError('批准或阻断状态冲突')
            from _knowledge_policy import semantic_hash
            if semantic_hash(d,text[m.end():])!=rec['content_hash']:raise ValueError('内容绑定发生变化')
            for key in rec['evidence_refs']:
                ev=json.loads((root/'_meta/sources'/f'{key}.json').read_text(encoding='utf-8'))
                sha=hashlib.sha256(json.dumps(ev,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
                if sha!=key:raise ValueError('来源记录被改动')
        except Exception as e:errors.append(f'{p.name}：{e}')
    print(f'精简字段独立核验：{count}页；属性{min(fields)}—{max(fields)}项；错误{len(errors)}项')
    for e in errors[:20]:print('FAIL',e)
    print('结论：'+('FAIL' if errors else 'PASS'))
    return bool(errors)
if __name__=='__main__':raise SystemExit(main())
