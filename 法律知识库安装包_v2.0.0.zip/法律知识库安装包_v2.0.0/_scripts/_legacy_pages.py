# -*- coding: utf-8 -*-
"""_legacy_pages.py —— 「可确认的旧记录」清单（RULE-20261025-001 v2 补正）

**为什么需要这个模块**：Codex v1 审查指出，核验日期的判定在两处标准不一致——
`_meta_rules.verification_date` 要求自动核验来源必须有 `verified_at`，
而 `_publish_gate` / `_check_gate` 允许回退取 `last_verified`。
补正要求「统一口径」，且「确需历史兼容须集中实现并**限定明确旧记录**」，
「**新自动记录不得以旧人工日期放行**」。

**判定「旧记录」必须可确认，不能靠「缺 `verified_at`」推定**。
本模块以**基线清单**（`docs/governance/legacy-pages.json`（缺失时兼容旧基线））为权威来源：
只有**已登记在基线清单中**、且**尚无 `verified_at` 键**的页面，
才被视为「可确认的旧记录」，允许 `last_verified` 回退。

**fail-closed**：基线清单不存在 / 不可解析 → 返回空集合 →
所有自动核验来源的页面一律按**新记录**处理（缺 `verified_at` 即阻断）。
这保证「历史兼容」不会变成「放松新记录要求的后门」。

用法：

    from _legacy_pages import load_legacy_paths, is_legacy_path
    paths = load_legacy_paths()      # set[str]，相对 wiki/ 的路径
    if is_legacy_path(paths, rel): ...
"""

from __future__ import annotations

import json
import os

#: 基线清单路径（相对库根）
MANIFEST_REL = os.path.join("docs", "governance", "legacy-pages.json")
LEGACY_MANIFEST_REL = os.path.join("_work_temp", "_baseline", "manifest.json")

#: 库根（由调用方注入，或用环境变量 KB_ROOT 覆盖）
def _root():
    from _paths import ROOT
    return ROOT


_CACHE = {"loaded": False, "paths": set()}


def load_legacy_paths(root: str = None, manifest_rel: str = None) -> set:
    """加载「可确认的旧记录」路径集合。

    返回 set[str]（相对库根、正斜杠分隔的路径）。
    清单不可用时返回**空集合**（fail-closed）。
    """
    root = root or _root()
    rel = manifest_rel or MANIFEST_REL
    path = os.path.join(root, rel)
    if manifest_rel is None and not os.path.isfile(path):
        path = os.path.join(root, LEGACY_MANIFEST_REL)
    if not os.path.isfile(path):
        _CACHE["loaded"] = True
        _CACHE["paths"] = set()
        return set()
    try:
        with open(path, encoding="utf-8") as f:
            man = json.load(f)
    except Exception:
        _CACHE["loaded"] = True
        _CACHE["paths"] = set()
        return set()
    if not isinstance(man, dict):
        return set()
    entries = man.get("entries") or {}
    if not isinstance(entries, dict):
        _CACHE["loaded"] = True
        _CACHE["paths"] = set()
        return set()
    paths = set()
    for k in entries.keys():
        if not isinstance(k, str):
            continue
        # manifest 的键相对 wiki/；统一去掉 wiki/ 前缀，便于与
        # 「相对库根」与「相对 wiki/」两种比较方式都能命中
        norm = k.replace("\\", "/").strip("/")
        paths.add(norm)
        if norm.startswith("wiki/"):
            paths.add(norm[len("wiki/"):])
        else:
            # 基线清单的键相对 wiki/；同时登记「带 wiki/ 前缀」形式，
            # 以便调用方用「相对库根」的路径（如 wiki/01-labor/x.md）也能命中。
            paths.add("wiki/" + norm)
    _CACHE["loaded"] = True
    _CACHE["paths"] = paths
    return paths


def is_legacy_path(paths, rel: str) -> bool:
    """判断相对路径是否落在旧记录清单内。

    `rel` 可以是相对库根（`wiki/01-labor/x.md`）或相对 wiki/
    （`01-labor/x.md`）——两种写法都能命中。
    """
    if not paths or not rel:
        return False
    norm = rel.replace("\\", "/").strip("/")
    if norm in paths:
        return True
    if norm.startswith("wiki/") and norm[len("wiki/"):] in paths:
        return True
    return False
