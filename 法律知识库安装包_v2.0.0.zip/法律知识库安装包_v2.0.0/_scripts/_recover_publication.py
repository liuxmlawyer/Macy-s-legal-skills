"""Recover an interrupted paired publication after the writing application has stopped."""
import argparse,json,os,re
from pathlib import Path
from _paths import ROOT
from _publication import page_lock,atomic_bytes

def process_alive(pid):
    if os.name=='nt':
        import ctypes
        from ctypes import wintypes
        kernel=ctypes.WinDLL('kernel32',use_last_error=True)
        kernel.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD];kernel.OpenProcess.restype=wintypes.HANDLE
        kernel.GetExitCodeProcess.argtypes=[wintypes.HANDLE,ctypes.POINTER(wintypes.DWORD)];kernel.GetExitCodeProcess.restype=wintypes.BOOL
        kernel.CloseHandle.argtypes=[wintypes.HANDLE]
        handle=kernel.OpenProcess(0x1000,False,pid)
        if not handle:return ctypes.get_last_error()!=87
        try:
            code=wintypes.DWORD()
            return not kernel.GetExitCodeProcess(handle,ctypes.byref(code)) or code.value==259
        finally:kernel.CloseHandle(handle)
    try:os.kill(pid,0)
    except ProcessLookupError:return False
    except PermissionError:return True
    return True

def recover(root,relative,abandoned_lock=False):
    root=Path(root).resolve();tx=(root/relative).resolve()
    if not tx.is_relative_to(root/'_meta/transactions'):raise ValueError('只允许本库事务日志')
    journal=json.loads((tx/'journal.json').read_text(encoding='utf-8'))
    if journal['state'] in ('committed','rolled_back','recovered'):return journal['state']
    ident=journal['id']
    if not re.fullmatch(r'[\w-]+',str(ident)):raise ValueError('事务ID无效')
    note=(root/journal['path']).resolve()
    if not note.is_relative_to(root/'wiki'):raise ValueError('页面路径越界')
    lock=root/'_meta/publish-locks'/f'{ident}.lock'
    if lock.exists():
        if not abandoned_lock:raise ValueError('存在写锁；停止写入应用后，显式加--abandoned-lock恢复')
        pid=lock.read_text(encoding='utf-8').strip()
        if pid.isdigit() and process_alive(int(pid)):raise ValueError('原写入进程仍在运行，不能恢复')
        lock.unlink()
    rp=root/'_meta/pages'/f'{ident}.json'
    with page_lock(root,ident):
        for dest,name in [(note,'note'),(rp,'record')]:
            if dest.read_bytes() not in ((tx/(name+'.before')).read_bytes(),(tx/(name+'.after')).read_bytes()):raise ValueError('检测到其他修改；保留文件，不能自动恢复')
        atomic_bytes(note,(tx/'note.before').read_bytes());atomic_bytes(rp,(tx/'record.before').read_bytes())
        journal['state']='recovered';atomic_bytes(tx/'journal.json',(json.dumps(journal,ensure_ascii=False)+'\n').encode())
    return 'recovered'

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('transaction');ap.add_argument('--abandoned-lock',action='store_true');a=ap.parse_args()
    print(recover(ROOT,a.transaction,a.abandoned_lock))
