# -*- coding: utf-8 -*-
"""路径单一真源（客户版）

【与作者内部版的差异】
作者内部版的路径解析带有个人目录编号。
本客户版做三处改造，**行为要求不变**：

  1. 库根兜底探测**不再按目录名匹配**，改为扫描各盘根下**同时含 wiki/ 与 rules.md**
     的目录 —— 客户用自己的库名也能定位，不需要改代码。
  2. 关联库（收藏库 / 工作区 / 客户案件空间）**仅由环境变量指定**，
     不设置则不启用对应联动，绝不猜路径。
  3. 注释中的作者本机目录编号叙事改为通用表述。

【解析优先级】
1. 环境变量 KNOWLEDGE_ROOT（兼容 KB_ROOT，冲突即报错）/ LIB_FAVORITES / WORKSPACE_ROOT / CASE_SPACE
2. 由本文件位置上溯定位库根（_scripts/ 的父目录）
3. 兜底：扫描常见盘根，找同时含 wiki/ 与 rules.md 的目录
4. 最后兜底：当前工作目录

【用法】
    import sys, os
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from _paths import ROOT, WIKI, RAW, FAVORITES, WORKSPACE, CASE_SPACE
"""

import os

_THIS = os.path.dirname(os.path.abspath(__file__))


def _is_kb_root(path):
    """库根判定：同时含 wiki/ 目录与 rules.md 文件。"""
    return (os.path.isdir(os.path.join(path, "wiki"))
            and os.path.isfile(os.path.join(path, "rules.md")))


def _detect_root():
    """定位知识库根目录。三级优先，环境变量最优先。"""
    # 两个历史变量是同一根目录的别名，冲突或非法配置必须显式失败。
    configured = {k: os.environ.get(k) for k in ("KNOWLEDGE_ROOT", "KB_ROOT")
                  if os.environ.get(k)}
    resolved = {}
    for key, value in configured.items():
        path = os.path.realpath(os.path.abspath(os.path.expanduser(value)))
        if not _is_kb_root(path):
            raise RuntimeError("%s 必须指向包含 wiki/ 和 rules.md 的知识库根目录" % key)
        resolved[key] = path
    if len({os.path.normcase(v) for v in resolved.values()}) > 1:
        raise RuntimeError("KNOWLEDGE_ROOT 与 KB_ROOT 冲突：请将两者设置为同一个知识库根目录")
    if resolved:
        return next(iter(resolved.values()))

    # 2) 由本文件位置上溯：本文件在 <ROOT>/_scripts/
    cand = os.path.dirname(_THIS)
    if _is_kb_root(cand):
        return os.path.abspath(cand)

    # 3) 兜底：扫描常见盘根，找同时含 wiki/ 与 rules.md 的目录。
    #    不按目录名匹配 —— 客户用自己的库名也能定位。
    for drive in ("C:\\", "D:\\", "E:\\", "F:\\"):
        try:
            entries = os.listdir(drive)
        except OSError:
            continue
        for name in sorted(entries):
            p = os.path.join(drive, name)
            if os.path.isdir(p) and _is_kb_root(p):
                return os.path.abspath(p)

    # 4) 最后兜底：cwd
    cwd = os.path.abspath(os.getcwd())
    if _is_kb_root(cwd):
        return cwd
    return os.path.dirname(_THIS)


ROOT = _detect_root()

# ---------------------------------------------------------------- 主要子目录
WIKI = os.path.join(ROOT, "wiki")
RAW = os.path.join(ROOT, "raw")
DRAFT = os.path.join(ROOT, "draft")
BENCHMARK = os.path.join(ROOT, "benchmark")
LINT = os.path.join(ROOT, "lint-reports")
LOGS = os.path.join(ROOT, "logs")
SCRIPTS = os.path.join(ROOT, "_scripts")
TEMPLATES = os.path.join(ROOT, "templates")
TOOLS = os.path.join(ROOT, "tools")
OUTPUTS = os.path.join(ROOT, "outputs")
PKG_INDEX = os.path.join(ROOT, "raw", "06-资料包索引")

# ---------------------------------------------------------------- 库外关联库
# 仅由环境变量指定。未设置则不启用对应联动，绝不猜路径。
# 客户可按需设置，例如：
#   LIB_FAVORITES  = D:\MyFavorites     （收藏库）
#   WORKSPACE_ROOT = D:\MyWorkspace     （个人工作区）
#   CASE_SPACE     = D:\MyCaseSpace     （客户案件空间，未脱敏件专用）
def _optional_sibling(env_name):
    env = os.environ.get(env_name)
    if env and os.path.isdir(env):
        return os.path.abspath(env)
    return ""


FAVORITES = _optional_sibling("LIB_FAVORITES")
WORKSPACE = _optional_sibling("WORKSPACE_ROOT")
CASE_SPACE = _optional_sibling("CASE_SPACE")

# 常用二级路径（关联库未启用时为空串，调用方需判空）
FAVORITES_INBOX = os.path.join(FAVORITES, "inbox") if FAVORITES else ""
WORKSPACE_LABOR = os.path.join(WORKSPACE, "劳动用工工作区") if WORKSPACE else ""
CASE_LEDGER = os.path.join(CASE_SPACE, "_脱敏台账.md") if CASE_SPACE else ""

# ---------------------------------------------------------------- 写入便捷函数
def rel(*parts):
    """拼接库内相对路径，返回绝对路径。"""
    return os.path.join(ROOT, *parts)


def ensure_dir(path):
    """确保目录存在，返回该目录。"""
    os.makedirs(path, exist_ok=True)
    return path


def check_all():
    """自检：报告各路径是否存在。返回 (ok: bool, 报告: list[str])"""
    items = [
        ("库根", ROOT), ("wiki", WIKI), ("raw", RAW), ("draft", DRAFT),
        ("benchmark", BENCHMARK), ("lint-reports", LINT), ("logs", LOGS),
        ("scripts", SCRIPTS), ("templates", TEMPLATES), ("tools", TOOLS),
        ("outputs", OUTPUTS), ("资料包索引", PKG_INDEX),
    ]
    # 关联库为可选，未启用不计入失败
    for name, p in (("收藏库", FAVORITES), ("工作区", WORKSPACE),
                    ("客户案件空间", CASE_SPACE)):
        if p:
            items.append((name, p))
    report, ok = [], True
    for name, p in items:
        exists = os.path.exists(p)
        mark = "OK " if exists else "缺失"
        if not exists:
            ok = False
        report.append("  [%s] %-12s %s" % (mark, name, p))
    return ok, report


if __name__ == "__main__":
    ok, rep = check_all()
    print("路径单一真源自检（_paths.py）")
    print("=" * 72)
    print("\n".join(rep))
    print("=" * 72)
    print("结果：", "全部就绪" if ok else "存在缺失项，须处理")
    print("\n如需覆盖默认值，设置环境变量：")
    print("  KNOWLEDGE_ROOT / KB_ROOT")
    print("  LIB_FAVORITES / WORKSPACE_ROOT / CASE_SPACE（关联库，可选）")
