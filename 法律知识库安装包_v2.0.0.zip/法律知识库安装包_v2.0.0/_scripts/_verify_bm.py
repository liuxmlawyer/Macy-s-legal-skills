# -*- coding: utf-8 -*-
"""验证改写后 benchmark 文件的 YAML 可解析性与字段完整性（幂等校验）。"""
import os, re, sys
import yaml
sys.stdout.reconfigure(encoding="utf-8")

FM_RE = re.compile(r"\A---\n(.*?)\n---\n", re.S)
files = sorted(f for f in os.listdir("benchmark") if re.match(r"bench-\d+\.md$", f))
bad = 0
for f in files:
    p = os.path.join("benchmark", f)
    raw = open(p, encoding="utf-8").read()
    m = FM_RE.match(raw)
    if not m:
        print(f"[NO-FM] {f}")
        bad += 1
        continue
    try:
        d = yaml.safe_load(m.group(1))
    except Exception as e:
        print(f"[YAML-FAIL] {f}: {type(e).__name__}: {str(e)[:120]}")
        bad += 1
        continue
    if not isinstance(d, dict):
        print(f"[NOT-DICT] {f}")
        bad += 1
        continue
    probs = []
    if d.get("id") != f[:-3]:
        probs.append(f"id不符({d.get('id')})")
    if not d.get("category"):
        probs.append("category空")
    ea = d.get("expected_answer")
    if not isinstance(ea, str) or not ea.strip():
        probs.append("expected_answer空")
    for k in ("must_mention", "must_not_mention"):
        v = d.get(k)
        if not isinstance(v, list) or not v:
            probs.append(f"{k}非非空列表")
    # 正文参考答案是否与 frontmatter 一致（归一化空白后比较，YAML 双引号会折行）
    def norm(x):
        return re.sub(r"\s+", "", x)

    body = raw[m.end():]
    bm = re.search(r"(?ms)^## 参考答案\n(.*?)(?=^## |\Z)", body)
    if not bm:
        probs.append("正文无参考答案段")
    elif isinstance(ea, str) and ea.strip() and norm(ea) not in norm(bm.group(1)):
        probs.append("正文答案与frontmatter不一致")
    if probs:
        print(f"[PROB] {f}: {'; '.join(probs)}")
        bad += 1

print("=" * 70)
print(f"共 {len(files)} 题，异常 {bad} 题")
