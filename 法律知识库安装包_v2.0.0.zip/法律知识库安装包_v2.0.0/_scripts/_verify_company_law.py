# -*- coding: utf-8 -*-
"""G11 门禁（客户版）：检测引用已位移的旧法条号

【与作者内部版的差异】
作者内部版的基线是**库内自带的公司法权威原文**，随库提供。
客户包**不含法律正文**（法规原文著作权归属复杂），因此本版改为：

  · 基线原文**由客户自行放入** `raw/00-法律法规/.../01_中华人民共和国公司法.md`；
  · 未放入时，本门禁**明确报告「基线原文缺失，本门禁未执行」并以退出码 0 通过**，
    而不是抛异常阻断 —— 这是「无法验证」而非「验证不通过」；
  · 放入后，判定逻辑与作者内部版完全一致（内容指纹三态判定）。

【为什么这样处理】
门禁的语义是「发布前的技术校验」。缺少可选输入时，
把它记为「未执行」并说明原因，比让整套门禁崩掉更符合实际：
客户在放入公司法原文前，这条检查本来就没有可对照的基准。

【判定三态】
  ① 上下文命中「现行第 N 条」指纹 -> 正确引用（OK-NEW）
  ② 上下文命中「旧第 N 条」（2018 修正）特征 -> 误引旧条（FAIL）
  ③ 都不命中 -> 列入须人工核对（CHECK，不阻断发布）
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

BASE_REL = os.path.join("raw", "00-法律法规", "公司商事法律法规",
                        "01_核心法律", "01_中华人民共和国公司法.md")


def main() -> int:
    from _paths import ROOT

    baseline = os.path.join(ROOT, BASE_REL)
    if not os.path.isfile(baseline):
        print("=" * 74)
        print("G11 · 公司法条号位移检测（客户版）")
        print("=" * 74)
        print("基线原文缺失，本门禁未执行。")
        print()
        print("  期望路径：%s" % BASE_REL)
        print()
        print("  本包不含法律正文（法规原文著作权归属复杂，由使用者自备或自行取得授权）。")
        print("  如需启用本门禁，请把现行有效的公司法全文放到上述路径，")
        print("  格式为 Markdown，法条逐条分节（以「## 第N条」或「第N条」起头）。")
        print()
        print("  未放入时，本门禁不参与发布判断——这是「无法验证」，不是「验证不通过」。")
        print()
        print("结论：SKIP —— 基线原文缺失，本门禁未执行。")
        return 0

    # 基线存在 -> 走完整判定（与作者内部版同一实现）
    import _company_law_gate_impl as impl

    return impl.main()


if __name__ == "__main__":
    sys.exit(main())
