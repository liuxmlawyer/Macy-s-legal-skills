#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""正式检索（official scope）发布资格判定 + frontmatter 真实解析。

⚠️ 2026-10-24（KB-20261024-001 / B02）本模块为 `server.py` 的判定逻辑抽出，
目的是让「正式检索能否放行」这一安全关键判定**可以脱离 MCP 运行时被独立测试**
（server.py 依赖 mcp/pydantic，无法在无 MCP 环境下导入）。

抽出前的缺陷（Codex 补正清单 B02）：
  1. `_publish_gate` 用 `if st and st not in PUBLISH_STATUS_OK`——
     **status 缺失时不排除**，缺效力状态的页面可在 official 模式放行；
  2. **完全不检查 `verify_record`**——无任何核验证据记录也能放行；
  3. official 模式下 `raw_allowed = (not official) or (layer == "raw")`——
     显式传 `layer="raw"` 即可绕过发布条件，把未经发布流程的原始素材
     混入「正式检索」结果；
  4. `kb_read_page` 的状态提示块被包在 `if params.include_meta and fm:` 内——
     `include_meta=False` 时状态提示**整段消失**；
  5. frontmatter 用扁平正则解析，**跳过所有缩进行**，
     `verify_record` 这类嵌套字典/列表结构根本解析不出来。

⚠️ 2026-10-25（KB-20261024-001 / v2 补正 R01 + R02）本模块再次修订，
修订依据为 Codex 独立复核（评分 v1，8.1/10）指出的两项**阻断级**缺陷：

  **R01 非法 YAML 被宽松回退解析后仍放行**
    旧实现 `parse_frontmatter()` 用 `except Exception:` 把
    ① PyYAML **依赖缺失**、② YAML **语法错误** 两类完全不同的异常
    合并捕获，然后统一回退到内置宽松子集解析器 `_parse_fm_subset()`。
    宽松解析器会把 `broken: [unterminated` 当作普通键值行跳过，
    其余字段照常解析 → 判定为合格并**放行**。
    现改为：
      * YAML **语法错误** → **绝不回退宽松解析**，直接判定解析失败
        （`parse_frontmatter()` 返回带 `__parse_error__` 标记的字典，
         `strict=True` 时抛 `FrontmatterParseError`）；
      * PyYAML **依赖缺失** → 与语法错误**分开处理**，降级解析结果
        带 `__parse_degraded__` 标记；**正式模式（publish_gate）一律排除**，
        不允许「静默容错后放行」；
      * 两种异常的语义、提示与处置**分别独立可测**。

  **R02 空壳证据可独立放行**
    旧实现 `_record_field()` 对 list/dict 只要「长度非零」就返回 `"有内容"`，
    于是 `clauses=[null]`、`clauses=["  "]`、`evidence_location={x: null}`
    这类**空壳证据**都被当作「字段齐全」而放行。
    现改为：每个核验证据关键字段都有**明确的类型约束与内容约束**，
    空壳（null 元素、纯空白、空壳 dict、list/dict 冒充文本）一律排除，
    同时**保留真实既有记录形态**（verify_record 为 dict 或 list-of-dict、
    clauses 为条号列表或顿号串接的条号串）。

本模块的判定口径（依据 rules.md §1.3 / §8.1 与《知识库巡检制度》§5.1、§5.2）：
正式模式放行须**同时**满足：
  ① status 存在且 == 现行有效（缺失即排除）
  ② review_status ∈ {已发布, 已审核}
     （⚠️ V4.1 语义变更：**已发布 = wiki 内部入库成功**，
       **不代表已人工审核**；已审核 = 确经人工审核。两者都表示「已入库可检索」，
       但**都不能推出「正文已逐页复核」**。）
  ③ verify_source ∈ 真实核验来源（非「未核验」「批量推定」、非缺失）
  ④ **核验日期按核验路径取值**：
       · verify_source = 人工核验 → 取 `last_verified`（人工核验日期）
       · verify_source = 自动核验来源（flk-npc / 人民法院案例库 / pkulaw / wk /
         官方站点直查 …）→ 取 `verified_at`（真实自动核验时间）
       · 两者皆无 → 排除
     ⚠️ V4.1：**不再以「人工日期缺失」阻断真实自动核验**（旧口径要求
       last_verified 非空，等于要求每页先经人工核验，与「规则允许自动填写」
       冲突——这正是 RULE-20261025-001 要解决的矛盾）。
     ⚠️ 但**未来日期一律排除**（疑似脚本批量填充），人工日期与自动日期同此。
  ⑤ 未过复核周期：next_review（若存在）或核验日期 + 所属域周期 ≥ 今天
  ⑥ verify_record 可解析为字典、关键字段齐全、含**实际证据定位**
     （official_url 为 http(s) 地址、evidence_location 非空文本、
      verified_on 为真实日期）

另：历史法（历史版本条文）研究使用**独立范围**（research scope）+ 版本说明，
不得混入 official 结果；official 模式下显式传 raw/draft **不得绕过**上述判定。

⚠️ 2026-10-25（RULE-20261025-001 / rules.md V4.1）本模块再次修订：
  本轮**只放宽「人工日期前置」这一条**，其余防线（解析失败、空壳证据、
  日期合法性、证据定位、路径隔离）**全部原样保留**；
  并把「已发布」与「已人工审核」两个含义**彻底分开**，不再互相推断。

设计要点：
  * 解析失败与依赖缺失**分别显式**——不静默容错；
  * 所有判定只读 frontmatter，**不读正文、不改文件**；
  * 「已发布」**不等于**「已人工审核」——响应文案不得反向推断。
"""

from __future__ import annotations

import datetime
import re

# ── v3/G03：核验证据严格校验的**共享真源** ──────────────────────────────
# 本模块原先内嵌一份 `_is_real_date / _is_shell / _record_field /
# _clauses_fault / _evidence_location_fault / _text_field_fault /
# _check_one_record`，v3 把它**原样抽出**到 `_evidence_rules.py`，
# 使「发布资格门禁」与「自动赋值写回闸门」共用**同一份判定**。
# 本模块保留同名私有包装函数（内部既有调用点与错误文案逐字不变）。
_EVIDENCE_RULES = None
_EVIDENCE_RULES_TRIED = False


def _load_evidence_rules():
    """载入 `_evidence_rules` 模块（失败返回 None → 调用方 fail-closed）。"""
    global _EVIDENCE_RULES, _EVIDENCE_RULES_TRIED
    if _EVIDENCE_RULES_TRIED:
        return _EVIDENCE_RULES
    _EVIDENCE_RULES_TRIED = True
    try:
        import importlib.util
        import os
        here = os.path.dirname(os.path.abspath(__file__))
        path = os.path.join(here, "_evidence_rules.py")
        if not os.path.isfile(path):
            return None
        spec = importlib.util.spec_from_file_location("_evidence_rules", path)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        _EVIDENCE_RULES = mod
    except Exception:
        _EVIDENCE_RULES = None
    return _EVIDENCE_RULES


_ER = _load_evidence_rules()
if _ER is None:
    raise ImportError("_publish_gate 需要 _evidence_rules.py（核验证据严格校验共享真源）")
_ER_is_real_date = _ER.is_real_date
_ER_is_shell = _ER.is_shell
_ER_record_field = _ER.record_field
_ER_clauses_fault = _ER.clauses_fault
_ER_evidence_location_fault = _ER.evidence_location_fault
_ER_text_field_fault = _ER.text_field_fault
_ER_check_one_record = _ER.check_one_record

# ── 判定用的常量值域（与 rules.md §1.3 / §8.1 一致）────────────────────────
# ⚠️ V4.1（RULE-20261025-001）：review_status 的**语义已变更**——
#   「已发布」= **wiki 内部入库成功**（写入 + 索引 + 必要技术校验全部通过），
#   **不代表已人工审核**；「已审核」= 确经人工审核。
#   两者都表示「已进入正式库、可被检索」，但**都不能推出「正文已逐页复核」**。
#   ⚠️ 「已发布」**不**再等同于旧版的「已过人工审核关」——旧文案已废止。
PUBLISH_REVIEW_OK = {"已发布", "已审核"}

# 自动核验来源（真实自动/来源核验，非人工）——V4.1 新增分类
PUBLISH_VERIFY_AUTO = {"flk-npc", "人民法院案例库", "pkulaw", "wk",
                       "官方站点直查", "samr", "npc.gov.cn"}

PUBLISH_VERIFY_REAL = {"人工核验", "flk-npc", "人民法院案例库", "pkulaw", "wk",
                       "官方站点直查", "samr", "npc.gov.cn"}
PUBLISH_VERIFY_NONE = {"未核验", "批量推定", ""}
PUBLISH_STATUS_OK = {"现行有效"}

# ── 核验链规则引擎载入（统一口径的唯一真源）────────────────────────────
# ⚠️ `_meta_rules.resolve_verification()` 是核验日期判定的**唯一实现**；
#    本模块与 `_check_gate.py`、MCP 均调用它，避免各自实现造成标准分裂
#    （Codex v1 指出：`_meta_rules` 要求 verified_at，而门禁允许
#     last_verified 回退，两处标准不一致）。
_META_RULES = None
_META_RULES_TRIED = False

#: 旧记录回退提示（非阻断），由 publish_gate 累积，供报告层读取
_LEGACY_NOTES = []


def _load_meta_rules():
    """载入 `_meta_rules` 模块（失败返回 None → 调用方 fail-closed）。"""
    global _META_RULES, _META_RULES_TRIED
    if _META_RULES_TRIED:
        return _META_RULES
    _META_RULES_TRIED = True
    try:
        import importlib.util
        import os
        here = os.path.dirname(os.path.abspath(__file__))
        path = os.path.join(here, "_meta_rules.py")
        if not os.path.isfile(path):
            return None
        spec = importlib.util.spec_from_file_location("_meta_rules", path)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        _META_RULES = mod
    except Exception:
        _META_RULES = None
    return _META_RULES


def legacy_note_lines():
    """取出本轮累积的旧记录回退提示（非阻断）。"""
    return list(_LEGACY_NOTES)

# verify_record 的关键字段（全部必须存在且非空）
VERIFY_RECORD_REQUIRED = ("object", "version", "doc_no",
                          "official_url", "clauses",
                          "verified_on", "evidence_location")

# 复核周期（天）。依据《知识库巡检制度》§5.1「风险定频」
#   高频域 01-labor / 08-data      → 季度（90 天）
#   中频域 07-corporate / 05-family / 04-ip → 半年（180 天）
#   低频域其余各域                  → 年度（365 天）
REVIEW_CYCLE_DAYS = {
    "01-labor": 90, "08-data": 90,
    "07-corporate": 180, "05-family": 180, "04-ip": 180,
}
REVIEW_CYCLE_DEFAULT = 365

# ── R01：解析异常的两个独立标记 ────────────────────────────────────────────
# 解析**语法错误**（YAML 本身不合法）——禁止回退宽松解析后放行
PARSE_ERROR_KEY = "__parse_error__"
# 解析**依赖缺失**（PyYAML 不可用，已降级为内置子集解析）——正式模式不得放行
PARSE_DEGRADED_KEY = "__parse_degraded__"


class FrontmatterParseError(Exception):
    """frontmatter 解析失败（语法错误 / 依赖缺失）。

    `strict=True` 时抛出，用于「正式模式必须给出解析错误、不得静默容错」。
    """

    def __init__(self, message: str, kind: str = "syntax_error"):
        super().__init__(message)
        self.kind = kind          # 'syntax_error' | 'dependency_missing'
        self.message = message


def _today() -> datetime.date:
    return datetime.date.today()


# ── frontmatter 解析 ──────────────────────────────────────────────────────
FM_RE = re.compile(r"^---\s*\r?\n(.*?)\r?\n---", re.S)


def _scalar(v):
    """把 YAML 标量规约为字符串（日期对象 → ISO 字符串）。"""
    if isinstance(v, datetime.datetime):
        return v.date().isoformat()
    if isinstance(v, datetime.date):
        return v.isoformat()
    if isinstance(v, bool):
        return "true" if v else "false"
    return v


def _norm(tree):
    """递归规约解析结果。

    规则：dict / list 原样保留结构；**所有标量一律转为字符串**；
    **None 原样保留为 None**（⚠️ v2/R02：旧实现把 None 转成字符串 "None"，
    于是 `clauses: [null]` 被规约成 `["None"]`——非空文本，空壳证据得以放行。
    现改为保留 None，由字段校验器显式判为空壳）。
    这样 PyYAML 分支与内置回退分支的输出完全一致（数值、日期、布尔
    统一为字符串），也保持了旧版扁平解析器「一切皆字符串」的语义，
    避免下游把 int 与 str 混用比较。
    """
    if isinstance(tree, dict):
        return {str(k): _norm(v) for k, v in tree.items()}
    if isinstance(tree, list):
        return [_norm(v) for v in tree]
    if isinstance(tree, datetime.datetime):
        return tree.date().isoformat()
    if isinstance(tree, datetime.date):
        return tree.isoformat()
    if isinstance(tree, bool):
        return "true" if tree else "false"
    if tree is None:
        return None
    if isinstance(tree, str):
        return tree
    return str(tree)


def _parse_flow_list(val: str) -> list:
    inner = val.strip()[1:-1]
    items = []
    depth = 0
    cur = ""
    q = None
    for ch in inner:
        if q:
            cur += ch
            if ch == q:
                q = None
            continue
        if ch in "\"'":
            q = ch
            cur += ch
            continue
        if ch in "[{":
            depth += 1
        elif ch in "]}":
            depth -= 1
        if ch == "," and depth == 0:
            items.append(_strip_q(cur.strip()))
            cur = ""
            continue
        cur += ch
    if cur.strip():
        items.append(_strip_q(cur.strip()))
    return items


def _parse_flow_dict(val: str) -> dict:
    inner = val.strip()[1:-1]
    out = {}
    for part in inner.split(","):
        if ":" not in part:
            continue
        k, v = part.split(":", 1)
        out[_strip_q(k.strip())] = _strip_q(v.strip())
    return out


def _strip_q(v: str) -> str:
    v = v.strip()
    if len(v) >= 2 and v[0] in "\"'" and v[-1] == v[0]:
        return v[1:-1]
    return v


def _parse_fm_subset(text: str) -> dict:
    """内置 YAML 子集解析（独立实现，避免与主解析共用状态）。

    支持本库 frontmatter 实际用到的结构：
      key: value            标量
      key:                  空值（None）
      key:                  后跟块字典（缩进 > key 缩进）
      key:                  后跟块列表（"- item" 行，缩进可 == 或 > key 缩进）
      key: [a, b]           流式列表
      key: {a: 1}           流式字典

    ⚠️ v2/R01：本解析器是**宽松**的——它会跳过无法识别的行。
       因此它**只能**在「PyYAML 依赖缺失」这一种情形下使用，
       且其结果必须带 `PARSE_DEGRADED_KEY` 标记，
       **正式模式据此一律排除**。任何 YAML **语法错误**都不得落到这里。
    """
    lines = text.split("\n")
    root: dict = {}
    # 栈帧：(indent, kind, container)  kind ∈ {'dict','list'}
    stack = [(-1, "dict", root)]
    i = 0
    while i < len(lines):
        raw = lines[i].rstrip("\r")
        i += 1
        if not raw.strip() or raw.strip().startswith("#"):
            continue
        indent = len(raw) - len(raw.lstrip(" "))
        body = raw.strip()

        # ---- 列表项 ----
        if body.startswith("- "):
            # 找到最近一个仍然打开的 list 容器
            target = None
            for fr in reversed(stack):
                if fr[1] == "list":
                    target = fr
                    break
            if target is None or indent < target[0]:
                continue
            item = body[2:].strip()
            km = re.match(r"^([^\s:#][^:]*?)\s*:\s*(.*)$", item)
            if km:
                # 列表项本身是一个映射：- key: value
                sub = {km.group(1): _strip_q(km.group(2).strip())}
                target[2].append(sub)
                # 续行键的缩进通常为「列表项缩进 + 2」，故帧缩进取 indent+1，
                # 使续行（缩进更大）能留在本子字典内
                stack.append((indent + 1, "dict", sub))
            else:
                target[2].append(_strip_q(item))
            continue

        # ---- 键值行 ----
        km = re.match(r"^([^\s:#][^:]*?)\s*:\s*(.*)$", body)
        if not km:
            continue
        key, val = km.group(1), km.group(2).strip()

        while len(stack) > 1 and indent <= stack[-1][0]:
            stack.pop()
        parent = stack[-1][2]
        if not isinstance(parent, dict):
            continue

        if val == "":
            # 向前看：判定该键是块字典、块列表还是空值
            j = i
            kind = None
            while j < len(lines):
                nxt = lines[j].rstrip("\r")
                if not nxt.strip() or nxt.strip().startswith("#"):
                    j += 1
                    continue
                nind = len(nxt) - len(nxt.lstrip(" "))
                if nxt.strip().startswith("- "):
                    # 列表项：缩进 >= 当前键缩进即属本键
                    if nind >= indent:
                        kind = "list"
                    break
                if nind > indent:
                    kind = "dict"
                break
            if kind is None:
                parent[key] = None
                continue
            child = [] if kind == "list" else {}
            parent[key] = child
            stack.append((indent, kind, child))
            continue

        if val.startswith("["):
            parent[key] = _parse_flow_list(val)
        elif val.startswith("{"):
            parent[key] = _parse_flow_dict(val)
        else:
            parent[key] = _strip_q(val)
    return root


def _lint_yaml_syntax(block: str):
    """轻量 YAML 结构校验（不依赖 PyYAML）。

    用途：在 **PyYAML 依赖缺失**的降级场景下，仍然能够识别
    **明显的语法错误**（未闭合的流式列表/字典、值部分引号未闭合），
    从而做到「缺依赖」与「语法错误」两类异常的**语义分离**——
    语法错误绝不因为「恰好没装 PyYAML」而被降级放行。

    实现约束（防误报）：
      * 只检查**每行的值部分**（首个 `:` 之后），不动键名；
      * 引号只在**值以引号开头**时视为成对定界符，
        值中间出现的引号（如中文书名号/英文缩写）一律忽略；
      * 注释行与空行跳过；
      * 只做括号配平与「值以引号开头但未闭合」两项检查。

    返回错误描述字符串；无明显语法问题返回 ""。
    """
    for line_no, raw in enumerate(block.split("\n"), 1):
        line = raw.rstrip()
        if not line.strip() or line.strip().startswith("#"):
            continue
        body = line.strip()
        if body.startswith("- "):
            body = body[2:].strip()
        # 键值行：取第一个 ":" 之后的值部分
        km = re.match(r"^[^:]*:\s*(.*)$", body)
        val = km.group(1).strip() if km else body
        if not val:
            continue
        # 值以引号开头 → 必须在本行内闭合
        if val[0] in "\"'":
            q = val[0]
            if len(val) < 2 or val[-1] != q:
                return ("YAML 语法错误：第 %d 行的值以 %r 开头但引号未闭合"
                        % (line_no, q))
            continue
        # 括号配平（忽略引号内的括号）
        depth = 0
        in_q = None
        for ch in val:
            if in_q:
                if ch == in_q:
                    in_q = None
                continue
            if ch in "\"'":
                in_q = ch
                continue
            if ch in "[{":
                depth += 1
            elif ch in "]}":
                depth -= 1
                if depth < 0:
                    return ("YAML 语法错误：第 %d 行出现多余的闭合符" % line_no)
        if depth > 0:
            return ("YAML 语法错误：第 %d 行的流式集合未闭合（%r）"
                    % (line_no, val[:40]))
    return ""


def parse_frontmatter(text: str, strict: bool = False) -> dict:
    """解析 YAML frontmatter，**支持嵌套字典/列表结构**。

    返回 dict：顶层键 → 标量字符串 / dict / list。
    优先使用真实 YAML（PyYAML）；PyYAML **依赖缺失**时回退到内置 YAML 子集解析器。

    ⚠️ v2/R01 修订（依 Codex 复核 v1 的 R01 阻断项）：
      * **YAML 语法错误**与 **PyYAML 依赖缺失**不再被同一个
        `except Exception` 合并吞掉：
          - 语法错误 → **绝不**回退宽松解析；返回带 `PARSE_ERROR_KEY`
            标记的字典（strict=True 时抛 `FrontmatterParseError`），
            由 `publish_gate()` 判定为「解析失败，不得放行」；
          - 依赖缺失 → 降级解析并打上 `PARSE_DEGRADED_KEY` 标记，
            `publish_gate()` **同样排除**（正式模式不得静默容错）。
      * 旧实现（缺陷版）：语法错误被当成「PyYAML 不可用」→ 回退宽松解析
        → `broken: [unterminated` 被跳过、其余字段照常 → **放行**。
        该行为已由 `_test_publish_gate_v2.py` 的反例锁定，不得复现。
    """
    m = FM_RE.match(text)
    if not m:
        # 没有 frontmatter 块——不是解析错误，只是无元数据
        return {}
    block = m.group(1)

    # ── ① PyYAML 依赖是否可用（与语法错误分开处理）────────────────────
    yaml = None
    dep_error = None
    try:
        import yaml  # type: ignore
    except Exception as exc:      # ImportError 及其子类
        yaml = None
        dep_error = exc

    if yaml is not None:
        # ── ② 真实 YAML 解析：语法错误必须显式失败，不得回退 ─────────
        try:
            data = yaml.safe_load(block)
        except Exception as exc:
            msg = ("frontmatter YAML 语法错误：%s: %s"
                   % (type(exc).__name__, exc))
            if strict:
                raise FrontmatterParseError(msg, kind="syntax_error")
            # 非严格模式：**不**回退宽松解析，只标记解析失败
            return {PARSE_ERROR_KEY: msg}
        if data is None:
            return {}
        if not isinstance(data, dict):
            msg = ("frontmatter 顶层不是映射结构（解析结果类型：%s）"
                   % type(data).__name__)
            if strict:
                raise FrontmatterParseError(msg, kind="syntax_error")
            return {PARSE_ERROR_KEY: msg}
        return _norm(data)

    # ── ③ PyYAML 依赖缺失 → 降级解析 + 明确标记（正式模式一律排除）──
    dep_msg = ("缺少 PyYAML 依赖，无法进行真实 YAML 解析"
               "（%s: %s）" % (type(dep_error).__name__, dep_error))
    # ⚠️ 即使缺依赖，也必须能识别**明显的语法错误**——
    #    否则「恰好没装 PyYAML」会让非法 YAML 走降级路径（不得放行）。
    lint = _lint_yaml_syntax(block)
    if lint:
        if strict:
            raise FrontmatterParseError(lint, kind="syntax_error")
        return {PARSE_ERROR_KEY: lint}
    if strict:
        raise FrontmatterParseError(dep_msg, kind="dependency_missing")
    try:
        data = _norm(_parse_fm_subset(block))
    except Exception as exc:
        msg = "frontmatter 降级解析失败：%s: %s" % (type(exc).__name__, exc)
        return {PARSE_ERROR_KEY: msg, PARSE_DEGRADED_KEY: dep_msg}
    if not isinstance(data, dict):
        return {PARSE_ERROR_KEY: "frontmatter 降级解析结果不是映射结构",
                PARSE_DEGRADED_KEY: dep_msg}
    data[PARSE_DEGRADED_KEY] = dep_msg
    return data


# 兼容旧名：server.py 内部历史调用点沿用 _parse_fm
def _parse_fm(text: str) -> dict:
    return parse_frontmatter(text)


def _is_real_date(s: str) -> bool:
    """是否为真实存在的日历日期（YYYY-MM-DD）。

    ⚠️ v3/G03：判定口径已抽出到 `_evidence_rules.is_real_date`（共享真源），
    本函数保留为**兼容别名**，供本模块内部既有调用点使用。
    """
    return _ER_is_real_date(s)


def _get(fm: dict, key: str) -> str:
    """取标量字段的文本值。

    ⚠️ v2/R02：list/dict 一律视为「非标量」→ 返回 ""（视为缺失），
    **不再**把「非空 list/dict」当作有内容的字段值。
    """
    v = fm.get(key)
    if v is None:
        return ""
    if isinstance(v, (dict, list)):
        return ""
    if isinstance(v, bool):
        return "true" if v else "false"
    return str(v).strip()


def _type_fault(fm: dict, key: str) -> str:
    """标量字段被 list/dict 冒充时的类型问题描述（无问题返回 ""）。"""
    v = fm.get(key)
    if v is None:
        return ""
    if isinstance(v, (dict, list)):
        return ("字段 %s 类型非法：应为文本标量，实际为 %s"
                % (key, "dict" if isinstance(v, dict) else "list"))
    return ""


def _verify_record_of(fm: dict):
    """取出 verify_record 字典（支持 dict 与 list 两种历史形态）。

    返回 (记录字典或 None, 形态说明)。列表形态视为「多条记录」，
    只要每条都是完整记录才算通过——避免用一条完整记录掩盖其他空壳记录。
    """
    vr = fm.get("verify_record")
    if isinstance(vr, dict):
        return vr, "dict"
    if isinstance(vr, list):
        recs = [r for r in vr if isinstance(r, dict)]
        if recs and len(recs) == len([r for r in vr if r is not None]):
            return recs, "list"
        return None, "list-malformed"
    if isinstance(vr, str) and vr.strip():
        return None, "string-unparsed"
    return None, "missing"


def _record_field(rec: dict, name: str) -> str:
    """取 verify_record 的字段值文本（**只认标量文本**）。

    ⚠️ v3/G03：实现已抽出到 `_evidence_rules.record_field`（共享真源），
    判定口径与错误文案逐字保持不变。
    """
    return _ER_record_field(rec, name)


def _is_shell(value) -> bool:
    """判断一个值是否为空壳（无实际内容的容器）。

    ⚠️ v3/G03：实现已抽出到 `_evidence_rules.is_shell`（共享真源）。
    """
    return _ER_is_shell(value)


def _clauses_fault(rec: dict) -> str:
    """校验 clauses 字段（条号证据）。

    ⚠️ v3/G03：实现已抽出到 `_evidence_rules.clauses_fault`（共享真源）。
    """
    return _ER_clauses_fault(rec)


def _evidence_location_fault(rec: dict) -> str:
    """校验 evidence_location 字段（证据定位）。

    ⚠️ v3/G03：实现已抽出到 `_evidence_rules.evidence_location_fault`。
    """
    return _ER_evidence_location_fault(rec)


def _text_field_fault(rec: dict, name: str) -> str:
    """校验必须为非空文本的字段（object / version / doc_no）。

    ⚠️ v3/G03：实现已抽出到 `_evidence_rules.text_field_fault`。
    """
    return _ER_text_field_fault(rec, name)


def _check_one_record(rec: dict, idx: int = 0) -> list:
    """校验单条 verify_record，返回问题列表。

    ⚠️ v3/G03：实现已抽出到 `_evidence_rules.check_one_record`（共享真源），
    错误文案逐字保留（既有回归依赖「缺少关键字段 …」等精确表述）。
    """
    return _ER_check_one_record(rec, idx)


def publish_gate(fm: dict, today: datetime.date = None,
                 rel_path: str = "", legacy_paths=None) -> tuple:
    """判定页面是否满足正式检索（official scope）的发布条件。

    返回 (是否合格, 排除原因列表)；原因列表为空表示合格。

    判定**仅依据 frontmatter 字段**，不构成「内容已逐页复核」的保证。

    ⚠️ **统一核验日期口径（Codex v1 指出两处标准不一致）**：
    本函数的 ④ 核验日期判定**不再自行实现**，改为统一调用
    `_meta_rules.resolve_verification()`——那是**唯一真源**，
    `_check_gate.py` 与 MCP 也调同一函数。
    旧记录回退（自动来源缺 `verified_at` → 回退 `last_verified`）
    **仅对 `legacy_paths` 中可确认的旧页生效**；新记录缺 `verified_at`
    一律**阻断**。
    """
    if today is None:
        today = _today()
    reasons = []

    # ⚠️ v2/R01：解析异常优先判定——解析失败/降级一律排除，
    #    **不得**因为「其余字段齐全」而放行。
    if not isinstance(fm, dict):
        return False, ["frontmatter 不是字典，无法判定发布资格"]
    perr = fm.get(PARSE_ERROR_KEY)
    if perr:
        reasons.append("frontmatter 解析失败（%s）——解析失败的页面不得放行"
                       % perr)
    pdeg = fm.get(PARSE_DEGRADED_KEY)
    if pdeg:
        reasons.append("frontmatter 解析降级（%s）——正式模式要求真实 YAML "
                       "解析，依赖缺失不得静默容错后放行" % pdeg)

    rv = _get(fm, "review_status")
    vs = _get(fm, "verify_source")
    lv = _get(fm, "last_verified")
    va = _get(fm, "verified_at")
    st = _get(fm, "status")

    # ① 效力状态：必须存在且为「现行有效」（修复：缺失即排除）
    for key in ("status", "review_status", "verify_source",
                "last_verified", "verified_at", "next_review"):
        fault = _type_fault(fm, key)
        if fault:
            reasons.append(fault)

    if not st:
        reasons.append("status 缺失（未声明效力状态，无法认定为现行有效）")
    elif st not in PUBLISH_STATUS_OK:
        reasons.append("status=%s（非现行有效）" % st)

    # ② 入库状态：review_status ∈ {已发布, 已审核}
    #    ⚠️ V4.1：「已发布」= wiki 内部入库成功，**不代表已人工审核**。
    #    此处**不再**使用「已过人工审核关」这一措辞（旧语义已废止）。
    if rv not in PUBLISH_REVIEW_OK:
        reasons.append("review_status=%s（未进入正式库：已发布＝wiki 入库成功，"
                       "已审核＝确经人工审核；本项仅表示入库状态，"
                       "不代表正文已复核）" % (rv or "缺失"))

    # ③ 核验来源
    if vs in PUBLISH_VERIFY_NONE:
        reasons.append("verify_source=%s（无有效核验来源）" % (vs or "缺失"))
    elif vs not in PUBLISH_VERIFY_REAL:
        reasons.append("verify_source=%s（不在已定义的核验来源白名单内）" % vs)

    # ④ 核验日期：**统一调用 _meta_rules.resolve_verification()**（唯一真源）
    #    · 人工核验来源 → last_verified（人工核验日期）
    #    · 自动核验来源 → verified_at（真实自动核验时间）
    #    · 旧记录（可确认）缺 verified_at → 回退 last_verified，**不阻断**，
    #      记「待补 verified_at」提示
    #    · **新记录**缺 verified_at → **阻断**（不得以旧人工日期放行）
    _mr = _load_meta_rules()
    if _mr is not None:
        _rv = _mr.resolve_verification(
            fm, rel_path=rel_path, legacy_paths=legacy_paths,
            today_date=today)
        verify_date = _rv["date"]
        verify_path = _rv["path"]
        verify_fallback = _rv["used_legacy_fallback"]
        for _b in _rv["blockers"]:
            reasons.append(_b)
        for _n in _rv.get("notes", []):
            _LEGACY_NOTES.append("%s — %s" % (rel_path or "(未标路径)", _n))
    else:
        # 规则引擎不可用 → fail-closed（不得静默放行）
        verify_date = ""
        verify_path = ""
        verify_fallback = False
        reasons.append("核验链规则引擎（_meta_rules）不可用，无法判定核验日期"
                       "（fail-closed）")

    # ⑤ 复核周期：next_review 优先，否则核验日期 + 所属域周期
    domain = _get(fm, "domain")
    nr = _get(fm, "next_review")
    if nr and _is_real_date(nr):
        if datetime.date.fromisoformat(nr) < today:
            reasons.append("已过复核期（next_review=%s < 今天 %s）" % (nr, today.isoformat()))
    elif verify_date and _is_real_date(verify_date):
        days = REVIEW_CYCLE_DAYS.get(domain, REVIEW_CYCLE_DEFAULT)
        due = datetime.date.fromisoformat(verify_date) + datetime.timedelta(days=days)
        if due < today:
            reasons.append("已过复核期（%s=%s + %s域周期%d天 = %s < 今天 %s）"
                           % ("last_verified" if verify_path == "manual"
                              else "verified_at",
                              verify_date, domain or "未标注", days,
                              due.isoformat(), today.isoformat()))

    # ⑥ 核验证据记录：可解析 + 关键字段齐全 + 实际证据定位（v2/R02 严格化）
    rec, shape = _verify_record_of(fm)
    if shape == "missing":
        reasons.append("verify_record 缺失（无核验证据记录）")
    elif shape == "string-unparsed":
        reasons.append("verify_record 为未解析的字符串（无法校验证据字段）")
    elif shape == "list-malformed":
        reasons.append("verify_record 列表中存在非字典条目（证据记录结构不完整）")
    else:
        records = rec if shape == "list" else [rec]
        for i, r in enumerate(records):
            reasons.extend(_check_one_record(r, i))
        # verified_on 不得晚于今天
        for i, r in enumerate(records):
            von = _record_field(r, "verified_on")
            if von and _is_real_date(von):
                if datetime.date.fromisoformat(von) > today:
                    reasons.append("verify_record%s 的 verified_on=%s 晚于今天（未来日期）"
                                   % ("" if i == 0 else "（第%d条）" % (i + 1), von))

    return (not reasons), reasons


def official_layer_allowed(layer: str, scope: str) -> tuple:
    """正式模式下校验检索层参数。

    返回 (是否允许, 说明)。official 模式下显式传 raw/draft **不得绕过**发布条件：
      * raw  —— 原始素材，未经发布流程，official 一律不检索；
      * draft—— 草稿层，同样须逐页通过 publish_gate（由调用方保证），
                  但**不允许以 draft 规避 wiki 层的发布流程**。
    """
    layer = (layer or "wiki").lower()
    scope = (scope or "research").lower()
    if scope != "official":
        return True, ""
    if layer == "raw":
        return False, ("正式检索不得检索 raw 层：raw 是未经发布流程的原始素材。"
                       "历史版本/原始素材研究请改用 scope=\"research\" 并在结论中说明版本。")
    if layer == "draft":
        return False, ("正式检索不得以 draft 层绕过 wiki 层的发布流程："
                       "草稿层须先经人工审核发布至 wiki，再以 scope=\"official\" 检索。")
    return True, ""


def research_version_note(fm: dict) -> str:
    """研究范围下的版本/效力说明（供 research scope 标注历史法）。"""
    bits = []
    st = _get(fm, "status")
    if st:
        bits.append("效力状态：%s" % st)
    vr = fm.get("verify_record")
    if isinstance(vr, dict):
        ver = _record_field(vr, "version")
        if ver:
            bits.append("版本：%s" % ver)
    vs = _get(fm, "verify_source")
    if vs:
        bits.append("核验来源：%s" % vs)
    # ⚠️ V4.1：核验方式（人工 / 自动）必须写明，**不得让读者以为已人工审核**。
    #    ⚠️ v2 补正：核验日期口径统一走 `_meta_rules.resolve_verification()`，
    #    不再在本函数内另行判定「有 verified_at 用它、否则用 last_verified」，
    #    避免第三处标准分裂。
    va = _get(fm, "verified_at")
    _mr = _load_meta_rules()
    _rv = None
    if _mr is not None:
        try:
            _rv = _mr.resolve_verification(fm)
        except Exception:
            _rv = None
    if _rv is not None:
        if _rv["path"] == "manual":
            bits.append("核验方式：人工核验（%s）" % _rv["date"])
        elif _rv["path"] == "auto":
            bits.append("核验方式：自动核验（%s，来源 %s）"
                        % (_rv["date"], _rv["source"]))
        elif _rv["path"] == "legacy":
            bits.append("核验方式：自动核验（来源 %s；**核验时间暂记于 "
                        "last_verified=%s，待补 verified_at**）"
                        % (_rv["source"], _rv["date"]))
        else:
            # path == 'none'：无合法核验时间。若有 last_verified 仍记录
            # 「待补 verified_at」的历史提示（**仅提示，不构成放行依据**）。
            lv = _get(fm, "last_verified")
            if lv:
                bits.append("核验方式：自动核验（来源 %s；**核验时间暂记于 "
                            "last_verified=%s，待补 verified_at**）" % (vs, lv))
            else:
                bits.append("核验方式：自动核验来源 %s（尚无核验时间）" % vs)
    elif vs == "人工核验":
        lv = _get(fm, "last_verified")
        if lv:
            bits.append("核验方式：人工核验（%s）" % lv)
    elif vs in PUBLISH_VERIFY_AUTO:
        if va:
            bits.append("核验方式：自动核验（%s，来源 %s）" % (va, vs))
        else:
            lv = _get(fm, "last_verified")
            if lv:
                bits.append("核验方式：自动核验（来源 %s；**核验时间暂记于 "
                            "last_verified=%s，待补 verified_at**）" % (vs, lv))
            else:
                bits.append("核验方式：自动核验来源 %s（尚无核验时间）" % vs)
    rv = _get(fm, "review_status")
    if rv == "已发布":
        bits.append("入库状态：已发布（wiki 内部入库成功，**不代表已人工审核**）")
    elif rv == "已审核":
        bits.append("入库状态：已审核（确经人工审核）")
    return "；".join(bits)


# V5: compact-note compatibility and one evidence gate. Legacy strict checks remain intact.
_v42_parse_frontmatter = parse_frontmatter
_v42_publish_gate = publish_gate
_v42_official_layer_allowed = official_layer_allowed

def parse_frontmatter(text, *args, **kwargs):
    data = _v42_parse_frontmatter(text, *args, **kwargs)
    if not isinstance(data, dict) or "publish_status" not in data or data.get(PARSE_ERROR_KEY) or data.get(PARSE_DEGRADED_KEY):
        return data
    try:
        from _knowledge_policy import hydrate
        return hydrate(data)
    except ImportError as exc:
        data[PARSE_DEGRADED_KEY] = str(exc)
        return data

def publish_gate(fm, today=None, rel_path="", legacy_paths=None):
    if not isinstance(fm, dict):
        return _v42_publish_gate(fm, today=today, rel_path=rel_path, legacy_paths=legacy_paths)
    if fm.get("release_blockers") or str(fm.get("content_review_required")).lower() == "true":
        return False, ["存在未解决的实质内容问题"]
    if "publish_status" not in fm:
        return _v42_publish_gate(fm, today=today, rel_path=rel_path, legacy_paths=legacy_paths)
    if fm.get(PARSE_ERROR_KEY) or fm.get(PARSE_DEGRADED_KEY):
        return False, ["解析失败或依赖缺失，不得放行"]
    try:
        from _knowledge_policy import verified_input, usable_gate
        data = verified_input(fm)
    except ImportError:
        return False, ["缺少精简字段适配依赖，不得放行"]
    if data.get("__policy_error__"):
        return False, [data["__policy_error__"]]
    usable, reasons = usable_gate(data)
    if not usable:
        return False, reasons
    if data.get('_v5_record',{}).get('official_publications'):
        from _case_publication import published_case_gate
        return published_case_gate(data)
    if data.get('_v5_record',{}).get('usage_class')=='author_summary':
        return False, ['作者总结已发布可默认检索；本过滤器只核对官方来源，不属于发布失败']
    return _v42_publish_gate(data, today=today, rel_path=rel_path, legacy_paths=legacy_paths)

def official_layer_allowed(layer, scope):
    return _v42_official_layer_allowed(layer, "official" if scope in ("usable", "verified") else scope)
