# -*- coding: utf-8 -*-
"""G11 门禁：检测引用已位移的旧法条号

【为什么需要】
2023 年修订《公司法》（2024-07-01 施行，主席令第十五号）大幅重排条号，危险之处在于：
**旧条号在现行法中依然存在，只是内容完全不同**。
例如「公司法第 22 条」——旧法讲决议无效/可撤销，
现行第 22 条讲「控股股东、实控人、董监高不得利用关联关系」。
按「数字找不到 = 失效」的思路检测会完全失效。

本门禁用**内容指纹**判定。

【2026-10-24 全表重建】
前一版 RISKY 表的映射**多处双向错位**（详见
wiki/07-corporate/company-law-article-mapping.md §六）。现表依据：
  · 现行法原文：SAMR 官网 https://www.samr.gov.cn/djzcj/zcfg/fl/art/2026/art_9b4263a169cf43c2aba950cfc9ac1af2.html
  · 旧法（2018 修正）原文：中国人大网 http://www.npc.gov.cn/zgrdw/npc/xinwen/2018-11/05/content_2065671.htm
并经自建库 raw/00-法律法规/.../01_中华人民共和国公司法.md 交叉比对。
**不得用「数字在新法中找不到」判断失效。**

【⚠️ 2026-10-24（KB-20261024-001 / B05）判定口径重建】
前一版 RISKY 表的第三列（「现行语义关键词」）是**手写**的，且存在
**系统性错位**：填的是「映射目标条」的内容，而不是「现行同号条」的内容。
例：旧 20 条 → 现行 21/23 条，但表里「现行语义」写的是
「社会责任|公益活动|利益相关者」——那是现行**第 20 条**（社会责任）的内容。

后果是**双向误判**：
  · 正确引用现行第 21 条（讨论「滥用股东权利」）的页面
    → 旧语义命中、错位的现行语义不命中 → **误判为硬失败**；
  · 引用真正现行第 20 条（讨论「社会责任」）的页面
    → 旧语义不命中、现行语义命中 → **误判为「正确」**。

现改为**以「现行同号条」为基准**的判定（三态）：

  设页面写「公司法第 N 条」，上下文语义为 S：
  ① S 命中**现行第 N 条**的内容指纹 → 正确引用现行法（OK-NEW）
  ② 否则 S 命中**旧第 N 条**（2018 修正）的内容特征 → 误引旧条（FAIL）
  ③ 两者都不命中 → 无法判断，列入「须人工核对」（CHECK）

所有内容指纹**由库内权威原文自动派生**（`_company_law_baseline`），
不再手写——从根上消除错位可能。旧法语义特征为人工整理，
已于 2026-10-24 逐条对照旧法原文复核。

【白名单与自核豁免】
`company-law-article-mapping.md` 等文件在 WHITELIST 中被整体豁免
（它们必须并列新旧条号）。但**豁免只针对「引用扫描」，不豁免数据核验**：
  · 本门禁新增 `run_selftest()`：RISKY 表的指纹必须与原文逐字吻合；
  · 映射表自身的逐字核验由 `_verify_company_law_mapping.py` 与
    `_company_law_tri_diff.py`（官方 SAMR / 库内 raw / 映射表 §五
    三向比对）负责。

【退出码】1 = 有硬失败项或自检失败。
"""

import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _paths import ROOT, WIKI, BENCHMARK  # noqa: E402
import _company_law_baseline as base  # noqa: E402

# 旧条号: (现行条号(映射目标, 提示用), 旧法语义特征)
RISKY_OLD = {
    "20": ("21/23", "人格混同|滥用股东权利|滥用公司法人独立地位|逃避债务.*连带责任"),
    "21": ("22", "关联关系|控股股东|实际控制人.*损害"),
    "22": ("25/26/28", "决议内容违反法律.*无效|决议.*可撤销|撤销决议|变更登记.*撤销"),
    "27": ("48", "出资|货币|非货币财产|作价出资"),
    "28": ("49", "按期足额缴纳|缴纳出资|逾期缴纳"),
    "33": ("57", "查阅|复制|股东名册|会计账簿"),
    "34": ("210/227", "分红|分取红利|利润分配|优先认缴|优先.*认缴出资"),
    "39": ("62", "定期会议|临时会议|股东会会议分为"),
    "40": ("63", "召集和主持|董事长主持|董事会召集"),
    "70": ("171-175", "国有独资|监事会成员"),
    "71": ("84", "过半数同意|其他股东过半数|同等条件.*优先购买权"),
    "74": ("89", "合理的价格收购|异议股东|回购"),
    "97": ("110", "查阅复制公司章程|债券存根"),
    "146": ("178", "不得担任.*董事|任职资格|兼职"),
    "147": ("180", "忠实义务|勤勉义务"),
    "148": ("181/183/184", "禁止行为|挪用公司资金|商业机会|同业"),
    "166": ("210", "法定公积金|税后利润"),
    "179": ("223/225/229/230", "合并|分立|解散|登记"),
    "180": ("229", "解散事由|营业期限届满|吊销营业执照"),
    "182": ("231", "司法解散|经营管理发生严重困难|请求人民法院解散"),
    "183": ("232", "清算组由股东组成|成立清算组|清算义务人"),
    "184": ("234", "清算组职权|清算组在清算期间"),
    "185": ("235", "通知公告债权人|公告"),
    "186": ("236", "清算方案|制订清算方案"),
    "187": ("237", "申请破产清算|财产不足清偿"),
    "188": ("239", "清算报告|申请注销登记"),
    "189": ("238", "清算组成员|忠于职守"),
    "190": ("242", "破产清算|被依法宣告破产"),
}


def _cur_nums(s):
    """从「21/23」「210/227」「171-175」「25/26/28」抽出条号。

    「171-175」表示区间（国有独资公司专章），展开为 171..175。
    """
    out = []
    for part in re.split(r"[/、,\s]+", s):
        m = re.match(r"^(\d+)\s*(?:-\s*(\d+))?$", part)
        if not m:
            continue
        a = int(m.group(1))
        b = int(m.group(2)) if m.group(2) else a
        out.extend(range(a, b + 1))
    return out


def _frags(statute, n, limit):
    """取该条的高区分度内容指纹（正则安全形式）。

    指纹由 `_company_law_baseline.Statute.fingerprint()` 自动派生：
      · 优先取**低文档频率的真实法律术语**（「关联关系」「忠实义务」等），
        这些词简短、可被页面引述，因而具备实际判定力；
      · 术语不足时回退到「本条独有的原文片段」（长、几乎不可能被引述，
        仅用于自检回验与极冷门条）。
    """
    out = []
    for s in statute.fingerprint(n, limit=limit):
        if len(s) >= 3:
            out.append(re.escape(s))
    return out


_STATUTE = None


def get_statute():
    global _STATUTE
    if _STATUTE is None:
        _STATUTE = base.load()
    return _STATUTE


def _derive_same_no_keywords(statute, old_num):
    """由**库内权威原文**派生「现行同号条」的内容指纹（判定主依据）。

    旧条号 N 在现行法中仍然存在（内容却完全不同），用户写
    「公司法第 N 条」时，只有上下文讲的是**现行第 N 条的内容**才算正确引用；
    讲的是旧第 N 条的内容即误引。

    ⚠️ 前一版把「现行语义关键词」填成映射目标条（旧20→现21/23）的内容，
    造成双向误判。现改为按**同号条**派生，从根上消除错位。
    """
    if old_num not in statute.articles:
        return ""
    return "|".join(_frags(statute, old_num, 4))


def _derive_target_keywords(statute, cur_nums):
    """派生「映射目标条」内容指纹（用于提示读者应改引哪一条）。"""
    out = {}
    for n in cur_nums:
        out[n] = "|".join(_frags(statute, n, 2))
    return out


# RISKY[旧条号] = {
#   "cur_map": 映射目标条号串（提示用）
#   "old_kw":  旧法（2018 修正）该条内容特征（人工整理，已逐条复核）
#   "same_kw": 现行**同号条**内容指纹（由原文自动派生）← 判定主依据
#   "tgt_kw":  {映射目标条号: 指纹}（由原文自动派生）← 提示用
# }
RISKY = {}
for _old, (_cur, _oldkw) in RISKY_OLD.items():
    _st = get_statute()
    RISKY[_old] = {
        "cur_map": _cur,
        "old_kw": _oldkw,
        "same_kw": _derive_same_no_keywords(_st, int(_old)),
        "tgt_kw": _derive_target_keywords(_st, _cur_nums(_cur)),
    }


def same_no_keywords(num):
    """现行同号条的内容指纹（判定主依据）。"""
    return RISKY[num]["same_kw"]


def target_keywords(num):
    """映射目标条的内容指纹合并（提示读者正确条号）。"""
    kws = []
    for _n, kw in sorted(RISKY[num]["tgt_kw"].items()):
        if kw:
            kws.append(kw)
    return "|".join(kws)


def classify(num, text):
    """对「页面写第 N 条 + 上下文 text」做三态判定。

    返回 "OK-NEW" / "FAIL" / "CHECK" / "PASS"（放行）。
    """
    d = RISKY[num]
    same_hit = bool(d["same_kw"]) and bool(re.search(d["same_kw"], text))
    if same_hit:
        return "OK-NEW"          # 上下文讲的是现行第 N 条的内容
    if re.search(d["old_kw"], text):
        return "FAIL"            # 上下文讲的是旧第 N 条的内容
    return "CHECK"


def run_selftest():
    """对 RISKY 表做自洽性回验——本门禁自身的数据核验。

    这解决了「映射表因 WHITELIST 整体豁免而逃过自身数据核验」的问题：
    G11 的白名单只豁免**引用扫描**，不豁免**数据本身**的正确性。
    """
    st = get_statute()
    out = []
    for old, d in sorted(RISKY.items(), key=lambda x: int(x[0])):
        n = int(old)
        # ① 同号条必须存在于原文库，且指纹来自该条正文
        if n not in st.articles:
            out.append(("旧条号在现行法中已不存在于原文库", old, n, ""))
        else:
            body = re.sub(r"\s+", "", st.article(n)["body"])
            for frag in d["same_kw"].split("|"):
                if not frag:
                    continue
                plain = frag.replace("\\", "")
                if plain and plain not in body:
                    out.append(("同号条指纹与原文不符", old, n, plain))
        # ② 映射目标条必须存在，且其指纹来自各自正文
        for tn, kw in sorted(d["tgt_kw"].items()):
            if tn not in st.articles:
                out.append(("映射目标条号不存在于原文库", old, tn, d["cur_map"]))
                continue
            tbody = re.sub(r"\s+", "", st.article(tn)["body"])
            for frag in kw.split("|"):
                if not frag:
                    continue
                plain = frag.replace("\\", "")
                if plain and plain not in tbody:
                    out.append(("映射目标指纹与原文不符", old, tn, plain))
        # ③ 旧语义关键词必须是有效正则
        try:
            re.compile(d["old_kw"])
        except re.error as e:
            out.append(("旧语义关键词正则非法", old, 0, str(e)))
    return out


# 条号引用模式：**同时支持阿拉伯数字与中文数字**。
#   「公司法第 22 条」「公司法第二十二条」「公司法第二百二十二条」
# ⚠️ 此前只匹配阿拉伯数字，导致中文数字书写的引用**全部漏检**
#    （库内「《公司法》第二十五条」等页面均未被扫描到）。
_CN_NUM = "零一二三四五六七八九十百千"
PAT = re.compile(r"公司法\s*[》】〕]?\s*第\s*([0-9]+|[%s]+)\s*条" % _CN_NUM)


def _norm_num(s: str) -> str:
    """条号文本 → 阿拉伯数字字符串（中文数字转阿拉伯数字）。"""
    s = s.strip()
    if s.isdigit():
        return str(int(s))
    return str(base.cn_to_int(s))

# 明确的历史引用语境——这些是有意标注旧法，放行
HISTORIC = re.compile(
    r"旧法|旧《公司法》|2018\s*年|2010\s*年|原第\s*\d+\s*条|条号已位移|不再参照"
    r"|2018年修正|2018 年修正|历史条文|已失效")

# 已核验未变动的条号，不参与风险判定
SAFE = {"3", "54", "84"}

# 正当引用旧条号的文件（白名单）——
#   company-law-article-mapping.md : 映射表本身必须并列列出新旧条号
#   bench-034.md                  : must_not_mention 陷阱设计，引用旧号=判错
#   benchmark-id-mapping.md       : 判读记录，描述的是「当时发现错误」这一事实
#   lint-reports/2026-10-21-法条核验工作单.md : 人工核验工作单，逐条列出待核条号
# ⚠️ 白名单只豁免「引用扫描」，**不豁免映射表自身的数据核验**——
#    那部分由 `_verify_company_law_mapping.py` / `_company_law_tri_diff.py`
#    （官方三向比对）负责。
WHITELIST = {
    "wiki/07-corporate/company-law-article-mapping.md",
    "benchmark/bench-034.md",
    "benchmark/benchmark-id-mapping.md",
    "lint-reports/2026-10-21-法条核验工作单.md",
}

# 仅扫描这两个范围（内容层）；lint-reports/ 属存档不改（rules.md R24 例外）
SCAN_ROOTS = (WIKI, BENCHMARK)


def scan(root_dir):
    hits = []
    if not os.path.isdir(root_dir):
        return hits
    for r, _d, fs in os.walk(root_dir):
        for f in fs:
            if not f.endswith(".md"):
                continue
            p = os.path.join(r, f)
            try:
                s = open(p, encoding="utf-8", errors="ignore").read()
            except Exception:
                continue
            try:
                rel_p = os.path.relpath(p, ROOT).replace("\\", "/")
            except ValueError:
                # 跨盘符（如临时夹具在 C:）—— 用绝对路径，不参与白名单判断
                rel_p = p.replace("\\", "/")
            if rel_p in WHITELIST:
                continue
            lines = s.split("\n")
            for i, ln in enumerate(lines, 1):
                for m in PAT.finditer(ln):
                    num = _norm_num(m.group(1))
                    if num in SAFE or num not in RISKY:
                        continue
                    ctx = ln.strip()
                    # 取该行所在段落作上下文（表格行的语义在相邻行）
                    window = "\n".join(lines[max(0, i - 3):i + 2])
                    if HISTORIC.search(ctx) or HISTORIC.search(window):
                        continue  # 有意标注旧法
                    state = classify(num, window)
                    cur = RISKY[num]["cur_map"]
                    hits.append((state, rel_p, i, num, cur, ctx[:90]))
    return hits


def main():
    print("=" * 74)
    print("G11 · 公司法旧条号引用检测（2026-10-24 全表重建 / B05 判定口径重建）")
    print("=" * 74)
    print("高危条号（旧号在现行法中内容已变，误引最危险）：")
    for k, d in sorted(RISKY.items(), key=lambda x: int(x[0])):
        print("  旧第{0:>3} 条 -> 现{1}".format(k, d["cur_map"]))
    print("已核验未变动，不参与判定：", "、".join("第 " + x + " 条" for x in sorted(SAFE, key=int)))
    print()

    # ---- 自洽性回验（先跑，避免用错数据去判别人）----
    stf = run_selftest()
    print("-" * 74)
    print("【数据自洽性回验】RISKY 表的内容指纹须与库内原文一致")
    for why, old, n, det in stf:
        print("  [FAIL] 旧第 %s 条 -> 现第 %s 条 —— %s：%s" % (old, n, why, det))
    if not stf:
        print("  [PASS] %d 条映射的现行同号条指纹、映射目标指纹全部与原文库逐字吻合"
              % len(RISKY))
    print()

    hits = scan(WIKI) + scan(BENCHMARK)
    fails = [h for h in hits if h[0] == "FAIL"]
    checks = [h for h in hits if h[0] == "CHECK"]
    oks = [h for h in hits if h[0] == "OK-NEW"]

    print("-" * 74)
    print("【硬失败】引用旧条号且上下文为旧语义（内容已变，必须改）")
    for _s, p, i, num, cur, ctx in fails:
        print("  {0}:{1}  第 {2} 条 -> 现第 {3} 条".format(p, i, num, cur))
        print("      {0}".format(ctx))
    if not fails:
        print("  （无）")

    print("\n【须人工核对】出现高危条号但上下文无法判断语义")
    for _s, p, i, num, cur, ctx in checks:
        print("  {0}:{1}  第 {2} 条（现第 {3} 条）".format(p, i, num, cur))
        print("      {0}".format(ctx))
    if not checks:
        print("  （无）")

    print("\n【正确】引用的是现行同号条的内容")
    for _s, p, i, num, cur, ctx in oks:
        print("  {0}:{1}  第 {2} 条（现语义）".format(p, i, num))
    if not oks:
        print("  （无）")

    print("\n" + "=" * 74)
    print("硬失败 {0} 处 | 须核对 {1} 处 | 正确 {2} 处".format(
        len(fails), len(checks), len(oks)))

    if stf:
        print("\n结论：FAIL —— RISKY 表自身数据不自洽，拒绝据此判定。")
        sys.exit(1)
    if fails:
        print("\n结论：FAIL —— 存在引用已位移旧条号的页面，读者一查即发现。")
        print("对照表：wiki/07-corporate/company-law-article-mapping.md")
        sys.exit(1)
    print("\n结论：PASS —— 未发现引用旧公司法条号的情况。")
    print("（“须人工核对”项不阻断发布，但须列入待办清单）")


if __name__ == "__main__":
    main()
