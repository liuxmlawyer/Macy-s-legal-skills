"""Executable source routing: reuse FLK, configured case/PKU providers, then actual official fetches."""
from pathlib import Path
import os,json,subprocess,urllib.request,urllib.parse,hashlib,datetime as dt,re
from _knowledge_policy import ROOT,read_raw,hydrate

def configured(name,path):
    value=os.environ.get(name)
    if not value:return None,'该来源适配器未配置，未声称已调用成功'
    argv=json.loads(value)
    if not isinstance(argv,list) or not argv or not all(isinstance(x,str) for x in argv):raise ValueError(name+'必须是命令参数JSON数组')
    run=subprocess.run([*argv,'--page',str(path)],capture_output=True,text=True,encoding='utf-8',timeout=60)
    if run.returncode:return None,'适配器非零退出：'+str(run.returncode)
    return json.loads(run.stdout),''

def route(path):
    path=Path(path).resolve()
    if not path.is_relative_to((ROOT/'wiki').resolve()):raise ValueError('路径越界')
    text=path.read_text(encoding='utf-8-sig');raw,body=read_raw(text);fm=hydrate(raw)
    attempts=[];candidates=[]
    source0='人民法院案例库' if raw.get('type')=='case' else 'flk-npc'
    for provider in [source0,'pkulaw','官方站点直查']:
        try:
            if provider=='flk-npc':
                from _source_query_v42 import run_query
                result=run_query(page_path=str(path))
            elif provider in ('pkulaw','人民法院案例库'):
                result,reason=configured('KB_PKULAW_QUERY_COMMAND' if provider=='pkulaw' else 'KB_CASE_QUERY_COMMAND',path)
                if result is None:attempts.append({'source':provider,'ok':False,'reason':reason});continue
            else:
                for url in raw.get('sources',[]):
                    if not str(url).startswith(('https://','http://')):continue
                    if not (urllib.parse.urlparse(url).hostname or '').endswith('.gov.cn'):continue
                    cache=ROOT/'_meta/fetch-cache'/hashlib.sha256(url.encode()).hexdigest()
                    cp=cache.with_suffix('.json');cached=json.loads(cp.read_text(encoding='utf-8')) if cp.exists() else None
                    # Reuse actual fetched raw bytes for one day. A cache hit is not a fresh verification date.
                    source_file=cache.with_suffix('.source')
                    if cached and cached.get('ok', True) and source_file.exists() and hashlib.sha256(source_file.read_bytes()).hexdigest()==cached.get('sha256') and 0 <= (dt.datetime.now()-dt.datetime.fromisoformat(cached['fetched_at'])).total_seconds()<86400:
                        candidates.append(cached);continue
                    try:
                        with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'LegalKnowledgeAudit/5.0'}),timeout=20) as response:
                            payload=response.read()
                        if b'EO_Bot_Ssid' in payload or b'__tst_status' in payload:
                            raise ValueError('站点返回脚本验证页，不是原文')
                        cache.parent.mkdir(parents=True,exist_ok=True);cache.with_suffix('.source').write_bytes(payload)
                        ev={'url':url,'fetched_at':dt.datetime.now().isoformat(timespec='seconds'),'sha256':hashlib.sha256(payload).hexdigest(),'bytes':len(payload),'note':'实际取得原文；不自动等同于本页所有结论已核验'}
                        cp.write_text(json.dumps(ev,ensure_ascii=False,indent=2),encoding='utf-8');candidates.append(ev)
                    except Exception as e:attempts.append({'source':provider,'url':url,'ok':False,'reason':type(e).__name__+': '+str(e)[:160]})
                attempts.append({'source':provider,'ok':bool(candidates),'reason':'原文下载与本页核验分开；新证据须完成对象/版本/条文内容及结论适用比对'})
                break
            # A provider response alone does not establish a successful page verification.
            import _meta_rules as MR
            ok,normal,errors=MR.validate_source_result(result)
            bound,be,_=MR.check_target_binding(result.get('target'),fm,text,path.relative_to(ROOT).as_posix(),source_result=result)
            evidence,ee=MR.check_verify_record(result,fm)
            if ok and bound and evidence:
                attempts.append({'source':provider,'ok':True});result['routing_attempts']=attempts;return result
            attempts.append({'source':provider,'ok':False,'reason':'；'.join(errors+be+ee) or result.get('note','本页核验未成立')})
        except Exception as e:attempts.append({'source':provider,'ok':False,'reason':type(e).__name__+': '+str(e)[:160]})
    return {'query_ok':False,'kind':'案例' if raw.get('type')=='case' else '法规','note':'未取得可直接写回的逐页核验回执；已取得原文可供后续比对','verify_source':'','verified_at':'','routing_attempts':attempts,'candidate_documents':candidates}

def main():
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('--page',required=True);ap.add_argument('--out',required=True);args=ap.parse_args()
    result=route(ROOT/args.page);Path(args.out).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print('query_ok =',result['query_ok'],'实际路由',len(result['routing_attempts']),'级；未成功时不写核验日期')
    return 0 if result['query_ok'] else 1
if __name__=='__main__':raise SystemExit(main())
