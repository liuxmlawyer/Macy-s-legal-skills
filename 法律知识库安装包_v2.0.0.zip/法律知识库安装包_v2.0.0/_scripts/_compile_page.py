# -*- coding: utf-8 -*-
"""编译新页：为尚无外置记录的知识页创建 `_meta/pages/<id>.json`。

【为什么需要】
本地发布插件与 `_scripts/_publish_pages.py` 都要求页面**已有外置记录**
（插件在缺记录时提示「缺少外置记录，请先运行自动编译」）。
本脚本补上这一步，使「新建页面 → 建记录 → 发布 → 可检索」在全新空库上可走通。

【它做什么】
1. 读取页面 YAML 头，校验 8 项基础属性是否齐备；
2. 按 `semantic_hash` 计算内容绑定哈希；
3. 写入外置记录（含 schema/id/path/content_hash/legacy/evidence_refs/issues/approval）；
4. **不批准**。新记录 `approval` 为 null、`publish_status` 保持草稿，
   批准仍须由作者在 Obsidian 发布面板或 `_publish_pages.py` 显式完成。

【安全约束】
· 默认 dry-run，只报告不写入；须显式 `--write` 才落盘；
· 只处理 `wiki/` 下的页面，绝不动 `raw/`、`draft/` 与既有记录；
· 已存在记录时**不覆盖**，仅报告既有记录状态；
· 不生成任何人工核验日期，不伪造来源核验。

用法：
    python _scripts/_compile_page.py --page wiki/01-labor/terms/xxx.md
    python _scripts/_compile_page.py --page wiki/01-labor/terms/xxx.md --write
    python _scripts/_compile_page.py --scan wiki --write
"""
from pathlib import Path
import argparse
import json
import re
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
import _knowledge_policy as K


def build_record(data: dict, body: str, rel_path: str) -> dict:
    """按 V5 结构生成外置记录。approval 为 null —— 批准不由本脚本产生。"""
    return {
        "schema": 5,
        "id": data["id"],
        "path": rel_path,
        "content_hash": K.semantic_hash(data, body),
        "legacy": {
            "status": data.get("status", "待核实"),
            "verify_source": "未核验",
            "review_status": "草稿",
        },
        "evidence_refs": [],
        "issues": [],
        "approval": None,
        "publication_history": [],
        "machine_queue": ["按需补充真实来源证据；作者批准后方进入默认检索"],
        "display_cleanup": "无",
    }


def refresh_record(data: dict, body: str, rel_path: str, rec: dict) -> dict:
    """内容变化后刷新绑定：归档旧批准、解除批准，并把状态退回草稿。

    与 Obsidian 插件「仅保存属性」的语义一致——
    旧批准对应旧版本，不能自动沿用到新内容上。
    """
    rec = dict(rec)
    old_approval = rec.get("approval")
    if old_approval:
        rec.setdefault("approval_history", []).append(old_approval)
        rec["approval"] = None
    rec["content_hash"] = K.semantic_hash(data, body)
    rec.setdefault("publication_history", []).append({
        "at": __import__("datetime").datetime.now().astimezone().isoformat(
            timespec="seconds"),
        "action": "invalidate_on_content_change",
        "note": "内容变化，绑定已刷新；旧批准归档，需作者重新发布",
    })
    return rec


def compile_one(path: Path, write: bool):
    root = Path(K.ROOT)
    rel = path.relative_to(root).as_posix()
    if not path.resolve().is_relative_to((root / "wiki").resolve()):
        raise ValueError("仅允许编译 wiki/ 下的知识页")
    data, body = K.read_raw(path.read_text(encoding="utf-8-sig"))

    missing = [k for k in K.CORE if k not in data]
    if missing:
        raise ValueError("缺少基础属性：%s（请先补齐 YAML 头）" % "、".join(missing))
    if not str(data.get("id") or "").strip():
        raise ValueError("缺少 id，请先指定稳定唯一 ID")
    rec_path = root / "_meta" / "pages" / ("%s.json" % data["id"])

    if rec_path.is_file():
        rec = json.loads(rec_path.read_text(encoding="utf-8"))
        current = K.semantic_hash(data, body)
        if rec.get("content_hash") == current:
            return (data["id"], "已有记录（内容绑定一致），未改动", False)
        if not write:
            return (data["id"], "内容已变化，刷新绑定并退回草稿；预览未写入", True)
        rec = refresh_record(data, body, rel, rec)
        rec_path.write_text(json.dumps(rec, ensure_ascii=False, indent=2) + "\n",
                            encoding="utf-8", newline="\n")
        # 页面状态同步退回草稿（与插件一致）
        text = path.read_text(encoding="utf-8-sig")
        text2 = re.sub(r"(?m)^publish_status:[^\r\n]*",
                       "publish_status: 草稿", text)
        if text2 != text:
            path.write_text(text2, encoding="utf-8", newline="")
        return (data["id"], "已刷新绑定并退回草稿（旧批准已归档，需重新发布）", True)

    record = build_record(data, body, rel)
    if not write:
        return (data["id"], "可创建记录；预览未写入", True)

    rec_path.parent.mkdir(parents=True, exist_ok=True)
    rec_path.write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n",
                        encoding="utf-8", newline="\n")
    return (data["id"], "已创建外置记录（未批准，待作者发布）", True)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--page", help="单个页面路径")
    g.add_argument("--scan", help="扫描目录下的全部页面")
    ap.add_argument("--write", action="store_true", help="实际写入（默认只预览）")
    args = ap.parse_args()

    root = Path(K.ROOT)
    if args.page:
        targets = [root / args.page]
    else:
        targets = sorted((root / args.scan).rglob("*.md"))

    mode = "写入" if args.write else "预览"
    print("编译新页 | 模式：%s | 目标 %d 个" % (mode, len(targets)))
    print("=" * 68)

    ok = failed = changed = 0
    for p in targets:
        try:
            ident, note, needs = compile_one(p, args.write)
            if needs:
                changed += 1
            ok += 1
            print("  [OK]   %-28s %s" % (ident, note))
        except Exception as exc:
            failed += 1
            print("  [FAIL] %-28s %s" % (p.name[:28], exc))

    print("=" * 68)
    print("成功 %d ｜ 失败 %d ｜ 需要记录或更新 %d" % (ok, failed, changed))
    if not args.write and changed:
        print("\n预览完成。加 --write 才会实际创建记录。")
    if not args.write and failed:
        print("\n有页面不符合要求，修正 YAML 头后重试。")
    elif args.write:
        print("\n记录已创建。新页面仍为草稿，请在 Obsidian 发布面板点击")
        print("「保存并发布 / 允许检索」，或运行 _scripts/_publish_pages.py 完成批准。")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
