"""自建法律知识库 MCP Server

遵循 ROOT\\rules.md（V3.0）规范：
  - raw/ 只读：本 MCP 仅读取，绝不写入/修改/移动
  - 混合检索：wiki 为主，raw 为辅（§3.1）
  - 回答强制：标注来源层级、引用可溯源、待核实须提示（Q1-Q5）

工具设计对应用户要求：
  - 公开现行有效法规为准（权威性裁决由调用方做，本 MCP 只负责取数与标注）
  - 自建知识库为辅助（提供外部查不到的增量：判例、专题、笔记）
"""
from __future__ import annotations

import os, sys

# 路径单一真源（V3.7）在库根/_scripts/ 下，需先定位库根再把它加入 sys.path。
# 顺序不能变：__future__ 必须是文件首个语句。
_KB_ROOT = os.environ.get("KNOWLEDGE_ROOT") or os.environ.get("KB_ROOT")
if not _KB_ROOT:
    # scripts/ -> <MCP名> -> legal-tools -> tools -> <库根>
    _probe = os.path.dirname(os.path.abspath(__file__))
    for _i in range(4):
        _probe = os.path.dirname(_probe)
        if os.path.isdir(os.path.join(_probe, "wiki")):
            _KB_ROOT = _probe
            break
    else:
        _KB_ROOT = os.path.abspath(os.path.join(
            os.path.dirname(os.path.abspath(__file__)), "..", "..", "..", ".."))
sys.path.insert(0, os.path.join(_KB_ROOT, "_scripts"))
from _paths import ROOT  # 路径单一真源（V3.7）

import asyncio
import os
import re
import sys
from pathlib import Path
from typing import Optional

from mcp.server.fastmcp import FastMCP
from pydantic import BaseModel, Field


def _resolve_root() -> Path:
    """复用 _paths 的已校验根目录；不另设探测或覆盖规则。"""
    return Path(ROOT)


ROOT = _resolve_root()
WIKI = ROOT / "wiki"
DRAFT = ROOT / "draft"
RAW = ROOT / "raw"

# 领域编码 → 中文名（rules.md §1.2 十域）
DOMAINS = {
    "01-labor": "劳动与人事",
    "02-contract": "合同",
    "03-tort": "侵权与不当得利",
    "04-ip": "知识产权",
    "05-family": "婚姻家事",
    "06-admin": "行政",
    "07-corporate": "公司商事",
    "08-data": "数据与AI合规",
    "09-criminal": "刑事",
    "10-cross": "跨领域",
}

# raw 目录 → 说明（用于取数说明与来源标注）
# 依现行 rules.md：核心三类客观素材；收藏文章仅作研究参考，资料包索引不等于正文
RAW_LAYERS = {
    "00-法律法规": ("法规与司法解释原文（直通发布 → terms/）", "法条原文"),
    "01-模板与范本": ("各类法律文书模板（直通发布 → topics/）", "范本"),
    "02-司法案例": ("裁判文书、指导性案例（**唯一需五步编译**）", "裁判文书"),
    "05-收藏文章": ("个人收藏的好文章（写作素材库，含 usable_for 可复用点标注）", "实务分析"),
    "06-资料包索引": ("二进制资料包索引（**只有索引，无正文**，命中需人工打开原文件）", "实务分析"),
}

# 需编译 vs 直通发布 —— 供检索结果标注处理路径
COMPILE_LAYER = "02-司法案例"

TEXT_EXT = {".md", ".txt"}
DOC_EXT = {".pdf", ".doc", ".docx", ".wps"}

# ── 发布资格判定（P1-2：正式检索 / 研究检索分离）────────────────────────────
# 正式模式（scope="official"）**只返回满足下列全部条件**的页面：
#   ① review_status ∈ {已发布, 已审核}   —— **已进入正式库**
#   ② verify_source 属真实核验来源         —— 不是「未核验」「批量推定」或缺失
#   ③ 核验日期按路径取值且为真实日历日期、未晚于今天：
#        · verify_source = 人工核验 → last_verified（人工核验日期）
#        · verify_source = 自动核验来源 → verified_at（真实自动核验时间）
#        ⚠️ V4.1：**不再以「人工日期缺失」阻断真实自动核验**
#   ④ status == 现行有效                   —— 效力状态明确且有效
# 不满足者一律排除，并在响应中说明**排除原因**。
# ⚠️ 该判定只依据 frontmatter 字段，**不代表内容已被逐页复核**——
#    内容审核与效力核验是两件事（见 P1-1 记录口径）。
# ⚠️ 2026-10-24（KB-20261024-001 / B02）：发布资格判定与 frontmatter 解析
# 已抽出到库根 `_scripts/_publish_gate.py`，理由有二：
#   ① 判定逻辑可**脱离 MCP 运行时被独立测试**（server.py 依赖 mcp/pydantic，
#      无法在无 MCP 环境下导入，安全关键判定因此无法回归测试）；
#   ② 旧实现用扁平正则**跳过所有缩进行**，`verify_record`（嵌套字典）、
#      `citations`/`clauses`（列表）根本解析不出来——B02 要求的证据校验
#      无从谈起。现改为**真实 YAML 解析**（PyYAML 优先，内置 YAML 子集
#      解析器回退；两者在本库 967 个 frontmatter 上解析结果完全一致）。
# ⚠️ 2026-10-25（RULE-20261025-001 / V4.1）：「已发布」的语义已变更——
#   **已发布 = wiki 内部入库成功**（写入 + 索引 + 必要技术校验全部通过），
#   **不代表已人工审核**。响应文案**不得**再出现
#   「review_status=已发布，所以已过人工审核关」这类推断。
from _publish_gate import (  # noqa: E402
    FM_RE,
    PUBLISH_REVIEW_OK,
    PUBLISH_STATUS_OK,
    PUBLISH_VERIFY_AUTO,
    PUBLISH_VERIFY_NONE,
    PUBLISH_VERIFY_REAL,
    official_layer_allowed,
    parse_frontmatter as _parse_fm,
    publish_gate as _publish_gate_impl,
    research_version_note,
)


def _rel_path(target: Path) -> str:
    """把路径转成相对库根的 POSIX 风格路径。

    target 可能是绝对路径（由 ROOT 拼接而来），也可能是已相对化的路径
    （调用方传了相对路径时 p 本身就是相对路径）——两种都要能处理。
    """
    try:
        return str(target.relative_to(ROOT)).replace("\\", "/")
    except ValueError:
        return str(target).replace("\\", "/")


def _read(path: Path, limit: Optional[int] = None) -> str:
    """读取文件文本。

    limit=None → 读取**全文**（不截断）。
    limit=N   → 只读前 N 字符（仅用于概览统计等不需要正文的地方）。

    ⚠️ 2026-10-24（P0-3）：此前默认 limit=4000，检索与读取均**静默截断**，
    导致长页尾部关键词查不到、页面读取自称"全文"实为前 20000 字。
    现默认读全文；截断必须显式传 limit。
    """
    try:
        t = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ""
    if limit is None:
        return t
    return t[:limit]


def _snippet(text: str, kw: str, span: int = 220) -> str:
    """在正文中定位关键词并截取上下文，用于命中片段。

    ⚠️ 2026-10-24（P0-3）：改为在**全文**上定位（原调用方传的是已截断文本），
    并返回全部命中次数，供调用方判断命中强度。
    """
    if not kw or not text:
        return ""
    low = text.lower()
    for kw_line in [k.strip() for k in kw.split() if k.strip()]:
        i = low.find(kw_line.lower())
        if i >= 0:
            s = max(0, i - span // 2)
            return ("…" if s > 0 else "") + text[s:i + span].strip() + ("…" if i + span < len(text) else "")
    return ""


def _hit_count(text: str, kw: str) -> int:
    """统计关键词在全文中的命中次数（AND 语义：返回全部词的总命中数）。"""
    if not kw or not text:
        return 0
    low = text.lower()
    n = 0
    for t in [k.strip() for k in kw.split() if k.strip()]:
        n += low.count(t.lower())
    return n


def _status_warning(fm: dict) -> str:
    from _knowledge_policy import usage_note
    return usage_note(fm)


def _judge_note(fm: dict) -> str:
    """地域规则必须标注适用地域（rules.md Q2）。

    注意：库中存在 jurisdiction=法律 / 行政法规 等**法源类型**误填值（13+2 条），
    这类不是地域，须过滤，否则会误报「适用地域为法律」。
    """
    j = (fm.get("jurisdiction") or "").strip()
    if not j or j in ("全国",):
        return ""
    if j in ("法律", "行政法规", "司法解释", "部门规章", "地方性法规", "unknown"):
        return ""
    parts = [p.strip() for p in re.split(r"[/、,，]", j) if p.strip()]
    real = [p for p in parts if p not in ("全国", "法律", "行政法规", "unknown")]
    if not real:
        return ""
    return ("\n\n> 📍 **地域提示**：本内容涉及地域 **" + "、".join(real) +
            "**，不得推定全国适用；地方裁审口径存在差异，引用前请确认适用地区。")


def _is_real_date(s: str) -> bool:
    """严格日历校验：格式 + 真实存在的日期。

    ⚠️ 不能只用 `datetime.date.fromisoformat`——Python 3.11+ 对 "2026-10-23"
    这类溢出值会**静默容忍**（回退 ISO 周日期解析），会让非法日期蒙混过关。
    """
    if not re.match(r"^\d{4}-\d{2}-\d{2}$", s or ""):
        return False
    import datetime
    try:
        y, m, d = (int(x) for x in s.split("-"))
        return datetime.date(y, m, d).isoformat() == s
    except (ValueError, TypeError):
        return False


def _publish_gate(fm: dict, rel_path: str = "", legacy_paths=None):
    """判定页面是否满足正式检索（official scope）的发布条件。

    返回 (是否合格, 排除原因列表)。原因列表为空表示合格。
    判定依据仅为 frontmatter 字段，**不构成内容已复核的保证**。

    ⚠️ 2026-10-24（KB-20261024-001 / B02）修复要点：
      * `status` **缺失即排除**（旧实现 `if st and st not in ...` 会放行无状态页）；
      * 校验 `verify_record`：必须可解析、关键字段齐全、含实际证据定位
        （official_url 为 http(s) 地址、evidence_location 非空、verified_on 为真实日期）；
      * `last_verified` 不得晚于今天（未来日期＝疑似脚本批量填充）；
      * 未过复核周期（next_review 或 last_verified + 所属域周期）即排除。
    实现见库根 `_scripts/_publish_gate.py`。

    ⚠️ 2026-10-25（RULE-20261025-001 v2 补正）：本包装现传入
    `rel_path` 与 `legacy_paths`，使 MCP 与 `_check_gate.py`、
    `_meta_rules.resolve_verification()` 使用**完全同一套**核验日期口径
    （旧记录回退仅限基线清单中可确认的旧页；新记录缺 `verified_at` 阻断）。
    """
    if legacy_paths is None:
        legacy_paths = _legacy_paths()
    return _publish_gate_impl(fm, rel_path=rel_path,
                              legacy_paths=legacy_paths)


#: 「可确认的旧记录」清单缓存（基线 manifest 权威来源；不可用 → 空集合）
_LEGACY_PATHS = None


def _legacy_paths():
    """加载可确认的旧记录路径集合（fail-closed：不可用返回空集合）。"""
    global _LEGACY_PATHS
    if _LEGACY_PATHS is None:
        _LEGACY_PATHS = set()
        try:
            from _legacy_pages import load_legacy_paths  # noqa: E402
            _LEGACY_PATHS = load_legacy_paths(root=str(ROOT))
        except Exception:
            _LEGACY_PATHS = set()
    return _LEGACY_PATHS


class SearchInput(BaseModel):
    keyword: str = Field(..., description="检索关键词。空格分隔表示同时包含（AND）。")
    domain: Optional[str] = Field(
        None, description="限定领域编码，如 01-labor / 08-data。留空则全库检索。")
    layer: Optional[str] = Field(
        "wiki", description="检索层：wiki（正式知识库，默认）/ draft（草稿）/ raw（原始素材）")
    page_type: Optional[str] = Field(
        None, description="页面类型：term 词条 / case 案例 / topic 专题 / index 索引。留空不限。")
    include_raw_fallback: bool = Field(
        True, description="wiki 无结果时是否回落 raw（默认 True，对应 rules.md §3.1 复核通道）")
    max_results: int = Field(10, description="最多返回条数，默认 10。")
    include_content: bool = Field(
        True, description="是否返回正文片段。False 时只返回标题与元数据（省 token）。")
    match_mode: str = Field(
        "fulltext",
        description="匹配范围：fulltext（默认，全文匹配）/ title（仅标题与路径，快速）。"
                    "fulltext 会读取文件全部内容，长库耗时略长但不会漏掉长页尾部关键词。")
    scope: str = Field(
        "usable",
        description="检索范围：usable（默认，作者已发布且无实质阻断，含个人总结）；verified/official（按类型核对官方来源：法规版本或官方案例发布文本）；"
                    "research（研究资料，须按返回状态和来源边界使用）。严格核验资格不代表逐句人工审核。")
    include_excluded: bool = Field(
        True,
        description="在 usable/verified/official 范围中，是否附上被排除页面的清单与排除原因，"
                    "便于追溯「为什么这条没被正式收录」。")


class ReadPageInput(BaseModel):
    path: str = Field(..., description="页面相对路径，如 wiki/01-labor/terms/xxx.md")
    offset: int = Field(
        0,
        description="起始字符偏移（基于**去掉 frontmatter 后的正文**计算）。默认 0，从头读起。"
                    "续读时传入上次返回的 next_offset。")
    limit: int = Field(
        0,
        description="本次最多返回的正文字符数。0 表示不限（尽可能一次读完）。"
                    "正文超过 limit 时返回 truncated=true 与 next_offset。")
    include_meta: bool = Field(
        True, description="是否返回 frontmatter 元数据区块。")
    body_only: bool = Field(
        False,
        description="⚠️ 2026-10-24（KB-20261024-001 / B03）新增。"
                    "True 时返回**严格 JSON**（便于程序化校验分页重组）："
                    "body 字段是本次**实际返回**的正文 chunk（未经任何重建），"
                    "并附 total_length / offset / next_offset / has_more。"
                    "False（默认）时返回原 Markdown 全文，行为不变。")


class StatsInput(BaseModel):
    domain: Optional[str] = Field(None, description="限定领域编码。留空统计全库。")


class IndexInput(BaseModel):
    domain: Optional[str] = Field(None, description="领域编码。留空返回全库总览 + 各领域成熟度。")


# pydantic 2.x 在 from __future__ import annotations 场景下，
# 动态生成的 *Arguments 模型无法解析 Optional → 显式重建一次。
for _m in (SearchInput, ReadPageInput, StatsInput, IndexInput):
    _m.model_rebuild(_types_namespace={"Optional": Optional})


mcp = FastMCP("legal_kb", host="127.0.0.1", port=18080)


@mcp.tool(
    name="kb_overview",
    annotations={"title": "知识库总览与领域成熟度",
                 "readOnlyHint": True, "destructiveHint": False,
                 "idempotentHint": True, "openWorldHint": False},
)
async def kb_overview(params: IndexInput) -> str:
    """查看自建法律知识库的总览：各领域页面数量、发布状态、来源层级构成。

    用于回答"我的知识库里有什么/哪个领域比较完整"这类问题，避免盲目检索。

    Args:
        params: domain 限定领域编码（可选），留空返回全部领域。

    Returns:
        Markdown 格式的库状态报告。
    """
    from collections import Counter

    if params.domain:
        targets = [params.domain]
    else:
        targets = list(DOMAINS.keys())

    lines = ["# 自建法律知识库总览", "",
             f"**根目录**：`{ROOT}`", ""]

    if not WIKI.exists():
        lines.append("> ⚠️ `wiki/` 目录不存在，检索能力不可用。")
        return "\n".join(lines)

    rows = []
    for code in targets:
        d = WIKI / code
        name = DOMAINS.get(code, code)
        if not d.is_dir():
            rows.append((code, name, 0, 0, 0, 0, "—"))
            continue
        n_all = n_pub = n_draft = 0
        types = Counter()
        for dp, dn, fn in os.walk(d):
            for f in fn:
                if not f.endswith(".md"):
                    continue
                n_all += 1
                fm = _parse_fm(_read(Path(dp) / f, 2000))
                t = fm.get("type", "")
                types[t or "?"] += 1
                if fm.get("review_status") == "已发布":
                    n_pub += 1
                else:
                    n_draft += 1
        rows.append((code, name, n_all, n_pub, n_draft,
                     types.get("term", 0) + types.get("case", 0) + types.get("topic", 0),
                     types.get("term", 0)))

    lines.append("| 编码 | 领域 | 页面数 | 已发布 | 待审/草稿 | 正文页 | 其中词条 |")
    lines.append("|---|---|---|---|---|---|---|")
    for code, name, a, p, dr, body, term in rows:
        lines.append(f"| `{code}` | {name} | {a} | {p} | {dr} | {body} | {term} |")

    lines += ["", "---", "",
              "**检索层说明**：", "",
              "| 层 | 路径 | 定位 |", "|---|---|---|",
              "| wiki | `wiki/` | 正式发布知识库（**检索主路径**）|",
              "| draft | `draft/` | AI 编译草稿，待人工审核 |",
              "| raw | `raw/` | 原始素材，只读（含 PDF/DOC 二进制，文本检索受限）|", "",
             "⚠️ **时效性提示**：本库多数页面 `status=待核实`、`review_status=草稿`，",
             "系 AI 编译产物。引用其法律结论前须由执业律师复核；法条的**效力状态**",
             "（现行有效/已修订/已废止）应以北大法宝或国家法律法规数据库的实时检索结果为准。",
             "",
             "⚠️ **入库状态语义**（rules.md V4.1）：`review_status=已发布` 表示",
             "**该页已成功进入 wiki 并通过必要技术校验**，**不代表已人工审核**；",
             "`已审核` 才表示确经人工审核。两者都**不等于**正文已逐页复核。"]
    return "\n".join(lines)


@mcp.tool(
    name="kb_search",
    annotations={"title": "检索自建法律知识库（wiki 为主 / raw 为辅）",
                 "readOnlyHint": True, "destructiveHint": False,
                 "idempotentHint": True, "openWorldHint": False},
)
async def kb_search(params: SearchInput) -> str:
    """检索自建法律知识库。混合检索策略：wiki 为主路径，raw 为复核兜底。

    对应 rules.md §3.1：先读 wiki 领域索引→页面，Wiki 不足或用户要求溯源时回落 raw 原文。

    ⚠️ 使用纪律（务必遵守）：
      1. 本库内容多为 AI 编译草稿，**不是权威法律依据**。
      2. 法条的现行有效性必须用外部 MCP（北大法宝 / 国家法律法规数据库）核验。
      3. 本工具的定位是补充外部检索查不到的增量：本人收集的判例、专题资料、学习笔记。
      4. 引用结果时必须标注来源层级（法条原文 / 裁判文书 / 实务分析）。

    ⚠️ 2026-10-24（P0-3）行为变更：
      - 匹配范围默认 `fulltext`：**读取全文**做匹配，不再只查前 600 字，
        长页尾部的关键词同样能被检出。
      - 如需快速粗筛，可传 `match_mode="title"`（仅标题/路径/ID）。
      - 未命中时提示语改为「**本次未检出**」，**不再声称「知识库未收录」**。
      - PDF/DOC 等二进制**不索引正文**，命中仅按文件名，并已明示。

    检索范围参数（V5.1）：
      - `scope="usable"`（默认）：仅返回有批准记录且无实质阻断的wiki页面。
      - `scope="research"`：研究用，返回全部命中页面（含未核验草稿），
        每条注明发布状态；**不可直接作为对客法律意见依据**。
      - `scope="verified"`或兼容`scope="official"`：额外核验，**只返回满足发布条件的页面**——
        review_status ∈ {已发布, 已审核} ＋ 真实核验来源 ＋ 合法 last_verified
        ＋ status=现行有效。被排除的命中页面会列出**排除原因**。
      - 判定依据页面属性与外置批准、内容绑定及来源证据，不等于内容已逐句人工复核。

    Args:
        params: 检索参数，见 SearchInput 各字段。

    Returns:
        Markdown 格式结果列表，含元数据、命中片段、来源标注与效力状态提示。
    """
    kw = params.keyword.strip()
    if not kw:
        return "❌ keyword 不能为空。"

    terms = [t for t in kw.split() if t]
    layer = (params.layer or "wiki").lower()
    max_results = max(1, min(int(params.max_results or 10), 50))
    scope = (params.scope or "usable").lower()
    if scope == "verified": scope = "official"
    if scope not in ("research", "official", "usable"):
        return ("❌ scope 只能是 usable（默认可用知识）、verified/official（现行核验）、research（研究）。原规则说明："
                "只返回满足发布条件的页面）。收到：%r" % scope)
    official = scope in ("official", "usable")
    # ⚠️ 2026-10-24（KB-20261024-001 / B02）：official 模式下显式传
    # layer="raw"/"draft" **不得绕过**发布条件。
    #   raw  —— 原始素材，未经发布流程，official 一律不检索；
    #   draft—— 草稿层，绕开 wiki 层的发布流程同样禁止。
    # 历史版本条文研究请用 scope="research"，并在结论中说明版本。
    _ok, _why = official_layer_allowed(layer, scope)
    if not _ok:
        return ("❌ " + _why)

    def match(text: str) -> bool:
        low = text.lower()
        return all(t.lower() in low for t in terms)

    results = []
    excluded = []
    searched = []

    # ---------- 主路径：wiki / draft ----------
    if layer in ("wiki", "draft"):
        base = WIKI if layer == "wiki" else DRAFT
        code_filter = params.domain
        if code_filter and code_filter not in DOMAINS:
            return "❌ 未知领域编码：" + str(code_filter)

        # ⚠️ 2026-10-24（P1-4 复现时发现）修复：**根目录页面被漏检**。
        # 原实现只遍历 `wiki/` 下的**领域子目录**，导致根目录的
        # 《法律知识库搭建指南》《法律知识库使用手册》《法律工具速查卡》
        # 《wiki-index》等页面**永远搜不到**——它们不在任何领域目录内。
        # 现改为：先收集领域子目录，再补上 base 根目录下的 .md 文件。
        target_files = []
        if code_filter and (base / code_filter).is_dir():
            roots = [base / code_filter]
        else:
            roots = []
            if base.is_dir():
                roots = [base / d for d in sorted(os.listdir(base))
                         if (base / d).is_dir()]
                # 根目录直属的 .md（不含领域目录里的）
                for f in sorted(os.listdir(base)):
                    fp = base / f
                    if fp.is_file() and f.endswith(".md"):
                        target_files.append(fp)
        for root in roots:
            if not root.is_dir():
                continue
            searched.append(str(root))
            for dp, dn, fn in os.walk(root):
                for f in fn:
                    if f.endswith(".md"):
                        target_files.append(Path(dp) / f)
        if base.is_dir():
            searched.append(str(base))

        for p in target_files:
            if not p.is_file():
                continue
            f = p.name
            # 索引页仅在明确指定 page_type=index 时才作为结果
            body = _read(p)
            fm = _parse_fm(body)
            ptype = fm.get("type", "")
            if ptype == "index" and params.page_type != "index":
                # 索引页仅用于定位，正文不算命中；标题含关键词时保留
                title = f
                if not match(title) and not match(str(p)):
                    continue
            if params.page_type and ptype and ptype != params.page_type:
                continue
            # ⚠️ 2026-10-24（P0-3）：全文匹配，不再只查前 600 字。
            # 正文读取不再截断——长页尾部的关键词同样必须能被检出。
            if params.match_mode == "title":
                head = body[:600]
                if not (match(head) or match(f) or match(fm.get("id", ""))):
                    continue
            else:
                if not (match(body) or match(f) or match(fm.get("id", ""))):
                    continue
            # P1-2：正式模式只保留满足发布条件的页面，其余登记排除原因
            from _knowledge_policy import usable_gate
            ok, reasons = (usable_gate(fm) if scope == "usable" else _publish_gate(fm, rel_path=_rel_path(p)))
            if official and not ok:
                excluded.append({
                    "path": str(p.relative_to(ROOT)).replace("\\", "/"),
                    "reasons": reasons,
                })
                continue
            results.append({
                "path": str(p.relative_to(ROOT)).replace("\\", "/"),
                "fm": fm, "body": body, "layer": layer,
                "name": DOMAINS.get(fm.get("domain", ""), fm.get("domain", "")),
                "hits": _hit_count(body, kw),
                "length": len(body),
                "publish_ok": ok,
                "publish_reasons": reasons,
            })

    # ---------- 兜底：raw ----------
    raw_hits = []
    # P1-2：正式模式默认**不回落 raw**——raw 是原始素材（未经发布流程），
    # 混入会让"正式结果"失去意义。仅当用户显式 layer="raw" 时才检索 raw。
    # official 模式下 raw 一律不检索（见变更3：official_layer_allowed 已拦截
    # layer="raw"，此处再兜底一层，防止后续改动引入绕过）
    raw_allowed = (not official)
    if raw_allowed and params.include_raw_fallback and (not results or layer == "raw"):
        # 以 raw/ 下**实际存在的**目录为准（而非 RAW_LAYERS 的键），
        # 避免新增目录漏遍历、或字典里写了不存在的目录名导致漏扫
        if layer == "raw":
            # 即使扫整个 raw/，也要让索引目录优先被遍历
            _prio = [RAW / d for d in sorted(os.listdir(RAW))
                     if d.endswith("索引") and (RAW / d).is_dir()]
            _rest = [RAW / d for d in sorted(os.listdir(RAW))
                     if not d.endswith("索引") and (RAW / d).is_dir()]
            raws = _prio + _rest
        else:
            _dirs = [d for d in sorted(os.listdir(RAW)) if (RAW / d).is_dir()]
            # 索引目录排在最前：它是"地图"，命中索引才能知道该打开哪些原文件，
            # 若排在后面会被前面几万份原始素材挤掉 max_results 名额。
            _prio = [d for d in _dirs if d.endswith("索引")]
            _rest = [d for d in _dirs if not d.endswith("索引")]
            raws = [RAW / d for d in (_prio + _rest)]
        for r in raws:
            if not r.is_dir():
                continue
            searched.append(str(r))
            for dp, dn, fn in os.walk(r):
                for f in fn:
                    ext = Path(f).suffix.lower()
                    if ext not in TEXT_EXT and ext not in DOC_EXT:
                        continue
                    p = Path(dp) / f
                    # 二进制（pdf/doc）不做内容匹配，仅按文件名匹配
                    if ext in DOC_EXT:
                        if not match(f) and not match(str(p)):
                            continue
                        raw_hits.append({
                            "path": str(p.relative_to(ROOT)).replace("\\", "/"),
                            "binary": True,
                        })
                        continue
                    body = _read(p)
                    # 全文匹配（不截断）：资料包索引等结构的条目可能位于文件后段，
                    # 截断匹配会漏掉（索引文件开头是说明文字，条目在后面的代码块内）
                    if not (match(body) or match(f) or match(str(p))):
                        continue
                    raw_hits.append({
                        "path": str(p.relative_to(ROOT)).replace("\\", "/"),
                        "binary": False,
                        "body": body,
                        "snip": _snippet(body, kw),
                        "hits": _hit_count(body, kw),
                        "length": len(body),
                    })
                    if len(raw_hits) >= max_results * 3:
                        break

    # ---------- 组装输出 ----------
    mode_name = "已发布可用知识（usable）" if scope == "usable" else "按类型核对的官方来源（official）" if official else "研究检索（research）"
    out = [f"# 自建知识库检索：{kw}", ""]
    out.append(f"**检索范围**：{mode_name}　|　**检索层**：{layer}　|　"
               f"**命中**：wiki/draft {len(results)} 条，raw {len(raw_hits)} 条"
               + (f"，因未满足发布条件被排除 {len(excluded)} 条" if official else ""))
    out.append("")
    if scope == "usable":
        out.append("> 已批准可用知识：保留适用范围和必要提示；不以排序、人工核验日期或非关键属性缺失阻断使用。实质问题、内容绑定失败和未批准页面不会返回。")
    elif official:
        out.append("> 官方来源过滤：法规核对版本与时点；已登记的官方案例核对发布身份、案例文本及缓存完整性，不要求原判决书。作者总结可在默认usable检索，其未进入官方来源过滤不属于发布失败。")
        out.append("> 下列结果**依据页面及外置证据判定核验资格**，"
                   "**不等于内容已逐页复核**；出具法律意见前仍须由执业律师核对原文。")
        out.append("> ⚠️ **review_status=已发布 仅表示 wiki 内部入库成功，"
                   "不代表已人工审核**。")
    else:
        out.append("> 🔬 **研究检索模式**：返回全部命中页面，**含未核验/待复核的草稿**，"
                   "仅供研究与线索定位，**不可直接作为对客法律意见的依据**。")
        out.append("> 需要满足正式检索条件的页面时，请改用 `scope=\"official\"` 重检。")
    out.append("> 法条现行有效性请以北大法宝 / 国家法律法规数据库的实时检索为准。")
    out.append("")

    if results:
        out.append("## wiki/draft 层结果（主路径）")
        out.append("")
        for i, r in enumerate(results[:max_results], 1):
            fm = r["fm"]
            st = fm.get("status", "")
            rv = fm.get("review_status", "")
            out.append(f"### {i}. {r['path']}")
            meta = []
            if fm.get("domain"):
                meta.append(f"领域：{DOMAINS.get(fm['domain'], r['name'])}")
            if fm.get("type"):
                meta.append(f"类型：{fm['type']}")
            if fm.get("jurisdiction"):
                meta.append(f"地域：{fm['jurisdiction']}")
            if fm.get("source_type"):
                meta.append(f"来源：{fm['source_type']}")
            if st:
                meta.append(f"效力：{st}")
            if rv:
                meta.append(f"入库：{rv}")
            if fm.get("last_verified"):
                meta.append(f"最后人工核验：{fm['last_verified']}")
            if fm.get("verified_at"):
                meta.append(f"自动核验时间：{fm['verified_at']}")
            if fm.get("verify_source"):
                meta.append(f"核验来源：{fm['verify_source']}")
            if fm.get("authority_level"):
                meta.append(f"参考优先级：{fm['authority_level']}")
            out.append("- " + "　|　".join(meta))
            if r.get("publish_ok"):
                out.append("- **发布状态**：✅ 满足本次检索范围的使用条件")
            else:
                out.append("- **发布状态**：⚠️ 未满足发布条件（仅研究参考）——"
                           + "；".join(r.get("publish_reasons") or []))
            if params.include_content:
                snip = _snippet(r["body"], kw)
                if snip:
                    out += ["", f"**命中片段**（全文命中 {r.get('hits', 0)} 处"
                                 f"，正文 {r.get('length', 0)} 字符）：", "",
                            "> " + snip.replace("\n", "\n> ")]
            w = _status_warning(fm)
            if w:
                out += [w]
            jn = _judge_note(fm)
            if jn:
                out += [jn]
            out.append("")

    if official and excluded and params.include_excluded:
        out.append("## 因未满足发布条件被排除的命中页面")
        out.append("")
        out.append("以下页面**命中了关键词但不满足正式发布条件**，故未列入上方正式结果。")
        out.append("在 `scope=\"research\"` 模式下这些页面会被返回。")
        out.append("")
        for e in excluded[:max_results * 2]:
            out.append(f"- `{e['path']}`")
            for rs in e["reasons"]:
                out.append(f"  - 排除原因：{rs}")
        if len(excluded) > max_results * 2:
            out.append(f"- ……另有 {len(excluded) - max_results * 2} 条未列出")
        out.append("")

    if raw_hits:
        out.append("## raw 层结果（原始素材 / 复核通道）")
        out.append("")
        out.append("来源层级：**裁判文书 / 实务分析 / 法条原文**（按所在目录判定）")
        out.append("")
        for h in raw_hits[:max_results]:
            layer_name = h["path"].split("/")[1] if "/" in h["path"] else ""
            desc, source = RAW_LAYERS.get(
                layer_name, ("原始素材（%s）" % layer_name if layer_name else "原始素材", "实务分析"))
            out.append(f"- `{h['path']}`")
            out.append(f"  - 类型：{desc}　|　来源层级：**{source}**")
            if h.get("binary"):
                out.append("  - ⚠️ **PDF/DOC 二进制文件**：本工具**不索引二进制正文**，"
                           "文本检索仅按文件名命中，内容需人工打开原文件查阅")
            elif h.get("snip"):
                out.append(f"  - 命中（{h.get('hits', 0)} 处）：" +
                           h["snip"][:200].replace("\n", " "))
                if h.get("length", 0) > 20000:
                    out.append(f"  - 正文长度 {h['length']} 字符（>20000，"
                               f"已按全文匹配）")
        out.append("")

    if not results and not raw_hits:
        out.append("## 本次未检出")
        out.append("")
        if official and excluded:
            out.append("**正式检索模式下未检出满足发布条件的页面。**")
            out.append("")
            out.append(f"有 {len(excluded)} 条页面命中了关键词，但因未满足发布条件被排除"
                       "（排除原因见下方清单）。")
            out.append("")
            out.append("⚠️ **这只表示「没有满足正式资格的页面」，"
                       "不代表库内不存在相关内容。**")
            out.append("")
        else:
            out.append("**本次未检出**与所检索关键词匹配的页面。")
            out.append("")
            out.append("⚠️ **这只是本次检索没有匹配结果，不代表库内一定不存在相关内容。**可能原因：")
            out.append("1. 该内容存在但关键词表述不同（可换用同义词、法条号、条号中文数字形式重试）；")
            out.append("2. 该内容位于本层之外的目录（如 `draft/`、`raw/`），可显式指定 `layer` 再检索；")
            out.append("3. 该内容为 PDF/DOC 等**二进制文件**，本工具**不索引其正文**，只能按文件名命中；")
            out.append("4. 该内容确实尚未进入本库。")
            out.append("")
        out.append("建议：")
        out.append("1. 若公开数据库有 → 改用外部 MCP（北大法宝 / 国家法律法规数据库）检索；")
        out.append("2. 若确属本地增量 → 建议补充到 `raw/` 对应目录后重新编译。")
        if official:
            out.append("3. 若只是做线索定位 → 改用 `scope=\"research\"` 检索，"
                       "可看到未过审核但内容相关的草稿页面。")
        out.append("")
        out.append("**严禁编造检索结果。**")

    out += ["", "---", "", "**已扫描路径**：", ""]
    for s in searched[:12]:
        out.append(f"- `{s}`")
    return "\n".join(out)


@mcp.tool(
    name="kb_read_page",
    annotations={"title": "读取指定知识库页面全文（支持分页）",
                 "readOnlyHint": True, "destructiveHint": False,
                 "idempotentHint": True, "openWorldHint": False},
)
async def kb_read_page(params: ReadPageInput) -> str:
    """读取知识库中指定页面的正文（**完整正文，可分页续读**）。

    用于 kb_search 命中后深入阅读原文，或用户直接指定页面。
    路径为相对知识库根目录，如 `wiki/01-labor/terms/末位淘汰.md`。

    ⚠️ 2026-10-24（P0-3）行为变更：
      - 旧版只返回前 20000 字却自称"全文"——**已修正**。
      - 现在默认读取**完整正文**；正文过长时按 `limit` 分页，返回
        `total_length` / `offset` / `next_offset` / `has_more` / `truncated`，
        **边界不丢不重**（续读时把 `offset` 设为上次返回的 `next_offset`）。
      - 旧调用方（只传 path）**完全兼容**，且现在拿到的是完整正文。

    Args:
        params: 页面相对路径 + 可选的 offset/limit。

    Returns:
        Markdown 格式的页面正文 + 分页信息 + 元数据 + 效力状态提示。

        ⚠️ 2026-10-25（KB-20261024-001 / v2 补正 R03）：
          body_only=True 时返回**严格 JSON**，其中除原始 body 与完整分页信息外，
          **另含结构化的资格字段**（publish_ok / publish_status /
          publish_reasons / effect_status / review_status / verify_source /
          last_verified / version_note）——旧实现提前 return 导致这些状态
          在机器输出里整体消失。
    """
    p = Path(params.path.strip().strip("`\"'"))
    if p.is_absolute():
        try:
            p = p.relative_to(ROOT)
        except ValueError:
            return f"❌ 越权：仅允许读取 `{ROOT}` 内的文件。"
    target = ROOT / p
    try:
        target.resolve().relative_to(ROOT.resolve())
    except ValueError:
        return f"❌ 越权：目标路径超出知识库根目录 `{ROOT}`。"
    if not target.is_file():
        return (f"❌ 文件不存在：`{params.path}`\n\n"
                "**说明**：本次未检出该路径的文件（不代表内容不存在于库内其他路径）。"
                "建议先调用 `kb_search` 或 `kb_overview` 定位页面。")

    full = _read(target)          # 全文，不截断
    fm = _parse_fm(full)
    body = FM_RE.sub("", full, count=1)   # 去 frontmatter 后的正文
    body = body.lstrip("\n")

    total = len(body)
    off = max(0, int(params.offset or 0))
    if off > total:
        off = total
    lim = int(params.limit or 0)
    if lim > 0:
        chunk = body[off:off + lim]
    else:
        chunk = body[off:]
    has_more = (off + len(chunk)) < total
    next_offset = off + len(chunk)

    # ⚠️ 2026-10-25（KB-20261024-001 / v2 补正 R03）：**统一状态计算**。
    # 旧实现把 body_only 的 JSON 返回放在状态判定**之前**（提前 return），
    # 于是 body_only=True 时「草稿审核 / 效力状态 / 发布资格」提示全部消失，
    # 调用方无从判断该页能否引用（Codex 复核 v1 判为重大缺陷 R03）。
    # 现改为：先算状态（机器输出与 Markdown 输出**共用同一份**结果），
    # 再按输出形态分流——**body 逐字符不变**，分页重组不受任何影响。
    def _scalar(k):
        v = fm.get(k)
        if v is None or isinstance(v, (dict, list)):
            return ""
        return str(v).strip()

    from _knowledge_policy import usable_gate
    usable_ok, usable_reasons = usable_gate(fm)
    effect_status = _scalar("status")
    review_status = _scalar("review_status")
    verify_source = _scalar("verify_source")
    last_verified = _scalar("last_verified")
    verified_at = _scalar("verified_at")
    authority_level = _scalar("authority_level")

    # 发布资格判定：优先用模块级 _publish_gate（正式判定口径唯一真源）；
    # 独立执行场景（隔离 exec / 单函数测试）下从库根 _scripts 现场载入。
    gate = globals().get("_publish_gate")
    publish_ok = False
    publish_reasons = []
    # 隔离执行路径（现场载入的模块）也须使用同一份旧记录清单，
    # 否则隔离执行会把存量页误判为「新记录」→ 误阻断（口径分裂）
    _gate_legacy = _legacy_paths()
    if gate is None:
        try:
            import importlib.util as _ilu
            _root = Path(globals().get("ROOT", "."))
            _gp = str(_root / "_scripts" / "_publish_gate.py")
            _spec = _ilu.spec_from_file_location("_publish_gate_iso", _gp)
            _mod = _ilu.module_from_spec(_spec)
            _spec.loader.exec_module(_mod)
            gate = _mod.publish_gate
        except Exception as exc:
            publish_reasons = ["无法载入发布资格判定模块（_publish_gate）："
                               "%s: %s" % (type(exc).__name__, exc)]
    if gate is not None:
        try:
            publish_ok, publish_reasons = gate(fm, rel_path=_rel_path(target),
                                               legacy_paths=_gate_legacy)
        except TypeError:
            # 兼容旧签名（不接受 rel_path / legacy_paths）
            publish_ok, publish_reasons = gate(fm)
        except Exception as exc:
            publish_ok = False
            publish_reasons = ["发布资格判定执行异常：%s: %s"
                               % (type(exc).__name__, exc)]

    # 版本与效力说明（研究范围标注历史法时使用）
    _vnote_fn = globals().get("research_version_note")
    version_note = ""
    if _vnote_fn is not None:
        try:
            version_note = _vnote_fn(fm)
        except Exception:
            version_note = ""
    if not version_note:
        _bits = []
        if effect_status:
            _bits.append("效力状态：%s" % effect_status)
        if verify_source:
            _bits.append("核验来源：%s" % verify_source)
        version_note = "；".join(_bits)

    # ⚠️ 2026-10-24（KB-20261024-001 / B03）：机器可解析输出。
    # body 字段是**本次实际返回**的正文 chunk——不做任何重建，
    # 供分页重组验收脚本逐页拼接后与完整原文逐字符比对。
    # ⚠️ v2/R03：JSON 现在**同时**带结构化的审核状态 / 效力状态 /
    #    publish_ok / 排除原因 / 版本说明，且**不受 include_meta 影响**。
    if params.body_only:
        import json as _json
        return _json.dumps({
            "path": _rel_path(target),
            "offset": off,
            "returned_length": len(chunk),
            "total_length": total,
            "has_more": has_more,
            "next_offset": next_offset,
            "truncated": has_more,
            "body": chunk,
            "usable": bool(usable_ok),
            "publication_status": fm.get('publish_status', '可用' if usable_ok else '草稿'),
            "source_verified": bool(publish_ok),
            "publish_ok_semantics": "官方来源核验资格；作者是否已发布请看usable与publication_status，不以publish_ok=false认定发布失败",
            "usage_reasons": list(usable_reasons),
            "publish_ok": bool(publish_ok),
            "publish_status": "qualified" if publish_ok else "excluded",
            "publish_reasons": list(publish_reasons),
            "effect_status": effect_status,
            "review_status": review_status,
            "verify_source": verify_source,
            "last_verified": last_verified,
            "verified_at": verified_at,
            "authority_level": authority_level,
            "verification_method": ("官方案例发布身份与文本核对" if verify_source == "官方案例发布文本" else "人工核验" if verify_source == "人工核验"
                                    else ("自动核验" if verify_source in PUBLISH_VERIFY_AUTO
                                          else ("未核验" if verify_source else "缺失"))),
            "review_semantics": ("已发布＝wiki 内部入库成功，不代表已人工审核"
                                 if review_status == "已发布"
                                 else ("已审核＝确经人工审核"
                                       if review_status == "已审核"
                                       else "未入库正式库")),
            "version_note": version_note,
        }, ensure_ascii=False)

    out = [f"# {target.name}", ""]

    # ---- 分页信息（始终返回，便于调用方判断是否需要续读）----
    out.append("## 读取信息")
    out.append("")
    out.append(f"- **正文字符数（total_length）**：{total}")
    out.append(f"- **本次起始偏移（offset）**：{off}")
    out.append(f"- **本次返回字符数**：{len(chunk)}")
    out.append(f"- **是否还有内容（has_more）**：{'是' if has_more else '否'}")
    out.append(f"- **是否被截断（truncated）**：{'是' if has_more else '否'}")
    if has_more:
        out.append(f"- **续读游标（next_offset）**：{next_offset}"
                   f"　→ 再次调用本工具并传入 `offset={next_offset}` 即可无缝续读")
    out.append(f"- **完整文件字符数（含 frontmatter）**：{len(full)}")
    out.append("")

    # ⚠️ 2026-10-24（KB-20261024-001 / B02）：**效力状态与发布资格提示必须保留**。
    # 旧实现把提示块整体包在 `if params.include_meta and fm:` 内，
    # 调用方传 include_meta=False 时提示整段消失——读者无从判断该页
    # 是否现行有效、是否具备引用资格。现改为：元数据可关，提示不可关。
    if params.include_meta and fm:
        out.append("## 元数据")
        out.append("")
        for k in ("id", "type", "domain", "jurisdiction", "status",
                  "authority_level", "review_status", "source_type",
                  "last_verified", "verified_at", "verify_source"):
            if k in fm:
                label = {"domain": "领域"}.get(k, k)
                val = DOMAINS.get(fm[k], fm[k]) if k == "domain" else fm[k]
                out.append(f"- **{label}**：{val}")
        out.append("")
        out.append("---")
        out.append("")

    # ---- 状态提示（始终输出，不受 include_meta 影响）----
    w = _status_warning(fm)
    if w:
        out += [w, ""]
    jn = _judge_note(fm)
    if jn:
        out += [jn, ""]
    if version_note:
        out.append("> 📌 **版本与效力说明**：" + version_note)
        out.append("")
    # P1-2 / B02：发布资格状态（与 kb_search 的 official 模式判定口径一致）
    # ⚠️ v2/R03：此处使用与机器输出**完全相同**的那一份判定结果，
    #    保证「机器输出」与「Markdown 输出」两条路径的状态结论一致。
    out.append("> - **作者发布 / 默认检索（usable）**：%s" % ('已发布，可默认检索' if usable_ok else '未放行：'+'；'.join(usable_reasons)))
    out.append("> - **官方来源核验资格（publish_ok，兼容字段）**：%s"
               % ("是" if publish_ok else "未满足本过滤器；已发布的作者总结仍可默认检索" if usable_ok else "否"))
    out.append("> - **效力状态（effect_status）**：%s" % (effect_status or "缺失"))
    out.append("> - **入库状态（review_status）**：%s" % (review_status or "缺失"))
    out.append("> - **参考优先级（authority_level）**：%s" % (authority_level or "缺失"))
    out.append("> - **核验来源（verify_source）**：%s" % (verify_source or "缺失"))
    out.append("> - **人工核验日期（last_verified）**：%s" % (last_verified or "无（无人工核验）"))
    out.append("> - **自动核验时间（verified_at）**：%s" % (verified_at or "无（未执行自动核验）"))
    out.append("> - **入库语义**：%s"
               % ("已发布＝wiki 内部入库成功，**不代表已人工审核**"
                  if review_status == "已发布"
                  else ("已审核＝确经人工审核" if review_status == "已审核"
                        else "未入库正式库，仅供研究参考")))
    if publish_ok:
        out.append("> - **判定依据**：先检查作者批准、当前版本与实质问题，再按来源类型核对法规证据或官方案例发布身份及文本完整性。")
        out.append("> - 资格依据页面、作者批准与外置来源证据判定；官方案例不额外要求原判决书，作者总结可默认检索；不等于逐句人工实核。")
    else:
        out.append("> - **排除原因（publish_reasons）**：")
        for rs in publish_reasons:
            out.append(">   - " + rs)
    out.append("")

    out.append("> 可用知识状态：" + ("可用" if usable_ok else "未放行：" + "；".join(usable_reasons)))
    out.append(chunk)
    return "\n".join(out)


def main():
    async def _run():
        if sys.stdin.isatty():
            await mcp.run_streamable_http_async()   # 手动终端 → http:18080
        else:
            await mcp.run_stdio_async()               # MCP 客户端 → stdio
    asyncio.run(_run())


if __name__ == "__main__":
    main()
