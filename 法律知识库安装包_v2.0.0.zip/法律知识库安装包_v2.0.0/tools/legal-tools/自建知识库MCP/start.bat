@echo off
cd /d "%~dp0"
".venv\Scripts\python.exe" -B "scripts\run_http.py"
