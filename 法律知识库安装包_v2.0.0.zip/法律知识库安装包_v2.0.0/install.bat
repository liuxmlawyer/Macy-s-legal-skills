@echo off
REM ============================================================
REM  Legal Knowledge Base v2.0.0 - Installer
REM  Usage: double-click this file, or run install.bat
REM  Default target: %USERPROFILE%\LegalKB
REM  NOTE: this file is intentionally pure ASCII so that
REM        cmd.exe on Chinese Windows cannot garble it.
REM ============================================================
setlocal

set "PKG_DIR=%~dp0"
set "TARGET=%USERPROFILE%\LegalKB"

echo ============================================================
echo   Legal Knowledge Base v2.0.0 - Installer
echo ============================================================
echo.

where python >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Python not found in PATH.
    echo         Install Python 3.10-3.13 from:
    echo         https://www.python.org/downloads/windows/
    echo         Remember to check "Add python.exe to PATH".
    echo.
    pause
    exit /b 1
)

python -c "import sys; raise SystemExit(0 if (3,10)<=sys.version_info[:2]<(3,14) else 1)"
if errorlevel 1 (
    echo [ERROR] Unsupported Python version. Need 3.10 - 3.13.
    python --version
    pause
    exit /b 1
)

echo Target directory: %TARGET%
echo.
echo Press Enter to continue, or Ctrl+C to cancel.
pause >nul

python "%PKG_DIR%scripts\install.py" --kb-root "%TARGET%"
if errorlevel 1 (
    echo.
    echo [FAILED] Installation did not complete. See messages above.
    pause
    exit /b 1
)

echo.
echo ============================================================
echo   Files and dependencies installed.
echo.
echo   Next steps:
echo     1. Open the KB ROOT folder in Obsidian (not a subfolder).
echo     2. Copy .obsidian\plugins\kb-property-choices into your
echo        vault and enable it in the installed-plugins list.
echo     3. Import config\mcp.json into your AI client, click
echo        Trust, then reopen the session.
echo     4. Create a test page with a unique marker and run one
echo        real search to verify the whole chain.
echo ============================================================
pause
endlocal
