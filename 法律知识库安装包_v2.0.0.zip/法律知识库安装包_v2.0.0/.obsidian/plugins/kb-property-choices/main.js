"use strict";
var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};

// .obsidian/plugins/kb-property-choices/policy.js
var require_policy = __commonJS({
  ".obsidian/plugins/kb-property-choices/policy.js"(exports2, module2) {
    "use strict";
    var crypto = require("crypto");
    var CORE = ["id", "type", "domain", "jurisdiction", "source_type", "sources", "citations", "publish_status"];
    var OPTIONAL = ["status", "effective_on", "doc_no", "case_no", "court", "judgment_date", "case_effect", "manual_overrides"];
    function canonical(x) {
      if (x instanceof Date) return JSON.stringify(x.toISOString().slice(0, 10));
      if (Array.isArray(x)) return "[" + x.map(canonical).join(", ") + "]";
      if (x && typeof x === "object") return "{" + Object.keys(x).sort().map((k) => JSON.stringify(k) + ": " + canonical(x[k])).join(", ") + "}";
      return JSON.stringify(x === void 0 ? null : x);
    }
    function semanticHash(d, body) {
      const props = {};
      for (const k of [...CORE, ...OPTIONAL]) if (!["publish_status", "manual_overrides"].includes(k)) props[k] = d[k] === void 0 ? null : d[k];
      const nav = /^\s*(?:-\s*)?(?:(?:引用|补充|关联|适用|区别)：\s*)?\[\[[^\]]+\]\](?:\s*[·•]\s*\[\[[^\]]+\]\])*\s*$/;
      const lines = body.split(/\r?\n/).filter((l) => !nav.test(l)).map((l) => l.trim()).filter(Boolean);
      return crypto.createHash("sha256").update(canonical([props, lines]), "utf8").digest("hex");
    }
    function validateChanges2(schema, current, changes, record) {
      const clean = {};
      for (const [k, v] of Object.entries(changes)) {
        const def = schema.fields[k];
        if (!def) throw Error("\u8BE5\u5B57\u6BB5\u7531\u7CFB\u7EDF\u6216\u539F\u6587\u7BA1\u7406\uFF1A" + k);
        if (v === "" && !def.optional) throw Error("\u5FC5\u9700\u5B57\u6BB5\u4E0D\u80FD\u6E05\u7A7A\uFF1A" + k);
        if (v !== "" && !def.options.includes(v)) throw Error("\u4E0D\u5728\u5141\u8BB8\u9009\u9879\u4E2D\uFF1A" + k);
        if (k === "publish_status" && v === "\u53EF\u7528" && record.issues?.length) throw Error("\u5B58\u5728\u5B9E\u8D28\u95EE\u9898\uFF1A" + record.issues.join("\uFF1B"));
        if ((current[k] ?? "") !== v) clean[k] = v;
      }
      return clean;
    }
    function reviseRecord2(record, before, after, body, changes, now, action = "save") {
      const next = JSON.parse(JSON.stringify(record));
      next.property_edits = next.property_edits || [];
      const hash = semanticHash(after, body), publish = action === "publish" || changes.publish_status === "\u53EF\u7528";
      next.property_edits.push({ at: now, changes, previous_approval: next.approval || null, note: "\u7528\u6237\u64CD\u4F5C\uFF1B\u53D1\u5E03\u6279\u51C6\u4E0E\u6765\u6E90\u6838\u9A8C\u5206\u5F00" });
      if (publish) {
        if (next.issues?.length) throw Error("\u5B58\u5728\u5B9E\u8D28\u95EE\u9898\uFF1A" + next.issues.join("\uFF1B"));
        if (next.approval) {
          next.approval_history = next.approval_history || [];
          next.approval_history.push(next.approval);
        }
        next.approval = { kind: "author_publication", basis: "\u4F5C\u8005\u5728Obsidian\u9009\u62E9\u53D1\u5E03/\u4FDD\u5B58\u5E76\u53D1\u5E03", recorded_on: now, content_hash: hash, not_a_new_human_verification: true };
        after.publish_status = "\u53EF\u7528";
        next.publication_history = next.publication_history || [];
        next.publication_history.push({ at: now, action: "publish", basis: next.approval.basis });
        if (after.type === "topic" && !next.official_publications?.length) next.usage_class = "author_summary";
      } else if (changes.publish_status === "\u505C\u7528" || changes.publish_status === "\u8349\u7A3F") {
        if (next.approval) {
          next.approval_history = next.approval_history || [];
          next.approval_history.push(next.approval);
        }
        next.approval = null;
      } else if (hash !== record.content_hash) {
        after.publish_status = "\u8349\u7A3F";
        next.unrecorded_status_intent = { observed: before.publish_status, reason: "\u5F53\u524D\u4FEE\u6539\u5C1A\u672A\u53D1\u5E03\uFF1B\u4FDD\u5B58\u5E76\u53D1\u5E03\u53EF\u786E\u8BA4\u65B0\u7248\uFF0C\u65E7\u6279\u51C6\u4FDD\u7559\u4F9B\u8FFD\u6EAF" };
      }
      next.content_hash = hash;
      return next;
    }
    function matchFrontmatter2(text) {
      return text.match(/^---[ \t]*\r?\n([\s\S]*?)\r?\n---(?:\r?\n|$)/);
    }
    module2.exports = { semanticHash, validateChanges: validateChanges2, reviseRecord: reviseRecord2, matchFrontmatter: matchFrontmatter2 };
  }
});

// .obsidian/plugins/kb-property-choices/transaction.js
var require_transaction = __commonJS({
  ".obsidian/plugins/kb-property-choices/transaction.js"(exports2, module2) {
    "use strict";
    var fs2 = require("fs");
    var path2 = require("path");
    var crypto = require("crypto");
    function atomic(file, bytes) {
      const temp = file + "." + crypto.randomUUID() + ".pending";
      try {
        fs2.writeFileSync(temp, bytes, { flag: "wx" });
        fs2.renameSync(temp, file);
      } finally {
        if (fs2.existsSync(temp)) fs2.unlinkSync(temp);
      }
    }
    function within(base, file) {
      const rel = path2.relative(base, file);
      return rel !== "" && !rel.startsWith(".." + path2.sep) && rel !== ".." && !path2.isAbsolute(rel);
    }
    function commitPair2(root, rel, oldNote, oldRecord, newNote, record) {
      const base = fs2.realpathSync(root), file = fs2.realpathSync(path2.join(base, rel));
      if (!within(path2.join(base, "wiki"), file) || !/^[-\w]+$/.test(record.id)) throw Error("\u4EC5\u5141\u8BB8wiki\u4E2D\u7684\u6709\u6548\u77E5\u8BC6\u9875");
      if (record.path !== rel.replace(/\\/g, "/")) throw Error("\u8BB0\u5F55\u8DEF\u5F84\u4E0D\u7B26");
      const rp = path2.join(base, "_meta", "pages", record.id + ".json");
      const lockDir = path2.join(base, "_meta", "publish-locks");
      fs2.mkdirSync(lockDir, { recursive: true });
      const lock = path2.join(lockDir, record.id + ".lock");
      let fd;
      try {
        fd = fs2.openSync(lock, "wx");
        fs2.writeSync(fd, String(process.pid));
      } catch (e) {
        throw Error("\u672C\u9875\u6B63\u5728\u5199\u5165\u6216\u6709\u5F85\u6062\u590D\u4E8B\u52A1\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5");
      }
      const tx = path2.join(base, "_meta", "transactions", crypto.randomUUID());
      const next = Buffer.from(JSON.stringify(record, null, 2) + "\n", "utf8");
      const equal = (file2, bytes) => fs2.readFileSync(file2).equals(bytes);
      let started = false;
      const log = (state) => atomic(path2.join(tx, "journal.json"), Buffer.from(JSON.stringify({ id: record.id, path: rel, state })));
      try {
        if (!equal(file, oldNote) || !equal(rp, oldRecord)) throw Error("\u9875\u9762\u6216\u8BB0\u5F55\u5E76\u53D1\u53D8\u5316\uFF0C\u8BF7\u91CD\u65B0\u6253\u5F00\u540E\u53D1\u5E03");
        fs2.mkdirSync(tx, { recursive: true });
        for (const [name, bytes] of [["note.before", oldNote], ["record.before", oldRecord], ["note.after", newNote], ["record.after", next]]) fs2.writeFileSync(path2.join(tx, name), bytes, { flag: "wx" });
        log("prepared");
        started = true;
        atomic(file, newNote);
        if (!equal(file, newNote) || !equal(rp, oldRecord)) throw Error("\u5199\u5165\u671F\u95F4\u6587\u4EF6\u53D8\u5316");
        atomic(rp, next);
        if (!equal(file, newNote) || !equal(rp, next)) throw Error("\u5199\u540E\u5E76\u53D1\u53D8\u5316");
        log("committed");
        return tx;
      } catch (e) {
        if (started) {
          if (equal(file, newNote)) atomic(file, oldNote);
          if (equal(rp, next)) atomic(rp, oldRecord);
          log(equal(file, oldNote) && equal(rp, oldRecord) ? "rolled_back" : "conflict_preserved");
        }
        throw e;
      } finally {
        fs2.closeSync(fd);
        fs2.unlinkSync(lock);
      }
    }
    module2.exports = { commitPair: commitPair2, atomic };
  }
});

// .obsidian/plugins/kb-property-choices/main.source.js
var { Plugin, Modal, Setting, Notice, parseYaml, stringifyYaml } = require("obsidian");
var fs = require("fs");
var path = require("path");
var { validateChanges, reviseRecord, matchFrontmatter } = require_policy();
var { commitPair } = require_transaction();
var PropertiesModal = class extends Modal {
  constructor(app, file, schema) {
    super(app);
    this.file = file;
    this.schema = schema;
    this.changes = {};
  }
  async onOpen() {
    const el = this.contentEl;
    el.createEl("h2", { text: "\u77E5\u8BC6\u9875\u5C5E\u6027\u4E0E\u53D1\u5E03" });
    this.root = this.app.vault.adapter.getBasePath();
    this.originalBytes = fs.readFileSync(path.join(this.root, this.file.path));
    const text = this.originalBytes.toString("utf8").replace(/^\uFEFF/, "");
    this.original = text;
    const m = matchFrontmatter(text);
    if (!m) {
      el.createEl("p", { text: "\u8BE5\u7B14\u8BB0\u6CA1\u6709\u77E5\u8BC6\u9875\u5C5E\u6027\u3002" });
      return;
    }
    this.current = parseYaml(m[1]);
    const d = this.current;
    if (!/^[\w-]+$/.test(d.id || "")) {
      el.createEl("p", { text: "\u7F3A\u5C11\u6709\u6548ID\uFF0C\u8BF7\u5148\u8FD0\u884C\u81EA\u52A8\u7F16\u8BD1\u3002" });
      return;
    }
    this.recordPath = `_meta/pages/${d.id}.json`;
    try {
      this.recordBytes = fs.readFileSync(path.join(this.root, this.recordPath));
      this.record = JSON.parse(this.recordBytes.toString("utf8"));
    } catch (e) {
      el.createEl("p", { text: "\u7F3A\u5C11\u5916\u7F6E\u8BB0\u5F55\uFF0C\u8BF7\u5148\u8FD0\u884C\u81EA\u52A8\u7F16\u8BD1\u3002" });
      return;
    }
    el.createEl("p", { text: `ID\uFF1A${d.id}\u3000\u9886\u57DF\uFF1A${d.domain}\uFF08\u81EA\u52A8\u7BA1\u7406\uFF09` });
    el.createEl("p", { text: "\u9009\u62E9\u53EF\u7528\u6216\u70B9\u51FB\u4FDD\u5B58\u5E76\u53D1\u5E03\uFF0C\u5373\u8BB0\u5F55\u4F60\u7684\u6279\u51C6\u5E76\u5141\u8BB8\u9ED8\u8BA4\u68C0\u7D22\u3002\u5B98\u65B9\u6848\u4F8B\u65E0\u9700\u53E6\u627E\u5224\u51B3\u4E66\uFF1B\u4E2A\u4EBA\u603B\u7ED3\u4E0D\u8981\u6C42\u5B98\u65B9\u6765\u6E90\u6216\u6838\u9A8C\u65E5\u671F\u3002" });
    if (this.record.issues?.length) el.createEl("p", { text: "\u672C\u9875\u5F85\u89E3\u51B3\u95EE\u9898\uFF1A" + this.record.issues.join("\uFF1B") });
    for (const [key, def] of Object.entries(this.schema.fields)) {
      if (key === "status" && d.source_type === "\u5B9E\u52A1\u5206\u6790") continue;
      if (key === "case_effect" && d.type !== "case") continue;
      const setting = new Setting(el).setName(def.label).setDesc(def.hint || key);
      setting.addDropdown((drop) => {
        if (def.optional) drop.addOption("", "\u4E0D\u586B\u5199 / \u4E0D\u9002\u7528");
        const options = [...def.options];
        if (d[key] && !options.includes(String(d[key]))) options.unshift(String(d[key]));
        for (const val of options) drop.addOption(val, val === "\u53EF\u7528" ? "\u53EF\u7528\uFF08\u4FDD\u5B58\u5373\u53D1\u5E03\uFF09" : val);
        drop.setValue(String(d[key] ?? ""));
        drop.onChange((value) => {
          this.changes[key] = value;
        });
      });
    }
    el.createEl("p", { text: "\u6848\u53F7\u3001\u6CD5\u9662\u3001\u6587\u53F7\u53CA\u65E5\u671F\u65E0\u9700\u4E3A\u51D1\u9F50\u800C\u586B\u5199\uFF1B\u7CFB\u7EDF\u53EF\u786E\u5B9A\u7684\u4F1A\u9884\u586B\u3002\u4E0D\u80FD\u786E\u5B9A\u7684\u53EF\u4EE5\u7559\u7A7A\u3002" });
    new Setting(el).addButton((b) => b.setButtonText("\u4FDD\u5B58\u5E76\u53D1\u5E03 / \u5141\u8BB8\u68C0\u7D22").setCta().onClick(() => this.save("publish"))).addButton((b) => b.setButtonText("\u4EC5\u4FDD\u5B58\u5C5E\u6027").onClick(() => this.save("save"))).addButton((b) => b.setButtonText("\u53D6\u6D88").onClick(() => this.close()));
  }
  async save(action = "save") {
    try {
      const changes = validateChanges(this.schema, this.current, this.changes, this.record);
      if (!Object.keys(changes).length && action !== "publish") {
        this.close();
        return;
      }
      const m = matchFrontmatter(this.original), after = { ...this.current };
      for (const [k, v] of Object.entries(changes)) {
        if (v === "") delete after[k];
        else after[k] = v;
      }
      const body = this.original.slice(m[0].length);
      const rec = reviseRecord(this.record, this.current, after, body, changes, (/* @__PURE__ */ new Date()).toISOString(), action);
      for (const field of ["id", "type", "domain", "jurisdiction", "source_type", "sources", "citations", "publish_status"]) if (!(field in after)) throw Error("\u7F3A\u57FA\u7840\u5C5E\u6027\uFF1A" + field);
      if (rec.id !== after.id) throw Error("\u8BB0\u5F55ID\u4E0D\u7B26");
      const text = "---\n" + stringifyYaml(after).trimEnd() + "\n---\n" + body;
      commitPair(this.root, this.file.path, this.originalBytes, this.recordBytes, Buffer.from(text, "utf8"), rec);
      new Notice(after.publish_status === "\u53EF\u7528" ? "\u53D1\u5E03\u6210\u529F\uFF1A\u5DF2\u8BB0\u5F55\u4F5C\u8005\u6279\u51C6\uFF0C\u5141\u8BB8\u9ED8\u8BA4\u68C0\u7D22\u3002" : "\u5C5E\u6027\u5DF2\u4FDD\u5B58\uFF1A" + after.publish_status);
      this.close();
    } catch (e) {
      new Notice("\u672A\u5B8C\u6210\uFF1A" + e.message, 1e4);
    }
  }
  onClose() {
    this.contentEl.empty();
  }
};
module.exports = class extends Plugin {
  async onload() {
    const open = async () => {
      const file = this.app.workspace.getActiveFile();
      if (!file || !file.path.startsWith("wiki/") || file.extension !== "md") {
        new Notice("\u8BF7\u5148\u6253\u5F00wiki\u4E2D\u7684\u77E5\u8BC6\u9875");
        return;
      }
      try {
        const schema = JSON.parse(await this.app.vault.adapter.read("_meta/property-options.json"));
        new PropertiesModal(this.app, file, schema).open();
      } catch (e) {
        new Notice("\u5C5E\u6027\u9009\u9879\u672A\u52A0\u8F7D\uFF1A" + e.message);
      }
    };
    this.addCommand({ id: "choose-note-properties", name: "\u5C5E\u6027\u4E0E\u53D1\u5E03\uFF1A\u4FDD\u5B58\u5E76\u53D1\u5E03 / \u5141\u8BB8\u68C0\u7D22", callback: open });
    this.addRibbonIcon("list-filter", "\u77E5\u8BC6\u9875\u5C5E\u6027\u4E0E\u53D1\u5E03", open);
    this.registerEvent(this.app.workspace.on("file-menu", (menu, file) => {
      if (file.path.startsWith("wiki/") && file.extension === "md") menu.addItem((item) => item.setTitle("\u9009\u62E9\u77E5\u8BC6\u9875\u5C5E\u6027").setIcon("list-filter").onClick(async () => {
        const schema = JSON.parse(await this.app.vault.adapter.read("_meta/property-options.json"));
        new PropertiesModal(this.app, file, schema).open();
      }));
    }));
  }
};
