'use strict';
const fs=require('fs'),path=require('path'),crypto=require('crypto');
function atomic(file,bytes){const temp=file+'.'+crypto.randomUUID()+'.pending';try{fs.writeFileSync(temp,bytes,{flag:'wx'});fs.renameSync(temp,file);}finally{if(fs.existsSync(temp))fs.unlinkSync(temp);}}
function within(base,file){const rel=path.relative(base,file);return rel!==''&&!rel.startsWith('..'+path.sep)&&rel!=='..'&&!path.isAbsolute(rel);}
function commitPair(root,rel,oldNote,oldRecord,newNote,record){
 const base=fs.realpathSync(root),file=fs.realpathSync(path.join(base,rel));
 if(!within(path.join(base,'wiki'),file)||!/^[-\w]+$/.test(record.id))throw Error('仅允许wiki中的有效知识页');
 if(record.path!==rel.replace(/\\/g,'/'))throw Error('记录路径不符');
 const rp=path.join(base,'_meta','pages',record.id+'.json');
 const lockDir=path.join(base,'_meta','publish-locks');fs.mkdirSync(lockDir,{recursive:true});
 const lock=path.join(lockDir,record.id+'.lock');let fd;
 try{fd=fs.openSync(lock,'wx');fs.writeSync(fd,String(process.pid));}catch(e){throw Error('本页正在写入或有待恢复事务，请稍后重试');}
 const tx=path.join(base,'_meta','transactions',crypto.randomUUID());
 const next=Buffer.from(JSON.stringify(record,null,2)+'\n','utf8');
 const equal=(file,bytes)=>fs.readFileSync(file).equals(bytes);
 let started=false;
 const log=state=>atomic(path.join(tx,'journal.json'),Buffer.from(JSON.stringify({id:record.id,path:rel,state})));
 try{
  if(!equal(file,oldNote)||!equal(rp,oldRecord))throw Error('页面或记录并发变化，请重新打开后发布');
  fs.mkdirSync(tx,{recursive:true});
  for(const [name,bytes] of [['note.before',oldNote],['record.before',oldRecord],['note.after',newNote],['record.after',next]])fs.writeFileSync(path.join(tx,name),bytes,{flag:'wx'});
  log('prepared');started=true;atomic(file,newNote);
  if(!equal(file,newNote)||!equal(rp,oldRecord))throw Error('写入期间文件变化');
  atomic(rp,next);
  if(!equal(file,newNote)||!equal(rp,next))throw Error('写后并发变化');
  log('committed');return tx;
 }catch(e){
  if(started){if(equal(file,newNote))atomic(file,oldNote);if(equal(rp,next))atomic(rp,oldRecord);log(equal(file,oldNote)&&equal(rp,oldRecord)?'rolled_back':'conflict_preserved');}
  throw e;
 }finally{fs.closeSync(fd);fs.unlinkSync(lock);}
}
module.exports={commitPair,atomic};
