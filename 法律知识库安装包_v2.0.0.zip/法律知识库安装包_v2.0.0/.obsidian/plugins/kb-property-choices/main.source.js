'use strict';
const {Plugin,Modal,Setting,Notice,parseYaml,stringifyYaml}=require('obsidian');
const fs=require('fs'),path=require('path');
const {validateChanges,reviseRecord,matchFrontmatter}=require('./policy');
const {commitPair}=require('./transaction');
class PropertiesModal extends Modal {
 constructor(app,file,schema){super(app);this.file=file;this.schema=schema;this.changes={};}
 async onOpen(){
  const el=this.contentEl;el.createEl('h2',{text:'知识页属性与发布'});
  this.root=this.app.vault.adapter.getBasePath();
  this.originalBytes=fs.readFileSync(path.join(this.root,this.file.path));
  const text=this.originalBytes.toString('utf8').replace(/^\uFEFF/,'');this.original=text;
  const m=matchFrontmatter(text);if(!m){el.createEl('p',{text:'该笔记没有知识页属性。'});return;}
  this.current=parseYaml(m[1]);const d=this.current;
  if(!/^[\w-]+$/.test(d.id||'')){el.createEl('p',{text:'缺少有效ID，请先运行自动编译。'});return;}
  this.recordPath=`_meta/pages/${d.id}.json`;
  try{this.recordBytes=fs.readFileSync(path.join(this.root,this.recordPath));this.record=JSON.parse(this.recordBytes.toString('utf8'));}catch(e){el.createEl('p',{text:'缺少外置记录，请先运行自动编译。'});return;}
  el.createEl('p',{text:`ID：${d.id}　领域：${d.domain}（自动管理）`});
  el.createEl('p',{text:'选择可用或点击保存并发布，即记录你的批准并允许默认检索。官方案例无需另找判决书；个人总结不要求官方来源或核验日期。'});
  if(this.record.issues?.length)el.createEl('p',{text:'本页待解决问题：'+this.record.issues.join('；')});
  for(const [key,def] of Object.entries(this.schema.fields)){
   if(key==='status' && d.source_type==='实务分析')continue;
   if(key==='case_effect' && d.type!=='case')continue;
   const setting=new Setting(el).setName(def.label).setDesc(def.hint||key);
   setting.addDropdown(drop=>{
    if(def.optional)drop.addOption('','不填写 / 不适用');
    const options=[...def.options];if(d[key]&&!options.includes(String(d[key])))options.unshift(String(d[key]));
    for(const val of options)drop.addOption(val,val==='可用'?'可用（保存即发布）':val);
    drop.setValue(String(d[key]??''));drop.onChange(value=>{this.changes[key]=value;});
   });
  }
  el.createEl('p',{text:'案号、法院、文号及日期无需为凑齐而填写；系统可确定的会预填。不能确定的可以留空。'});
  new Setting(el).addButton(b=>b.setButtonText('保存并发布 / 允许检索').setCta().onClick(()=>this.save('publish'))).addButton(b=>b.setButtonText('仅保存属性').onClick(()=>this.save('save'))).addButton(b=>b.setButtonText('取消').onClick(()=>this.close()));
 }
 async save(action='save'){
  try{
   const changes=validateChanges(this.schema,this.current,this.changes,this.record);
   if(!Object.keys(changes).length&&action!=='publish'){this.close();return;}
   const m=matchFrontmatter(this.original),after={...this.current};
   for(const [k,v] of Object.entries(changes)){if(v==='')delete after[k];else after[k]=v;}
   const body=this.original.slice(m[0].length);
   const rec=reviseRecord(this.record,this.current,after,body,changes,new Date().toISOString(),action);
   for(const field of ['id','type','domain','jurisdiction','source_type','sources','citations','publish_status'])if(!(field in after))throw Error('缺基础属性：'+field);
   if(rec.id!==after.id)throw Error('记录ID不符');
   const text='---\n'+stringifyYaml(after).trimEnd()+'\n---\n'+body;
   commitPair(this.root,this.file.path,this.originalBytes,this.recordBytes,Buffer.from(text,'utf8'),rec);
   new Notice(after.publish_status==='可用'?'发布成功：已记录作者批准，允许默认检索。':'属性已保存：'+after.publish_status);this.close();
  }catch(e){new Notice('未完成：'+e.message,10000);}
 }
 onClose(){this.contentEl.empty();}
}
module.exports=class extends Plugin {
 async onload(){
  const open=async()=>{const file=this.app.workspace.getActiveFile();if(!file||!file.path.startsWith('wiki/')||file.extension!=='md'){new Notice('请先打开wiki中的知识页');return;}
   try{const schema=JSON.parse(await this.app.vault.adapter.read('_meta/property-options.json'));new PropertiesModal(this.app,file,schema).open();}catch(e){new Notice('属性选项未加载：'+e.message);}};
  this.addCommand({id:'choose-note-properties',name:'属性与发布：保存并发布 / 允许检索',callback:open});
  this.addRibbonIcon('list-filter','知识页属性与发布',open);
  this.registerEvent(this.app.workspace.on('file-menu',(menu,file)=>{if(file.path.startsWith('wiki/')&&file.extension==='md')menu.addItem(item=>item.setTitle('选择知识页属性').setIcon('list-filter').onClick(async()=>{const schema=JSON.parse(await this.app.vault.adapter.read('_meta/property-options.json'));new PropertiesModal(this.app,file,schema).open();}));}));
 }
};
