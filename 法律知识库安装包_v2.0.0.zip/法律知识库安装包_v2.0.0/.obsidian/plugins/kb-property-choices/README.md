# 知识库属性选择：本地发布插件

当前修复版1.1.1；ID为kb-property-choices。安装与启用详见库根[安装与使用手册](../../../安装与使用手册.md)，日常操作详见[页面操作指南](../../../wiki操作指南-页面修改与发布.md)。

启用位置：当前库设置 → 第三方插件 → 已安装插件 → 知识库属性选择。不是社区市场，也不是Obsidian网站发布。

左侧图标提示为知识页属性与发布；命令为属性与发布：保存并发布 / 允许检索；右键本地菜单为选择知识页属性。保存并发布确认当前版本；退回草稿时选择草稿并点击仅保存属性。官方案例无需原判决书，个人总结无需官方发布或人工核验日期。

部署使用独立main.js和manifest.json；main.source.js、policy.js、transaction.js为维护源码。执行node _scripts/_build_kb_property_plugin.js重新生成部署文件，再运行_scripts/_test_plugin_obsidian_loader.js等专项检查。不能直接部署依赖相对require的源码。

本插件加载及面板曾在实际Obsidian 1.14.5中完成验收，记录见outputs/插件加载修复_20261029/修复说明.md；不由此推断每个外部MCP客户端连接已完成。
