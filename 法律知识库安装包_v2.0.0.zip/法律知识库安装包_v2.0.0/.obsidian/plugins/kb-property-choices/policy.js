'use strict';
const crypto = require('crypto');
const CORE=['id','type','domain','jurisdiction','source_type','sources','citations','publish_status'];
const OPTIONAL=['status','effective_on','doc_no','case_no','court','judgment_date','case_effect','manual_overrides'];
function canonical(x) {
  if(x instanceof Date) return JSON.stringify(x.toISOString().slice(0,10));
  if (Array.isArray(x)) return '['+x.map(canonical).join(', ')+']';
  if(x && typeof x==='object') return '{'+Object.keys(x).sort().map(k=>JSON.stringify(k)+': '+canonical(x[k])).join(', ')+'}';
  return JSON.stringify(x===undefined?null:x);
}
function semanticHash(d,body) {
  const props={};for(const k of [...CORE,...OPTIONAL]) if(!['publish_status','manual_overrides'].includes(k))props[k]=d[k]===undefined?null:d[k];
  const nav=/^\s*(?:-\s*)?(?:(?:引用|补充|关联|适用|区别)：\s*)?\[\[[^\]]+\]\](?:\s*[·•]\s*\[\[[^\]]+\]\])*\s*$/;
  const lines=body.split(/\r?\n/).filter(l=>!nav.test(l)).map(l=>l.trim()).filter(Boolean);
  return crypto.createHash('sha256').update(canonical([props,lines]),'utf8').digest('hex');
}
function validateChanges(schema,current,changes,record) {
  const clean={};
  for(const [k,v] of Object.entries(changes)) {
    const def=schema.fields[k];if(!def) throw Error('该字段由系统或原文管理：'+k);
    if(v==='' && !def.optional)throw Error('必需字段不能清空：'+k);
    if(v!=='' && !def.options.includes(v))throw Error('不在允许选项中：'+k);
    if(k==='publish_status' && v==='可用' && record.issues?.length)throw Error('存在实质问题：'+record.issues.join('；'));
    if((current[k]??'')!==v)clean[k]=v;
  }
  return clean;
}
function reviseRecord(record,before,after,body,changes,now,action='save') {
  const next=JSON.parse(JSON.stringify(record));
  next.property_edits=next.property_edits||[];
  const hash=semanticHash(after,body),publish=action==='publish'||changes.publish_status==='可用';
  next.property_edits.push({at:now,changes,previous_approval:next.approval||null,note:'用户操作；发布批准与来源核验分开'});
  if(publish){
    if(next.issues?.length)throw Error('存在实质问题：'+next.issues.join('；'));
    if(next.approval){next.approval_history=next.approval_history||[];next.approval_history.push(next.approval);}
    next.approval={kind:'author_publication',basis:'作者在Obsidian选择发布/保存并发布',recorded_on:now,content_hash:hash,not_a_new_human_verification:true};
    after.publish_status='可用';next.publication_history=next.publication_history||[];
    next.publication_history.push({at:now,action:'publish',basis:next.approval.basis});
    if(after.type==='topic'&&!next.official_publications?.length)next.usage_class='author_summary';
  }else if(changes.publish_status==='停用'||changes.publish_status==='草稿'){
    if(next.approval){next.approval_history=next.approval_history||[];next.approval_history.push(next.approval);}
    next.approval=null;
  }else if(hash!==record.content_hash){
    after.publish_status='草稿';next.unrecorded_status_intent={observed:before.publish_status,reason:'当前修改尚未发布；保存并发布可确认新版，旧批准保留供追溯'};
  }
  next.content_hash=hash;return next;
}
function matchFrontmatter(text){return text.match(/^---[ \t]*\r?\n([\s\S]*?)\r?\n---(?:\r?\n|$)/);}
module.exports={semanticHash,validateChanges,reviseRecord,matchFrontmatter};
