"""法律知识库空库生成器 —— 独立可用。

用法：
    python scripts/build_skeleton.py <KB_ROOT>
    python scripts/build_skeleton.py <KB_ROOT> --with-index

生成内容（依 rules.md V5.2 现行规范）：
    wiki/ draft/ raw/     十领域 × (terms / cases / topics)
                         索引文件全库唯一命名（wiki 用 {code}-index，draft 用 {code}-draft-index）
                         raw 下建 06-资料包索引（G 目录门禁需要）
    _meta/                pages / sources / fetch-cache / publish-locks /
                         transactions / history —— 发布记录与来源证据的存放位置
    config/ logs/ outputs/cases/ benchmark/ lint-reports/

**只建空目录与索引占位，不写入任何法律内容。**
已存在的文件不会被覆盖，可重复运行。
"""
from __future__ import annotations

import argparse
import os
import sys

DOMAINS = [
    ("01-labor", "劳动与人事", "劳动合同、解除、工伤、社保、竞业限制"),
    ("02-contract", "合同与债", "合同成立、效力、违约、免责"),
    ("03-tort", "侵权与损害赔偿", "人身/财产损害、医疗损害"),
    ("04-ip", "知识产权", "商标、专利、著作权、商业秘密"),
    ("05-family", "婚姻家庭与继承", "离婚财产分割、子女抚养、继承、彩礼"),
    ("06-admin", "行政法", "行政处罚、行政许可、征收、信息公开"),
    ("07-corporate", "公司与商事", "公司决议、股东权益、破产、证券"),
    ("08-data", "数据与AI合规", "个人信息保护、数据权益、数据安全、AI合规"),
    ("09-criminal", "刑法与犯罪", "罪名、量刑、单位犯罪"),
    ("10-cross", "跨领域实务", "跨 2+ 领域的综合专题（不建案例页）"),
]

WIKI_INDEX_NAME = "{code}-index"
DRAFT_INDEX_NAME = "{code}-draft-index"

WIKI_INDEX_TPL = """---
id: {code}-index
type: index
domain: {code}
jurisdiction: 全国
source_type: 实务分析
sources: []
citations: []
publish_status: 草稿
---

# {code}（{name}）领域索引

> 本域涵盖：{scope}

**已发布**：词条 0 篇 · 案例 0 篇 · 专题 0 篇

---

## 核心裁判规则速查

| 争点 | 裁判规则 | 页面 |
|---|---|---|
|  |  |  |

> 待填。整理本页最常用的裁判规则，每条双链到对应页面。

## 词条（待补充）

（待补充）

## 案例（待补充）

（待补充）

## 实务专题（待补充）

（待补充）
"""

WIKI_TOTAL_INDEX = """# 全库总索引

> 每个领域一行，链接到该领域索引。
> 索引文件命名规则：**wiki 域用 `{code}-index.md`，draft 域用 `{code}-draft-index.md`**。
> 两套前缀不同，**全库唯一**，Obsidian 双链按文件名解析也不会撞名。

| 编码 | 领域 | 词条 | 案例 | 专题 |
|---|---|---|---|---|
{wiki_rows}

---

## 使用纪律

- 内容默认视为**草稿**，正式发布需通过本地发布面板批准。
- 法条**现行有效性**必须用权威源核验（国家法律法规数据库 / 专业法律数据库）。
- 引用前先看 `status` 字段，`待核实` 一律转述并提示读者。
"""
DRAFT_INDEX = """# 草稿总索引

> 本区为**待人工审核**的内容。发布到 `wiki/` 前必须人工确认。

| 编码 | 领域 | 待审词条 | 待审案例 | 待审专题 |
|---|---|---|---|---|
{draft_rows}

---

**发布纪律**：草稿移入正式库前需人工确认；写入与索引必须通过门禁校验。
"""

GITIGNORE = """# ---- Python ----
__pycache__/
*.py[cod]
.venv/
venv/
*.egg-info/

# ---- Node ----
node_modules/

# ---- 环境与凭证 ----
.env
.env.local
*.local.json
tokens.json
cookies.json
login.log
*.key
*.pem

# ---- 知识库内容（按需调整） ----
# raw/ 体积大，默认不入库；如需版本管理请自行放开
raw/

# ---- 日志与临时 ----
logs/
*.log
*.tmp
.DS_Store
Thumbs.db
"""


def log(msg: str = "") -> None:
    print(msg)


def write_if_absent(path: str, text: str, made: list) -> None:
    if os.path.exists(path):
        return
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)
    made.append(path)


def makedirs(path: str, made: list) -> None:
    if not os.path.isdir(path):
        os.makedirs(path, exist_ok=True)
        made.append(path)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("kb_root")
    ap.add_argument("--with-index", action="store_true",
                    help="生成领域索引文件（默认只建目录）")
    args = ap.parse_args()

    kb = os.path.abspath(args.kb_root)
    made: list = []

    log("空库生成器 | 目标：%s" % kb)

    for rel in ("wiki", "draft", "raw", "raw/06-资料包索引",
                "_meta/pages", "_meta/sources", "_meta/fetch-cache",
                "_meta/publish-locks", "_meta/transactions", "_meta/history",
                "config", "logs", "outputs/cases", "benchmark", "lint-reports",
                "templates", "tools"):
        makedirs(os.path.join(kb, rel.replace("/", os.sep)), made)

    for code, name, scope in DOMAINS:
        for layer in ("wiki", "draft"):
            for sub in ("terms", "cases", "topics"):
                makedirs(os.path.join(kb, layer, code, sub), made)
        if args.with_index:
            write_if_absent(
                os.path.join(kb, "wiki", code,
                             WIKI_INDEX_NAME.format(code=code) + ".md"),
                WIKI_INDEX_TPL.format(code=code, name=name, scope=scope), made)

    if args.with_index:
        rows = "\n".join(
            "| %s | %s | 0 | 0 | 0 |" % (c, n) for c, n, _ in DOMAINS)
        # 模板含字面量 {code}，用 replace 而非 format，避免 KeyError
        write_if_absent(os.path.join(kb, "wiki", "wiki-index.md"),
                        WIKI_TOTAL_INDEX.replace("{wiki_rows}", rows), made)
        rows = "\n".join(
            "| %s | %s | 0 | 0 | 0 |" % (c, n) for c, n, _ in DOMAINS)
        write_if_absent(os.path.join(kb, "draft", "draft-index.md"),
                        DRAFT_INDEX.replace("{draft_rows}", rows), made)

    write_if_absent(os.path.join(kb, ".gitignore"), GITIGNORE, made)

    log("已创建 %d 项（已存在的未覆盖）。" % len(made))
    log("未写入任何法律内容。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
