"""法律知识库 v2.0.0 安装器：部署只读检索内核并生成接入配置。

用法：
    python scripts/install.py --kb-root "D:\\MyLawKB"
    python scripts/install.py --kb-root "D:\\MyLawKB" --dry-run

做四件事：
  1. 建立十领域骨架（wiki / draft / raw）+ _meta / templates / tools / _scripts / config；
  2. 复制规则、模板、规则引擎、只读 MCP、发布插件；
  3. 建 Python 虚拟环境并安装 MCP 依赖（需联网）；
  4. 生成 config/mcp.json。

不写入、不修改、不移动使用者的任何资料：目标目录必须全新。
"""
from pathlib import Path
import argparse
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import sys
import venv

PKG_ROOT = Path(__file__).resolve().parent.parent
VERSION = "2.0.0"
RULES_VERSION = "V5.2"
PLUGIN_VERSION = "1.1.1"

DOMAINS = [
    ("01-labor", "劳动与人事", "劳动合同、解除、工伤、社保、竞业限制"),
    ("02-contract", "合同与债", "合同成立、效力、违约、免责"),
    ("03-tort", "侵权与损害赔偿", "人身/财产损害、医疗损害"),
    ("04-ip", "知识产权", "商标、专利、著作权、商业秘密"),
    ("05-family", "婚姻家庭与继承", "离婚财产分割、子女抚养、继承、彩礼"),
    ("06-admin", "行政法", "行政处罚、行政许可、征收、信息公开"),
    ("07-corporate", "公司与商事", "公司决议、股东权益、破产、证券"),
    ("08-data", "数据与AI合规", "个人信息保护、数据权益、数据安全、AI合规"),
    ("09-criminal", "刑法与犯罪", "罪名、量刑、单位犯罪"),
    ("10-cross", "跨领域实务", "跨 2+ 领域的综合专题（不建案例页）"),
]

# 复制到目标库的受管文件：源路径 -> 目标相对路径
MANAGED_TREE = [
    ("_scripts", "_scripts"),
    ("templates", "templates"),
    ("tools/legal-tools/自建知识库MCP", "tools/legal-tools/自建知识库MCP"),
    (".obsidian/plugins/kb-property-choices", ".obsidian/plugins/kb-property-choices"),
]
MANAGED_FILES = [
    ("rules.md", "rules.md"),
    ("_meta/property-options.json", "_meta/property-options.json"),
]
IGNORED = shutil.ignore_patterns("__pycache__", "*.pyc", "*.pyo", ".git",
                                 "node_modules", ".venv", "venv")


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def collect_sources() -> dict:
    """收集包内受管文件 -> (包内相对路径, 目标相对路径)。"""
    files = {}
    for src_dir, dst_dir in MANAGED_TREE:
        base = PKG_ROOT / src_dir
        if not base.is_dir():
            raise RuntimeError("包内缺少目录：%s" % src_dir)
        for p in sorted(base.rglob("*")):
            if not p.is_file():
                continue
            if any(part in ("__pycache__", "node_modules", ".git", ".venv")
                   for part in p.parts):
                continue
            if p.suffix in (".pyc", ".pyo"):
                continue
            rel = p.relative_to(base).as_posix()
            files[src_dir + "/" + rel] = dst_dir + "/" + rel
    for src, dst in MANAGED_FILES:
        if not (PKG_ROOT / src).exists():
            raise RuntimeError("包内缺少文件：%s" % src)
        files[src] = dst
    return files


def managed_install(kb: Path, files: dict) -> dict:
    """复制受管文件。已存在且内容不同 -> 冲突拒绝，不静默覆盖。"""
    state_path = kb / "config" / "managed-files.json"
    old = {}
    if state_path.exists():
        try:
            old = json.loads(state_path.read_text(encoding="utf-8")).get("files", {})
        except Exception:
            old = {}

    plan, conflicts = [], []
    for src_rel, dst_rel in files.items():
        src = PKG_ROOT / src_rel
        dst = kb / dst_rel
        if dst.is_symlink():
            conflicts.append(dst_rel + "（符号链接）")
            continue
        if dst.exists():
            if digest(dst) != digest(src) and digest(dst) != old.get(dst_rel):
                conflicts.append(dst_rel)
                continue
        plan.append((src_rel, dst_rel, src, dst))

    if conflicts:
        raise RuntimeError(
            "受管文件冲突，未更新。请备份比对或改用新目录：\n  - "
            + "\n  - ".join(conflicts))

    stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    hashes = {}
    for src_rel, dst_rel, src, dst in plan:
        if dst.exists() and digest(dst) != digest(src):
            backup = kb / "config" / "code-backup" / stamp / dst_rel
            backup.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(dst, backup)
        dst.parent.mkdir(parents=True, exist_ok=True)
        if not dst.exists() or digest(dst) != digest(src):
            shutil.copy2(src, dst)
        got = digest(dst)
        if got != digest(src):
            raise RuntimeError("复制后哈希不一致：%s" % dst_rel)
        hashes[dst_rel] = got

    state_path.parent.mkdir(parents=True, exist_ok=True)
    state_path.write_text(
        json.dumps({"version": VERSION, "files": hashes}, ensure_ascii=False, indent=2),
        encoding="utf-8")
    return hashes


def build_skeleton(kb: Path) -> int:
    """建立十领域骨架与必要目录。已存在的不覆盖，可重复运行。"""
    made = 0

    def mkdir(rel: str) -> None:
        nonlocal made
        p = kb / rel
        if not p.exists():
            p.mkdir(parents=True, exist_ok=True)
            made += 1

    for rel in ("wiki", "draft", "raw", "_meta/pages", "_meta/sources",
                "_meta/fetch-cache", "_meta/publish-locks", "_meta/transactions",
                "_meta/history", "config", "logs", "outputs/cases",
                "benchmark", "lint-reports", "raw/06-资料包索引"):
        mkdir(rel)

    for code, _name, _scope in DOMAINS:
        for layer in ("wiki", "draft"):
            for sub in ("terms", "cases", "topics"):
                mkdir("%s/%s/%s" % (layer, code, sub))

    # 索引是**文件**，不是目录。统一命名规则：wiki 用 {code}-index.md，
    # draft 用 {code}-draft-index.md，两套前缀不同，全库唯一，
    # Obsidian 双链按文件名解析也不会撞名。
    # 索引须带 frontmatter 且含「（待补充）」占位符，
    # 之后运行 _scripts/_fill_index.py 即可自动登记页面。
    # 注：索引页同样需要外置记录（hydrate 从记录派生 review_status /
    # authority_level），故此处一并创建，避免门禁 G2 在空库即报缺字段。
    index_tpl = (
        "---\n"
        "id: {id}\n"
        "type: index\n"
        "domain: {domain}\n"
        "jurisdiction: 全国\n"
        "source_type: 实务分析\n"
        "sources: []\n"
        "citations: []\n"
        "publish_status: 草稿\n"
        "---\n"
        "\n"
        "# {title}\n"
        "\n"
        "## 核心裁判规则速查\n"
        "\n"
        "| 争点 | 裁判规则 | 页面 |\n"
        "|---|---|---|\n"
        "|  |  |  |\n"
        "\n"
        "## 词条（待补充）\n"
        "\n"
        "（待补充）\n"
        "\n"
        "## 案例（待补充）\n"
        "\n"
        "（待补充）\n"
        "\n"
        "## 实务专题（待补充）\n"
        "\n"
        "（待补充）\n"
    )
    for code, name, _scope in DOMAINS:
        rel = "wiki/%s/%s-index.md" % (code, code)
        p = kb / rel
        if not p.exists():
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(index_tpl.format(
                id="%s-index" % code, domain=code,
                title="%s（%s）领域索引" % (code, name)),
                encoding="utf-8", newline="\n")
            made += 1
        made += ensure_page_record(kb, p)

    total_tpl = (
        "---\n"
        "id: wiki-index\n"
        "type: index\n"
        "domain: cross\n"
        "jurisdiction: 全国\n"
        "source_type: 实务分析\n"
        "sources: []\n"
        "citations: []\n"
        "publish_status: 草稿\n"
        "---\n"
        "\n"
        "# 全库总索引\n"
        "\n"
        "| 编码 | 领域 | 词条 | 案例 | 专题 |\n"
        "|---|---|---|---|---|\n"
        + "".join("| %s | %s | 0 | 0 | 0 |\n" % (c, n) for c, n, _ in DOMAINS)
    )
    for rel, text in (("wiki/wiki-index.md", total_tpl),
                      ("draft/draft-index.md",
                       total_tpl.replace("id: wiki-index", "id: draft-index")
                              .replace("# 全库总索引", "# 草稿总索引"))):
        p = kb / rel
        if not p.exists():
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(text, encoding="utf-8", newline="\n")
            made += 1
        if rel.startswith("wiki/"):
            made += ensure_page_record(kb, p)
    return made


def ensure_page_record(kb: Path, page: Path) -> int:
    """为页面创建外置记录（若尚无）。索引与骨架页需要它，否则 hydrate 派生不出字段。"""
    import re as _re
    try:
        import yaml
    except ImportError:
        return 0
    text = page.read_text(encoding="utf-8-sig")
    if not text.startswith("---"):
        return 0
    end = text.find("\n---", 3)
    if end == -1:
        return 0
    try:
        d = yaml.safe_load(text[3:end])
    except Exception:
        return 0
    if not isinstance(d, dict):
        return 0
    ident = str(d.get("id") or "").strip()
    if not ident or not _re.fullmatch(r"[\w-]+", ident):
        return 0
    rp = kb / "_meta" / "pages" / ("%s.json" % ident)
    if rp.exists():
        return 0
    body = text[end + 4:]
    core = ("id", "type", "domain", "jurisdiction", "source_type",
            "sources", "citations", "publish_status")
    optional = ("status", "effective_on", "doc_no", "case_no", "court",
                "judgment_date", "case_effect", "manual_overrides")
    props = {k: d.get(k) for k in core + optional
             if k not in ("publish_status", "manual_overrides")}
    nav = _re.compile(
        r"\s*(?:-\s*)?(?:(?:引用|补充|关联|适用|区别)：\s*)?\[\[[^\]]+\]\]"
        r"(?:\s*[·•]\s*\[\[[^\]]+\]\])*\s*")
    lines = []
    for line in body.splitlines():
        if nav.fullmatch(line):
            continue
        line = line.strip()
        if line:
            lines.append(line)
    content_hash = hashlib.sha256(json.dumps(
        [props, lines], ensure_ascii=False, sort_keys=True,
        default=str).encode()).hexdigest()
    record = {
        "schema": 5,
        "id": ident,
        "path": page.relative_to(kb).as_posix(),
        "content_hash": content_hash,
        "legacy": {"status": d.get("status", "待核实"),
                   "verify_source": "未核验",
                   "review_status": "草稿"},
        "evidence_refs": [],
        "issues": [],
        "approval": None,
        "publication_history": [],
        "machine_queue": ["按需补充真实来源证据；作者批准后方进入默认检索"],
        "display_cleanup": "无",
    }
    rp.parent.mkdir(parents=True, exist_ok=True)
    rp.write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n",
                  encoding="utf-8", newline="\n")
    return 1


def python_in(kb: Path) -> Path:
    if os.name == "nt":
        return kb / ".venv" / "Scripts" / "python.exe"
    return kb / ".venv" / "bin" / "python"


def generate_mcp_config(kb: Path) -> Path:
    """生成 MCP 接入配置。已有不同配置时另存 proposed，不覆盖。"""
    py = python_in(kb)
    cfg = {"mcpServers": {"legal-kb": {
        "command": str(py),
        "args": ["-B", str(kb / "tools/legal-tools/自建知识库MCP/scripts/server.py")],
        "env": {"KNOWLEDGE_ROOT": str(kb)},
    }}}
    target = kb / "config" / "mcp.json"
    if target.exists():
        try:
            same = json.loads(target.read_text(encoding="utf-8")) == cfg
        except Exception:
            same = False
        if not same:
            proposed = kb / "config" / "mcp.proposed.json"
            proposed.write_text(
                json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
            print("已有配置已保留，新配置写入 mcp.proposed.json，需人工合并。")
            return proposed
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    return target


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--kb-root", required=True, help="目标库根目录（必须在包目录之外）")
    ap.add_argument("--dry-run", action="store_true", help="只检查环境与路径，不写入")
    args = ap.parse_args()

    if not (3, 10) <= sys.version_info[:2] < (3, 14):
        raise RuntimeError("使用 Python 3.10—3.13，当前为 %d.%d。"
                           % sys.version_info[:2])

    kb = Path(args.kb_root).expanduser().resolve()
    if kb == PKG_ROOT or kb.is_relative_to(PKG_ROOT) or PKG_ROOT.is_relative_to(kb):
        raise RuntimeError("目标目录与解压包不能互为父子。请指定包外的独立目录。")

    if args.dry_run:
        print("dry-run：仅检查 Python 与路径关系，未写入任何文件。")
        print("Python：%d.%d.%d" % sys.version_info[:3])
        print("包根：%s" % PKG_ROOT)
        print("目标：%s" % kb)
        try:
            files = collect_sources()
            print("受管文件：%d 个" % len(files))
        except Exception as exc:
            print("受管文件收集失败：%s" % exc)
        print("依赖声明：tools/legal-tools/自建知识库MCP/requirements.txt")
        return 0

    kb.mkdir(parents=True, exist_ok=True)

    # 旧安装检测：无受管清单但已有工具/规则 -> 拒绝，要求新目录
    if not (kb / "config" / "managed-files.json").exists() and any(
            (kb / x).exists() for x in ("tools", "_scripts", "rules.md")):
        raise RuntimeError(
            "目标目录已有旧安装痕迹但缺少受管清单。请换新目录安装，"
            "再人工迁移你自己的 raw/wiki/draft；工具与凭证不迁移。")

    files = collect_sources()
    hashes = managed_install(kb, files)
    made = build_skeleton(kb)

    py = python_in(kb)
    if not py.exists():
        print("创建虚拟环境：%s" % (kb / ".venv"))
        venv.EnvBuilder(with_pip=True).create(kb / ".venv")
    if subprocess.run([str(py), "-c", "import pip"],
                      capture_output=True).returncode != 0:
        subprocess.run([str(py), "-m", "ensurepip", "--upgrade", "--default-pip"],
                       check=True)

    req = kb / "tools/legal-tools/自建知识库MCP/requirements.txt"
    print("安装依赖（需联网）...")
    subprocess.run([str(py), "-m", "pip", "install", "-r", str(req)], check=True)
    subprocess.run([str(py), "-c",
                    "import mcp, pydantic, yaml; "
                    "from importlib.metadata import version; "
                    "assert version('mcp').split('.')[0] == '1'"], check=True)

    cfg_path = generate_mcp_config(kb)

    receipt = {
        "package_version": VERSION,
        "rules_version": RULES_VERSION,
        "plugin_version": PLUGIN_VERSION,
        "installed_at": datetime.datetime.now().isoformat(timespec="seconds"),
        "python": "%d.%d.%d" % sys.version_info[:3],
        "kb_root": str(kb),
        "managed_files": len(hashes),
        "skeleton_dirs_created": made,
        "mcp_config": str(cfg_path),
    }
    (kb / "config" / "install-receipt.json").write_text(
        json.dumps(receipt, ensure_ascii=False, indent=2), encoding="utf-8")

    print("")
    print("=" * 66)
    print("文件与依赖已安装")
    print("  库根：%s" % kb)
    print("  受管文件：%d 个" % len(hashes))
    print("  MCP 配置：%s" % cfg_path)
    print("=" * 66)
    print("接下来：")
    print("  1. 用 Obsidian 打开**库根**（不是子目录）")
    print("  2. 复制 .obsidian/plugins/kb-property-choices/ 到你的库并在已安装列表启用")
    print("  3. 导入 config/mcp.json 到 AI 客户端，点「信任」后重开会话")
    print("  4. 造一篇含唯一标记的测试页，跑一次真实检索验收")
    print("")
    print("尚未验证：宿主导入、实际检索、Obsidian 面板加载。请按《安装与环境准备》§6 验收。")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as exc:
        print("安装未完成：%s" % exc, file=sys.stderr)
        sys.exit(1)
